#!/bin/bash
pm2 reload 0
#service httpd restart > /var/log/restarthttpd.out 2>&1
#service php-fpm restart > /var/log/restarthttpd.out 2>&1
exit 0
