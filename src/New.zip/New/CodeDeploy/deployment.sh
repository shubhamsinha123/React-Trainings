#!/bin/bash
WEB="/var/www/dev-next/"
ENV="/var/www/.env"

cd $WEB

# copy the content from server .env file to project's .env before build begins
cp $ENV $WEB

sudo npm install
sudo npm run build
pm2 reload 0
chown -Rf ameex-digital.apache $WEB
