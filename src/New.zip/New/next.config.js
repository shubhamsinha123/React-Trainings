// const withCss = require('@zeit/next-css')
// const withScss = require('@zeit/next-sass')
// const withPurgeCss = require('next-purgecss')
const nextSafe = require('next-safe')

// const config = withCss(withScss(withPurgeCss({
//     purgeCssPaths: [
//         'pages/**/*',
//         'components/**/*'
//     ],
//     purgeCss: {
//         whitelist: () => ['player'],
//         whitelistPatterns: () => [/Toastify/, /.*nprogress.*/],
//         rejected: true
//     },
//     purgeCssEnabled: ({ dev, isServer }) => true, // Enable PurgeCSS for all env
// })
// )
// );
// module.exports = config;
// module.exports = withCss(withScss(
//     withPurgeCss({
//         compress: true,
//     //   purgeCssEnabled: ({ dev, isServer }) => (!dev && !isServer) // Only enable PurgeCSS for client-side production builds
//     })
//   )
// )

const isDev = process.env.NODE_ENV !== 'production'

/**
 * Content Security Policy Domains
 */
const cspSources = ["'self'",
    'https://*.ameexdigital.com',
    'https://*.youtube.com',
    'https://assets.calendly.com',
    'https://purecatamphetamine.github.io/country-flag-icons/',
    'https://catamphetamine.gitlab.io/country-flag-icons/',
    'https://calendly.com',
    "'unsafe-inline'",
    "'unsafe-eval'",
];

const cspCloudflare = [
    "https://*.cloudflare.com",
    "https://*.cloudflareinsights.com",
    'https://*.cloudflareinsights.co'
]

const cspHotjar = [
    'https://script.hotjar.com',
    'http://script.hotjar.com',
    'https://*.hotjar.com',
    'http://*.hotjar.com',
    'http://*.hotjar.com:*',
    'https://*.hotjar.com:*',
    'http://*.hotjar.io',
    'https://*.hotjar.io',
    'wss://*.hotjar.com'
]

const cspGTM = [
    'https://analytics.google.com/',
    'https://www.google-analytics.com',
    'https://ssl.google-analytics.com',
    'https://www.googletagmanager.com',
    'https://www.googleadservices.com',
    'https://*.google.com',
    'https://googleads.g.doubleclick.net',
    'https://stats.g.doubleclick.net',
]

module.exports = {
    async redirects() {
        return [
          {
            source: '/blog-detail/conversion-rate-optimization-tips-paid-ads-2022',
            destination: '/blog-detail/conversion-rate-optimization-tips-paid-ads',
            permanent: true,
          },
        ]
      },
    async headers() {
        return [
            {
                source: '/:path*',
                headers: nextSafe({
                    isDev,
                    referrerPolicy: 'strict-origin-when-cross-origin',
                    contentSecurityPolicy: {
                        'default-src': [...cspSources, ...cspCloudflare, ...cspGTM, ...cspHotjar],
                        'connect-src': [...cspSources, ...cspCloudflare, ...cspGTM, ...cspHotjar],
                        'img-src': [...cspSources, 'data:', ...cspCloudflare, ...cspGTM, ...cspHotjar],
                        'script-src': [...cspSources, ...cspCloudflare, ...cspGTM, ...cspHotjar],
                        'style-src': [...cspSources, ...cspCloudflare, ...cspGTM, ...cspHotjar],
                        'frame-src': [...cspSources, ...cspCloudflare, ...cspGTM, ...cspHotjar],
                        'font-src': [...cspSources, ...cspCloudflare, ...cspGTM, ...cspHotjar],
                        'worker-src': [...cspSources, ...cspCloudflare, ...cspGTM, ...cspHotjar],
                    }
                }),
            },
        ]
    },
    compress: true,
    images: {
        domains: ['dev-drupal.ameexdigital.com', 'stg-drupal.ameexdigital.com', 'prod-drupal.ameexdigital.com'],
    },
}
// module.exports = {
//     webpack: (config) => {​​​​​​​​
//         config.module.rules.push({​​​​​​​​
//             test: /\.(png|jpg|jpeg|gif|svg)$/i,
//             use: [
//                 {​​​​​​​​
//                     loader: "url-loader",
//                     options: {​​​​​​​​
//                         limit: 8192,
//                     }​​​​​​​​,
//                 }​​​​​​​​,
//             ],
//         }​​​​​​​​);
//         return config;
//     }​​​​​​​​,
// }​​​​​​​​;



