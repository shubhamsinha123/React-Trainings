import React from 'react';
import GlobalHeader from './header';
import LazyLoad from 'react-lazyload'
import dynamic from 'next/dynamic';

const FooterComp = dynamic(() => import('./footer/footer'), {
    ssr: false
})

const Layout = ({ children, header, footer, allInsights=[] }) => {
    return (
        <>
            <GlobalHeader data={header} allInsights={allInsights} />
            <main>
                {children}
            </main>
            <LazyLoad height={400} offset={450}>
                <FooterComp data={footer} />
            </LazyLoad>
        </>
    )
}

export default Layout;
