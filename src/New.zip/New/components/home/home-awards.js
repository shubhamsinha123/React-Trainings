import React, { useEffect } from 'react';
import ReactPlaceholder from 'react-placeholder';
import "react-placeholder/lib/reactPlaceholder.css";
import { LazyLoadComponent } from 'react-lazy-load-image-component';
import { useQuery } from 'react-query'
import { getHomeAwards } from "../../services/insights.service";

const HomeAwards = (props) => {
const awardData = useQuery('home-awards-data', getHomeAwards, {
    initialData: props.data || {},
    refetchOnMount: false,
    refetchOnWindowFocus: false,
})

useEffect(() => {
    if(!props.data || !Object.keys(props.data).length) {
        awardData.refetch();
    }
}, [])

return (
    <section className="awards-content">
        <div className="container-fluid">
            <div className="wrapper">
                <div className="row">
                    <div className="col-md-12">
                        <div className="awards-content-title">
                            <ReactPlaceholder type='text' rows={1} ready={!awardData.isLoading} style={{ width: "33%", marginLeft: "36%" }} showLoadingAnimation={true}>
                                <h4>{awardData.data.field_title}</h4>
                            </ReactPlaceholder>
                        </div>
                        <div className="container-fluid">
                            <div className="awards-content-partner row">
                                {awardData.data.field_reward_export && awardData.data.field_reward_export.map((awardsItem, index) => (
                                    <div className="awards-content-item col-md-3" key={index}>
                                        <div className="image-wrapper">

                                            <ReactPlaceholder type='round' style={{ width: "125px", height: "125px", borderradius: "50%", marginLeft: "27%" }} ready={!awardData.isLoading} showLoadingAnimation={true}>
                                                <LazyLoadComponent effect="blur">
                                                    <picture className="piture-image">
                                                        <source media="(max-width: 767px)" srcSet={awardsItem.reward_mobile_image} />
                                                        <img src={awardsItem.reward_desktop_image} alt="our-awards" loading="lazy" />
                                                    </picture>
                                                </LazyLoadComponent>
                                            </ReactPlaceholder>
                                        </div>
                                        <div className="desc">
                                            <ReactPlaceholder type='text' rows={1} ready={!awardData.isLoading} showLoadingAnimation={true}>
                                                <p>{awardsItem.reward_description}</p>
                                            </ReactPlaceholder>
                                        </div>
                                    </div>
                                ))
                                }
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
)
}
export default HomeAwards;