import React, { useState, useEffect } from "react";
import Link from "next/link";
import "react-placeholder/lib/reactPlaceholder.css";
import VideoModal from "../../common/VideoModal/VideoModal";
import ReactPlaceholder from "react-placeholder";
import dynamic from "next/dynamic";
import gsap from 'gsap';
import insightStyle from './homeGrayslider.module.scss';
import { useQuery } from 'react-query'
import { ScrollTrigger } from 'gsap/dist/ScrollTrigger';
import { getAllInsights, getHomePageInsights } from "../../../services/insights.service";
const Slider = dynamic(() => import("react-slick"), {
    ssr: false,
});
const HomeGreySlider = (props) => {
    const sectionRef = React.createRef(null);
    const rightSectionRef = React.createRef(null);
    const [videoContent, setVideoContent] = useState({})
    const [innovationoverlay_left, setInnovationoverlay_left] = useState(0);
    const [animation_start, setAnimation_start] = useState(0);
    const insightData = useQuery('homepage-insights', getHomePageInsights, {
        initialData: {}
    })
    const allInsights = useQuery('all-insights', getAllInsights, {
        initialData: [],
        refetchOnWindowFocus: false,
        select: (resdata) => {
            var filteryt = resdata.filter(function (obj) {
                return obj.field_watch_video_link.includes("youtube");
            });
            return {
                insightsbanner_leftsider: filteryt || [],
                insights: resdata || []
            }
        },
    })
    useEffect(() => {
        window.addEventListener("scroll", handleScroll, true);
        gsap.registerPlugin(ScrollTrigger);
        ScrollTrigger.saveStyles(rightSectionRef?.current);
        ScrollTrigger.matchMedia({
            "(min-width: 768px)": () => {
                let tl = gsap.timeline({
                    scrollTrigger: {
                        trigger: sectionRef?.current,
                        scrub: .9,
                        start: '-=300',
                        end: "+=280",
                    }
                });
                tl.fromTo(rightSectionRef?.current, { y: '280px' }, { y: '-120px' })
            },
            "(max-width: 799px)": function () {
            },
            "all": function () {
            }
        });
    }, [])
    const handleScroll = (e) => {
        let innovationElement = document.getElementById("solutionswidth");
        let innovationLeft = innovationElement?.offsetLeft;
        let screenWidth = window.innerWidth;
        let wrapperElement = document.getElementById("wrapperwidth");
        let wrappWidth = wrapperElement?.clientWidth;
        setInnovationoverlay_left(innovationLeft);
        let overlayslider = document.getElementById("scrolloverlayslider");
        let screenHeight = window.innerHeight;
        let overlaysliderTop = overlayslider?.offsetTop - screenHeight + 230;
        if (window.scrollY >= overlaysliderTop) {
            setAnimation_start(1);
        }
        if (window.scrollY < overlaysliderTop) {
            setAnimation_start(2);
        }
    };
    const handleOpenModal = (title_head, url_video) => {
        setVideoContent({
            title: title_head,
            url: url_video
        })
    }
    const handleCloseModal = () => {
        setVideoContent({})
    }
    var insights = {
        dots: !1,
        infinite: !0,
        centerMode: !0,
        slidesToShow: 1,
        slidesToScroll: 1,
    };
    if (typeof window !== "undefined") {
        if (window.innerWidth > 767) {
            var innovationoverlayStyle = {};
            if (animation_start === 0) {
                innovationoverlayStyle = {};
            }
            if (animation_start === 1) {
                innovationoverlayStyle = {
                    transform: `translate(${innovationoverlay_left}px, 0)`,
                };
            }
            if (animation_start === 2) {
                innovationoverlayStyle = {
                    transform: "translate(0, 0)",
                };
            }
        }
    }
    return (
        <>
            <section ref={sectionRef} className={`${insightStyle.slider} ${insightStyle.greyanimation}`} id="scrolloverlayslider">
                <div className={insightStyle.innovationsOverlay} style={innovationoverlayStyle}></div>
                <div className="container-fluid">
                    <div className="wrapper" id="wrapperwidth">
                        <div className="row">
                            <div className={`${insightStyle.insightSlider} col-md-8`}>
                                <div className={insightStyle.mediaSolutions}>
                                    <div className={insightStyle.nightsliderContent}>
                                        <h2>
                                            <ReactPlaceholder
                                                type="text"
                                                rows={1}
                                                ready={!insightData.isLoading}
                                                showLoadingAnimation={true}
                                            >
                                                <span>{insightData.data.field_title}</span>
                                            </ReactPlaceholder>
                                        </h2>
                                        <ReactPlaceholder
                                            type="text"
                                            rows={2}
                                            ready={!insightData.isLoading}
                                            showLoadingAnimation={true}
                                            style={{ width: "33%", marginLeft: "0%" }}
                                        >
                                            <p>{insightData.data.field_description}</p>
                                        </ReactPlaceholder>

                                        <div className="night-slider" style={{ width: "100%" }}>
                                            <div
                                                className={`${insightStyle.slider} center`}
                                                style={{ width: "100%" }}
                                            >
                                                <VideoModal
                                                    show={videoContent.url}
                                                    onClose={handleCloseModal}
                                                    url={videoContent.url}
                                                    title={videoContent.title}
                                                    backLink="Home page"
                                                />
                                                <Slider {...insights}>
                                                    {!allInsights.isLoading && allInsights.data?.insightsbanner_leftsider?.map(
                                                        (insightleftsider, index) => (
                                                            <div key={index}>
                                                                <div className={`${insightStyle.mediaVideo} ${insightStyle.youtubePlayer}`}>
                                                                    <span
                                                                        className={`${insightStyle.thumbVideohome} amd-play3`}
                                                                        style={{ cursor: "pointer" }}
                                                                        onClick={() => { handleOpenModal(insightleftsider.title, insightleftsider.field_watch_video_link) }}
                                                                    ></span>
                                                                    <img
                                                                        className={insightStyle.homeslideImg}
                                                                        href="#"
                                                                        src={
                                                                            insightleftsider.field_mobile_video_thumbnail
                                                                        }
                                                                        alt=""
                                                                        loading="lazy"
                                                                    />
                                                                    <div className={insightStyle.strategy}>
                                                                        <div className="set">
                                                                            <a
                                                                                href={`${insightleftsider.view_node}`}
                                                                                style={{ cursor: "pointer" }}
                                                                            >
                                                                                <h4>{insightleftsider.title}</h4>
                                                                            </a>
                                                                            <div>
                                                                                <a
                                                                                    className={insightStyle.readArt}
                                                                                    href={`${insightleftsider.view_node}`}
                                                                                    style={{ cursor: "pointer" }}
                                                                                >
                                                                                    <span className={`${insightStyle.readArticle1} amd-readarticle`}></span>{" "}
                                                                                    {
                                                                                        insightleftsider.field_read_more_text
                                                                                    }
                                                                                </a>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        )
                                                    )}
                                                </Slider>
                                            </div>
                                        </div>
                                        <div className={insightStyle.groupBtn}>
                                            <div className={insightStyle.bgTwo}>
                                                <ReactPlaceholder
                                                    type="text"
                                                    rows={1}
                                                    ready={!allInsights.isLoading}
                                                    showLoadingAnimation={true}
                                                    style={{
                                                        width: "33%",
                                                        marginLeft: "0%",
                                                        height: "2em",
                                                    }}
                                                >
                                                    <Link href="/insights">
                                                        <a className={insightStyle.btn}>VIEW ALL INSIGHTS </a>
                                                    </Link>
                                                </ReactPlaceholder>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className={`${insightStyle.solutions} col-md-4`} id="solutionswidth">
                                <div className={insightStyle.innovations}>
                                    <div className={insightStyle.cardDiscover}>
                                        <div ref={rightSectionRef} className={insightStyle.solutionsContent}>
                                            {!allInsights.isLoading && allInsights.data?.insights.map(
                                                (
                                                    {
                                                        title,
                                                        field_insight_description,
                                                        view_node,
                                                        field_authors_profile_image,
                                                        field_auth,
                                                        field_authors_date,
                                                        field_read_more_text,
                                                    },
                                                    index
                                                ) => {
                                                    if (index == 0 || index == 1) {
                                                        return (
                                                            <div key={index} className={insightStyle.bgSolution}>
                                                                <ReactPlaceholder
                                                                    type="text"
                                                                    rows={2}
                                                                    ready={!allInsights.isLoading}
                                                                    showLoadingAnimation={true}
                                                                    style={{
                                                                        width: "33%",
                                                                        marginLeft: "0%",
                                                                        height: "2em",
                                                                    }}
                                                                >
                                                                    <h3>
                                                                        {
                                                                            <a
                                                                                href={`${view_node}`}
                                                                                style={{ cursor: "pointer" }}
                                                                            >
                                                                                {title}
                                                                            </a>
                                                                        }
                                                                    </h3>
                                                                </ReactPlaceholder>

                                                                <p className={insightStyle.bgsolutionDesc}>
                                                                    <ReactPlaceholder
                                                                        type="text"
                                                                        rows={2}
                                                                        ready={!allInsights.isLoading}
                                                                        showLoadingAnimation={true}
                                                                        style={{
                                                                            width: "33%",
                                                                            marginLeft: "0%",
                                                                            height: "2em",
                                                                        }}
                                                                    >
                                                                        <span>{field_insight_description}</span>
                                                                    </ReactPlaceholder>
                                                                </p>

                                                                <ReactPlaceholder
                                                                    type="text"
                                                                    rows={1}
                                                                    ready={!allInsights.isLoading}
                                                                    showLoadingAnimation={true}
                                                                    style={{
                                                                        width: "33%",
                                                                        marginLeft: "0%",
                                                                        height: "2em",
                                                                    }}
                                                                >
                                                                    <a
                                                                        href={`${view_node}`}
                                                                        className={insightStyle.readarticle}
                                                                    >
                                                                        {field_read_more_text}
                                                                    </a>
                                                                </ReactPlaceholder>

                                                                <div className={insightStyle.Avatar2Lines}>
                                                                    <div className="row">
                                                                        <div className="col-2">
                                                                            <div className={insightStyle.article}>
                                                                                <ReactPlaceholder
                                                                                    type="round"
                                                                                    style={{
                                                                                        width: "60px",
                                                                                        height: "60px",
                                                                                        borderradius: "50%",
                                                                                        marginLeft: "0%",
                                                                                        marginRight: "9px",
                                                                                    }}
                                                                                    ready={!allInsights.isLoading}
                                                                                    showLoadingAnimation={true}
                                                                                >
                                                                                    <span className={insightStyle.namedateIconarticle}>
                                                                                        <img
                                                                                            src={
                                                                                                field_authors_profile_image
                                                                                            }
                                                                                            className={insightStyle.imgResponsive}
                                                                                            loading="lazy"
                                                                                            width={40}
                                                                                            height={40}
                                                                                            className={insightStyle.imgResponsive}
                                                                                        />
                                                                                    </span>
                                                                                </ReactPlaceholder>
                                                                            </div>
                                                                        </div>
                                                                        <div className="col-10">
                                                                            <div className={insightStyle.elit}>
                                                                                <ReactPlaceholder
                                                                                    type="text"
                                                                                    rows={1}
                                                                                    ready={!allInsights.isLoading}
                                                                                    showLoadingAnimation={true}
                                                                                    style={{
                                                                                        width: "33%",
                                                                                        marginLeft: "0%",
                                                                                        height: "2em",
                                                                                    }}
                                                                                >
                                                                                    <h4>{field_auth}</h4>
                                                                                </ReactPlaceholder>

                                                                                <ReactPlaceholder
                                                                                    type="text"
                                                                                    rows={1}
                                                                                    ready={!allInsights.isLoading}
                                                                                    showLoadingAnimation={true}
                                                                                    style={{
                                                                                        width: "33%",
                                                                                        marginLeft: "0%",
                                                                                        height: "2em",
                                                                                    }}
                                                                                >
                                                                                    <p>{field_authors_date}</p>
                                                                                </ReactPlaceholder>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        );
                                                    }
                                                }
                                            )}
                                            <div className={insightStyle.groupbtnIpadmob}>
                                                <div className={insightStyle.bgTwo}>

                                                    <ReactPlaceholder
                                                        type="text"
                                                        rows={1}
                                                        ready={!allInsights.isLoading}
                                                        showLoadingAnimation={true}
                                                        style={{
                                                            width: "33%",
                                                            marginLeft: "0%",
                                                            height: "2em",
                                                        }}
                                                    >

                                                        <a href="/insights" className={insightStyle.btn}>
                                                            VIEW ALL INSIGHTS{" "}
                                                        </a>
                                                    </ReactPlaceholder>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>
    );
}
export default HomeGreySlider;