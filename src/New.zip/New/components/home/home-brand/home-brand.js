import React, { useState, useEffect } from 'react';
import Link from "next/link";
import ReactPlaceholder from 'react-placeholder';
import { Parallax as ScrollParallax } from 'react-scroll-parallax';
import "react-placeholder/lib/reactPlaceholder.css";
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/dist/ScrollTrigger';
import { isMobile } from 'react-device-detect';
import { useQuery } from 'react-query'
import { getHomeBrand } from '../../../services/insights.service';
import styles from "./homeBrand.module.scss"

let Parallax = ScrollParallax;

if (isMobile) {
    Parallax = ({ children }) => <React.Fragment>{children}</React.Fragment>;
}

let brandStyle = {
    marginTop: 300,
};

const HomeBrand = (props) => {
    const sectionRef = React.createRef(null);
    const rightSectionRef = React.createRef(null);
    const [brandShow, setBrandShow] = useState(false);
    // const [brandStyle, setBrandStyle] = useState({ marginTop: 300 });

    const brandData = useQuery('home-brand', getHomeBrand, {
        initialData: props.data,
        refetchOnMount: false,
        refetchOnWindowFocus: false,
    })

    useEffect(()=> {
        if (window.innerWidth >= 768) {
            // setBrandStyle({});
            sectionRef?.current?.style.marginTop = 0;
        }
        if(!props.data?.field_top_title) {
            brandData.refetch();
        }
        gsap.registerPlugin(ScrollTrigger);
        ScrollTrigger.saveStyles(rightSectionRef?.current);
        ScrollTrigger.matchMedia({
            "(min-width: 768px)": () => {
                let tl = gsap.timeline({
                    scrollTrigger: {
                        trigger: sectionRef?.current,
                        scrub: .5,
                        start: '-=400',
                        end: "+=850",
                    }
                });
                tl.fromTo(rightSectionRef?.current, { y: '140px' }, { y: '-240px' })
            },
            "(max-width: 799px)": function () {
            },
            "all": function () {
            }
        });
    }, [])

    const loadMoreBrand = () => {
        setBrandShow(!brandShow);
    }

    // if (typeof window !== "undefined") {
    //     if (window.innerWidth <= 767) {
    //         brandStyle ={
    //             marginTop: '300px',
    //         }
    //     }
    // }

    return (
        <section ref={sectionRef} className={styles.brand} id="brand">
            <div className="container-fluid">
                <div className="wrapper">

                    <div className="row">
                        <div className="col-md-6">
                            <div className={styles.driveContent}>
                                <ReactPlaceholder type='text' rows={1} ready={!brandData.isLoading} showLoadingAnimation={true}>
                                    <h5>{brandData.data?.field_top_title}</h5>
                                </ReactPlaceholder>
                                <ReactPlaceholder type='text' rows={1} ready={!brandData.isLoading} showLoadingAnimation={true} style={{ backgroundColor: '#383f4e' }}>
                                    <h1>{brandData.data?.field_title}</h1>
                                </ReactPlaceholder>
                                <ReactPlaceholder type='text' rows={5} ready={!brandData.isLoading} showLoadingAnimation={true}>
                                    <p>{brandData.data?.field_description}</p>
                                </ReactPlaceholder>
                                <div className={styles.groupBtn}>
                                    <ReactPlaceholder type='rect' style={{ backgroundColor: '#383f4e' }} ready={!brandData.isLoading} showLoadingAnimation={true}>
                                        <div className={styles.bgTwo}>
                                            <Link href="/case-studies-1"><a className={styles.btn}>{brandData.data?.field_cta_button_text} </a></Link>
                                        </div>
                                    </ReactPlaceholder>
                                    <ReactPlaceholder type='text' rows={1} style={{ backgroundColor: '#383f4e' }} ready={!brandData.isLoading} className="placeholder-home-brand-view-case" showLoadingAnimation={true}>
                                        <div className={`${styles.viewCase} amd-yellow-arrow`}>
                                            <Link href="/case-studies-list"><a className={styles.case} rel="noopener noreferrer"> {brandData.data?.field_cta_arrow_text}</a></Link>
                                        </div>
                                    </ReactPlaceholder>
                                </div>
                            </div>
                        </div>
                        <div className={`${styles.absshowmore} col-md-6`}>
                            <div ref={rightSectionRef} className={styles.servicesContent}>
                                <div className={styles.leads}>
                                    <ReactPlaceholder type='rect' ready={!brandData.isLoading} className='placeholder-rect-home-brandbannder' showLoadingAnimation={true} style={{ minHeight: 320, maxWidth: 240 }}>
                                        <picture className={styles.leadsImages}>
                                            <source media="(max-width: 767px)" srcSet={brandData.data?.field_mobile_image} height={311} width={470} />
                                            <img
                                                effect="blur"
                                                src={brandData.data?.field_desktop_image}
                                                style={{ minHeight: 320 }}
                                                alt="ameex" />
                                        </picture>
                                    </ReactPlaceholder>
                                </div>

                                <div className={`${styles.consumer} ${styles.consumerLarge}`}>
                                    {brandData.isLoading ? (
                                        <div className="placeholder-consumer"></div>
                                    ) : (
                                        <></>
                                    )
                                    }
                                    <div className={styles.titleIcon} onClick={loadMoreBrand}><span className={styles.title}>Testimonial</span><span className={`${styles.icon} ${brandShow ? `${styles.active}` : ''}`}></span></div>
                                    <div className={`${styles.showmoreCont} ${brandShow ? `${styles.active}` : ''}`}>
                                        <ReactPlaceholder type='text' rows={6} ready={!brandData.isLoading} showLoadingAnimation={true}>
                                            <p>{brandData?.data?.field_testimonial_export?.[0]?.description}</p>
                                        </ReactPlaceholder>
                                        <p>
                                            <><ReactPlaceholder type='text' rows={1} ready={!brandData.isLoading} showLoadingAnimation={true}>
                                                <><b>{brandData?.data?.field_testimonial_export?.[0]?.author_name}</b><br /></>
                                            </ReactPlaceholder><br /></>
                                            <ReactPlaceholder type='text' rows={1} ready={!brandData.isLoading} showLoadingAnimation={true}>
                                                <span>{brandData?.data?.field_testimonial_export?.[0]?.author_rolw}</span>
                                            </ReactPlaceholder>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className={`${styles.consumer} ${styles.consumerMobile}`}>
                        {brandData.isLoading ? (
                            <div className="placeholder-consumer"></div>
                        ) : (
                            <></>
                        )
                        }
                        <div className={styles.titleIcon} onClick={loadMoreBrand}><span className={styles.title}>Testimonial</span><span className={`${styles.icon} ${brandShow ? `${styles.active}` : ''}`}></span></div>
                        <div className={`${styles.showmoreCont} ${brandShow ? `${styles.active}` : ''}`}>
                            <ReactPlaceholder type='text' rows={6} ready={!brandData.isLoading} showLoadingAnimation={true}>
                                <p>{brandData?.data?.field_testimonial_export?.[0]?.description}</p>
                            </ReactPlaceholder>
                            <p>
                                <><ReactPlaceholder type='text' rows={1} ready={!brandData.isLoading} showLoadingAnimation={true}>
                                    <><b>{brandData?.data?.field_testimonial_export?.[0]?.author_name}</b><br /></>
                                </ReactPlaceholder><br /></>
                                <ReactPlaceholder type='text' rows={1} ready={!brandData.isLoading} showLoadingAnimation={true}>
                                    <span>{brandData?.data?.field_testimonial_export?.[0]?.author_rolw}</span>
                                </ReactPlaceholder>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    )
}
export default HomeBrand;