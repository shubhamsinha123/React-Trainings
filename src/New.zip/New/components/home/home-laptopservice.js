import React from "react";
import gsap from "gsap";
import { Tween } from "react-gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";
import { LazyLoadComponent } from "react-lazy-load-image-component";
import ReactPlaceholder from "react-placeholder";
import { getlaptopservice } from "../../services/insights.service";
import Link from "next/link";
const currentFrame = (index) => `/assets/images/laptop/laptop_${index + 1}.png`;
class HomeLaptopService extends React.Component {
  constructor(probs) {
    super(probs);
    this.state = {
      Digital_iconsbanner: [],
      Digital_iconsbanner_field_icons: [],
      laptopanimation_start: false,
      laptopservice_start: 0,
      laptopMovingPos: 0,
      isLoading: true,
    };
    this.boundRef = React.createRef();
    this.videoRef = React.createRef();
    this.laptopOverlayRef = React.createRef();
    this.sectionRef = React.createRef();
    this.serviceImageRef = React.createRef();
  }
  componentDidMount() {
    this.getlaptopservice();
    if (window?.innerWidth > 1023) {

      this.registerScrollAnimation();
    }
  }

  getlaptopservice() {
    if (this.props.data) {
      this.setState(
        {
          Digital_iconsbanner: this.props.data,
          Digital_iconsbanner_field_icons: this.props.data?.field_icons,
        },
        () => {
          this.setState({ isLoading: false });
        }
      );
    } else {
      getlaptopservice()
        .then((result) => {
          this.setState(
            {
              Digital_iconsbanner: result,
              Digital_iconsbanner_field_icons: result?.field_icons, // correct second array don't remove
            },
            () => {
              this.setState({
                isLoading: false,
              });
            }
          );
        })
        .catch((error) => { });
    }
  }
  registerScrollAnimation = () => {
    gsap.registerPlugin(ScrollTrigger);
    const bound = this.boundRef?.current;
    const canvas = this.videoRef?.current;
    const overlay = this.laptopOverlayRef?.current;

    const context = canvas.getContext("2d");
    canvas.width = 1096;
    canvas.height = 657;

    if (overlay) {
      overlay.style.opacity = 0;
    }
    const frameCount = 111;
    const laptop = {
      frame: 0,
    };

    const images = [];
    for (let i = 0; i < frameCount; i++) {
      const img = new Image();
      img.src = currentFrame(i);
      images.push(img);
    }

    // setTimeout(() => {
    //   images?.forEach((im, i) => {
    //     let newImage = new Image();
    //     newImage.src = currentFrame(i);
    //     window[currentFrame(i)] = newImage;
    //   });
    // }, 1000);


    gsap.to(laptop, {
      frame: frameCount - 1,
      snap: "frame",
      scrollTrigger: {
        scrub: 0.5,
        trigger: bound,
        pin: bound,
        start: "center center",
        end: "+=1000",
      },
      onUpdate: () => {
        context.clearRect(0, 0, canvas.width, canvas.height);
        context.drawImage(images[laptop.frame], 0, 0);

        if (laptop.frame >= 105) {
          overlay.style.opacity = 1;
          if (100 - laptop.frame > 0) {
            overlay.style.transform = `rotateX(${100 - laptop.frame}deg)`;
          }
        } else {
          overlay.style.opacity = 0;
          overlay.style.transformOrigin = "bottom";
        }
      },
    });
  };

  render() {
    return (
      <section
        ref={this.boundRef}
        className="services services-static laptop-screen-one"
        id="laptop-screen-one"
      >
        <div className="container-fluid" id="laptop-screen-two">
          <div className="wrapper">
            <div className="row">
              <div className="col-md-12 video-static">
                <div className="laptop" id="laptop-screen-three">
                  <ReactPlaceholder
                    type="rect"
                    ready={!this.state.isLoading}
                    showLoadingAnimation={true}
                    className="placeholder-rect-home-laptopservice"
                  >
                    <Tween
                      from={{
                        y: "300px",
                        scale: 0.85,
                      }}
                      to={{
                        y: "80px",
                        scale: 0.65,
                      }}
                      scrollTrigger={{
                        scrub: 0.5,
                        trigger: this.boundRef?.current,
                        start: "center center",
                        end: "+=600",
                      }}
                    >
                      <h1 className="service-image-desktop">SERVICES</h1>
                    </Tween>
                    <h1
                      ref={this.serviceImageRef}
                      className="service-images-static"
                      style={{
                        color: "#000",
                        fontSize: "4em",
                        textAlign: "center",
                        fontFamily: "hindbold",
                        fontWeight: "bold",
                        letterSpacing: "2.3px",
                      }}
                    >
                      SERVICES
                    </h1>
                  </ReactPlaceholder>

                  <div
                    className="laptop-video-wrapper"
                    style={{ position: "relative" }}
                  >
                    <div
                      className="laptop-video-content"
                      style={{
                        transform: "scale(.92) translateY(-20px)",
                        position: "absolute",
                        width: "100%",
                        margin: "0 auto",
                      }}
                    >
                      <canvas ref={this.videoRef} />
                    </div>
                  </div>
                  <div
                    className="services-icon-content services-static-icon-content"
                    id="services-static-icon-content"
                  >
                    <div
                      ref={this.laptopOverlayRef}
                      className="services-static-content-blog"
                    >
                      <div className="row services-icons-list-desktop">
                        {this.state.Digital_iconsbanner_field_icons.map(
                          (iconsdet, index) => (
                            <div className="col-md-3 col-6" key={index}>
                              <div className="startegy-content">
                                <Link  href={iconsdet.icon_url}>
                                  <a 
                                  className="stcont-imghover"
                                  onMouseOver={(e) =>
                                  (e.currentTarget.querySelector("img").src =
                                    iconsdet.icon_hover_image)
                                  }
                                  onMouseOut={(e) =>
                                  (e.currentTarget.querySelector("img").src =
                                    iconsdet.icon_image)
                                  }
                                >
                                  <LazyLoadComponent>
                                    <picture className="laptop-images-static">
                                      <source
                                        media="(max-width: 767px)"
                                        srcSet={iconsdet.icon_image}
                                      />
                                      <img
                                        className=""
                                        src={iconsdet.icon_image}
                                        alt="ameex"
                                        loading="lazy"
                                      />
                                    </picture>
                                  </LazyLoadComponent>
                                  <p
                                    dangerouslySetInnerHTML={{
                                      __html: iconsdet.icon_text,
                                    }}
                                  />
                                </a>
                                </Link>
                              </div>
                            </div>
                          )
                        )}
                      </div>
                      <div className="services-icons-list">
                        {this.state.Digital_iconsbanner_field_icons.map(
                          (iconsdet, index) => (
                            <div
                              className="services-icon-list-item"
                              key={index}
                            >
                              <div className="startegy-content">
                                <Link href={iconsdet.icon_url}>
                                <a
                                  className="stcont-imghover"
                                  onMouseOver={(e) =>
                                  (e.currentTarget.querySelector("img").src =
                                    iconsdet.icon_hover_image)
                                  }
                                  onMouseOut={(e) =>
                                  (e.currentTarget.querySelector("img").src =
                                    iconsdet.icon_image)
                                  }
                                >
                                  <LazyLoadComponent>
                                    <picture className="laptop-images-static">
                                      <source
                                        media="(max-width: 767px)"
                                        srcSet={iconsdet.icon_image}
                                      />
                                      <img
                                        className=""
                                        src={iconsdet.icon_image}
                                        alt="ameex"
                                        loading="lazy"
                                      />
                                    </picture>
                                  </LazyLoadComponent>
                                  <p
                                    dangerouslySetInnerHTML={{
                                      __html: iconsdet.icon_text,
                                    }}
                                  />
                                </a>
                                </Link>
                              </div>
                            </div>
                          )
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  }
}
export default HomeLaptopService;