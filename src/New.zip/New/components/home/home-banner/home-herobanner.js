import React, { useEffect } from 'react';
import Link from "next/link";
import Image from 'next/image';
import ReactPlaceholder from 'react-placeholder';
import "react-placeholder/lib/reactPlaceholder.css";
import { Parallax as ScrollParallax } from 'react-scroll-parallax';
import { isMobile } from 'react-device-detect';
import gsap from 'gsap';
import { Tween } from 'react-gsap';
import HomeBstyle from './heroBanner.module.scss';
import { ScrollTrigger } from 'gsap/dist/ScrollTrigger';
import { getHomeHeroBanner } from '../../../services/insights.service';
import { useQuery } from 'react-query'
let Parallax = ScrollParallax;
if (isMobile) {
    Parallax = ({ children }) => <React.Fragment>{children}</React.Fragment>;
}
const HomeHeroBanner = (props) => {
    const sectionRef = React.createRef(null);
    const bannerData = useQuery('homepage-HeroBanner', getHomeHeroBanner, {
        initialData: props.data,
        refetchOnMount: false,
        refetchOnWindowFocus: false,
    })
    useEffect(() => {
        if(!props.data?.field_desktop_image) {
            bannerData.refetch();
        }
        var bodyStyles = document.body.style;
                bodyStyles.setProperty('--test', 0);
                window.onscroll = (event) => {
                    bodyStyles.setProperty('--test', -(window.scrollY) + 'px');
                };
        gsap.registerPlugin(ScrollTrigger);
    }, [])
    let data1 = bannerData?.data?.field_title?.split(' (') || [];
            let data2 = '(' + (data1?.[1] || "");
    return (
        <section ref={sectionRef} className={HomeBstyle.headerBaner}>
            <div className="container-fluid">
                <div className="wrapper">
                    <div className="row">
                        <div className="col-md-6">
                            <div className={HomeBstyle.rectangle}>
                                <div className={HomeBstyle.topAir}>
                                    <picture>
                                        <source media="(max-width: 767px)" srcSet={'/assets/images/group.svg'} />
                                        <Image priority src={'/assets/images/group.svg'} alt="ameex" width={100} height={20} />
                                    </picture>
                                </div>
                                <Tween
                                    to={{
                                        y: '-160px'
                                    }}
                                    scrollTrigger={{
                                        scrub: 0.5,
                                        trigger: sectionRef?.current,
                                        start: '+=0',
                                        end: '+=480',
                                    }}
                                >
                                    <div className={HomeBstyle.rectanglesourceImg}>
                                        <ReactPlaceholder type='rect' ready={!bannerData.isFetching} showLoadingAnimation={true} className="placeholder-rect-home-herobanner" style={{ minHeight: '240px', width: '90px', borderRadius: 10, opacity: .5, background: '#333', margin: 'auto' }}>
                                            <picture className={HomeBstyle.rectanglesourceImages}>

                                                <source media="(max-width: 767px)" srcSet={bannerData?.data?.field_mobile_image} />
                                                <img effect="blur" src={bannerData?.data?.field_desktop_image} alt="ameex" />
                                            </picture>
                                        </ReactPlaceholder>
                                    </div>
                                </Tween>
                            </div>
                        </div>
                        <div className={`${HomeBstyle.breakpoint6} col-md-6`}>
                            <div className={HomeBstyle.growyourBrandwith}>
                                <ReactPlaceholder type='text' rows={2} className="placeholder-parent-text-reset" ready={!bannerData.isFetching} showLoadingAnimation={true}>
                                    <h1>

                                        {data1?.[0]}

                                    </h1>
                                </ReactPlaceholder>
                                <ReactPlaceholder type='text' rows={1} className="placeholder-parent-text-reset" ready={!bannerData?.isLoading} showLoadingAnimation={true}>
                                    <h4>

                                        {data2}

                                    </h4>
                                </ReactPlaceholder>

                                <ReactPlaceholder type='text' rows={4} ready={!bannerData.isLoading} showLoadingAnimation={true} className="placeholder-data">
                                    <p>{bannerData?.data.field_description}</p>
                                </ReactPlaceholder>
                                <div className={HomeBstyle.bg}>
                                    <ReactPlaceholder type='rect' ready={!bannerData.isFetching} showLoadingAnimation={true} className="placeholder-hero-bg" style={{ backgroundColor: '#ffda41' }}>
                                        <Link href='/service'>
                                            <a className={HomeBstyle.btn}> {bannerData?.data.field_cta_button_text}</a>
                                        </Link>
                                    </ReactPlaceholder>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    )
}
export default HomeHeroBanner;