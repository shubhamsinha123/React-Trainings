import React from 'react';
import axios from 'axios';
import Link from "next/link";
import { PopupButton } from 'react-calendly';
import { withRouter } from "next/router";
import HeaderMenuSection1 from './header/components/HeaderMenu1';
import HeaderInsight from './header/components/headerMenu2';

class GlobalHeader extends React.Component {
    constructor(probs) {
        super(probs);

        this.onChangeSearchKeyValue = this.onChangeSearchKeyValue.bind(this);
        this.searchkeyupdate = this.searchkeyupdate.bind(this);
        this.onSubmit = this.onSubmit.bind(this);
        this.menutoggle = this.menutoggle.bind(this);
        this.closeMenu = this.closeMenu.bind(this);
        this.state = {
            header_service: [],
            header_ecommerce: [],
            header_digitalmarketingstrategy: [],
            header_searchengine: [],
            header_performance: [],
            header_analytics: [],
            header_uxvisualdesign: [],
            header_digitalmarketingtechnology: [],
            header_insights: [],
            header_insights_node: [],
            header_schedule: [],
            searchkeyvalue: '',
            redirectToReferrer: false,
            insights: [],
            items: [],
            error: false,
            showModal: false,
            modelContent: "",
            videoUrl: ""
        }

    }


    componentDidMount() {
        // window.scrollTo(0, 0);
        if(this.props.data && this.props.data?.length) {
            this.setState({
                header_service: this.props.data?.[1],
                header_ecommerce: this.props.data?.[2],
                header_digitalmarketingstrategy: this.props.data?.[3],
                header_searchengine: this.props.data?.[4],
                header_performance: this.props.data?.[5],
                header_analytics: this.props.data?.[6],
                header_uxvisualdesign: this.props.data?.[7],
                header_digitalmarketingtechnology: this.props.data?.[8],
                header_insights: this.props.data?.[9],
                header_schedule: this.props.data?.[10],
            });
        } else {
            this.getheader();
        }

        var closemenu = document.getElementsByClassName("colsemegamenu");
        for (var i = 0; i < closemenu.length; i++) {
            closemenu[i].addEventListener('click', this.closeMenu, false);
        }

    }
    getheader() {
        axios.get(`${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/header-footer`)
            .then(result => {
                this.setState({
                    headerData: result,
                    header_service: result.data[1],
                    header_ecommerce: result.data[2],
                    header_digitalmarketingstrategy: result.data[3],
                    header_searchengine: result.data[4],
                    header_performance: result.data[5],
                    header_analytics: result.data[6],
                    header_uxvisualdesign: result.data[7],
                    header_digitalmarketingtechnology: result.data[8],
                    header_insights: result.data[9],
                    header_schedule: result.data[10],
                });
            })
            .catch(error => {

            })
        // getAllInsights()

    }
    closeMenu(e) {
        console.log("closemenu");
        if (window.innerWidth < 767) {
            document.getElementById("navbar-toggler").setAttribute("aria-expanded", "false");
            document.getElementById("navbarCollapse").classList.remove("show");
            document.body.style.overflow = "visible";
        }
        document.getElementById("navbar-toggler").setAttribute("aria-expanded", "false");
        document.getElementById("navbarCollapse").classList.remove("show");
        document.getElementById("global-header").setAttribute("aria-expanded", "false");
        document.body.style.overflow = "visible";

    }
    menutoggle(e) {
        if (document.getElementById("navbar-toggler").getAttribute("aria-expanded") === "false") {
            console.log("false")
            document.getElementById("navbar-toggler").setAttribute("aria-expanded", "true");
            document.getElementById("navbarCollapse").classList.add("show");
            document.getElementById("global-header").setAttribute("aria-expanded", "true");
            document.body.style.overflow = "hidden";
        } else {
            console.log("true");
            document.getElementById("navbar-toggler").setAttribute("aria-expanded", "false");
            document.getElementById("navbarCollapse").classList.remove("show");
            document.getElementById("global-header").setAttribute("aria-expanded", "false");
            document.body.style.overflow = "visible";
        }
    }

    onChangeSearchKeyValue(e) {
        this.setState({ searchkeyvalue: e.target.value })

    }
    searchkeyupdate(event) {
        event.preventDefault();
        const searchvalue = this.state.searchkeyvalue;
        console.log(searchvalue);
        if (this.state.searchkeyvalue !== "") {
            console.log("not empty");
            this.props.router.push('/searchresult/' + this.state.searchkeyvalue);
            window.location.assign('/searchresult/' + this.state.searchkeyvalue);
            // window.location.href = '/searchresult/' + this.state.searchkeyvalue;

        }
    }
    onSubmit(event) {
        event.preventDefault();

        if (this.state.searchkeyvalue !== "") {
            this.props.router.push('/searchresult/' + this.state.searchkeyvalue);
        }
    }


    render() {

        return (
            <header>
                <div className="global-header" id="global-header" aria-expanded="false">
                    <div className="container-fluid">
                        <div className="wrapper">
                            <div className="header-inner">
                                <a href='/'>
                                    <picture> <img alt="logo" title="logo" className="logo" src="/assets/images/logo.png" width={181} height={17} /> </picture>
                                </a>
                                {/* </Link> */}
                                <button className="navbar-toggler" id="navbar-toggler" onClick={this.menutoggle} type="button" data-toggle="collapse" data-target="/#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation"> <span className="navbar-toggler-icon amd-hamburger"></span> <span className="navbar-close-icon"></span> <span className="search-icon amd-search"></span> </button>
                                <nav className="navbar navbar-expand-md navbar-dark lazynav">
                                    <div className="collapse navbar-collapse" id="navbarCollapse">
                                        <form className="form-inline mt-2 mt-md-0 form-inner-wrapper" autoComplete="off" onSubmit={this.onSubmit}>
                                            <div className="form-inner">
                                                <input className="form-control search-box mr-sm-2" type="text" placeholder="Search" aria-label="Search" name="searchkeyvalue" value={this.state.searchkeyvalue} onChange={this.onChangeSearchKeyValue} />
                                                <button className="btn  search-btn amd-search my-2 my-sm-0 colsemegamenu" type="submit" onClick={this.searchkeyupdate}></button>
                                            </div>
                                        </form>
                                        <div className="megamenu-wrapper colsemegamenu-dektop">
                                            <div className="row">
                                                <div className="col-md-4">
                                                    <HeaderMenuSection1 closeMenu={this.closeMenu} data={this.state} />
                                                </div>
                                                <div className="col-md-4">
                                                    <HeaderInsight data={this.props.data} allInsights={this.props.allInsights} />
                                                </div>
                                                <div className="col-md-4">
                                                    <div className="megamenu-inner megamenu-arrow-link">
                                                        <ul className="navbar-nav ">
                                                            <li className="nav-item head megamenu-bg"> <Link href="/case-studies-list" scroll={false}><a className="nav-link head-link arrow-link colsemegamenu amd-yellow-arrow"><span className="menu-font">{this.state.header_schedule.field_name}</span></a></Link> </li>
                                                            <li className="nav-item head megamenu-bg"> <Link href="/insights" scroll={false}><a className="nav-link head-link arrow-link colsemegamenu amd-yellow-arrow" ><span className="menu-font">{this.state.header_insights.name}</span></a></Link> </li>
                                                            <li className="nav-item head megamenu-bg"> <Link href="/about-us" scroll={false}><a className="nav-link head-link arrow-link colsemegamenu amd-yellow-arrow" ><span className="menu-font">{this.state.header_schedule.field_read_more_text}</span></a></Link> </li>
                                                            <li className="nav-item head megamenu-bg"> <Link href="/contact-us" scroll={false}><a className="nav-link head-link arrow-link colsemegamenu amd-yellow-arrow"><span className="menu-font">{this.state.header_schedule.field_watch_vide_text}</span></a></Link> </li>
                                                            <li className="nav-item megamenu-bg shedulecall-wrapper"> <a className="nav-link shedulecall"><span className="img amd-calendly"></span>
                                                                {/* <span className="cont">{this.state.header_schedule.name}</span> */}
                                                                <PopupButton
                                                                    className="cont colsemegamenu"
                                                                    text="SCHEDULE A CALL"
                                                                    url="https://calendly.com/ameexdigital/schedule-meeting-with-ameex-digital-team"
                                                                />
                                                            </a> </li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="row justify-content-between digital-marketing-strategy-wrapper">
                                                <div className="col-md-4">
                                                    <div className="strategy">
                                                        <div className="row">
                                                            <div className="col-8 col-md-7 strategy-text-wrapper">
                                                                <div className="strategy-text">CALCULATE YOUR MONTHLY DMAAS STRATEGY</div>
                                                            </div>
                                                            <div className="col-4 col-md-5 strategy-img-wrapper">
                                                                <a href="/#" className="strategy-img colsemegamenu"><span></span></a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="col-md-4 digital-marketing">
                                                    <div className="dgtmrktsrvcs">digital marketing services</div>
                                                </div>
                                            </div>
                                            <div className="row">
                                                <div className="col-10 col-lg-8 margin-x-auto social-icons-wrapper">
                                                    <div className="social-icons">
                                                        <a href="https://www.youtube.com/channel/UC5sHd3vyJISHaTFLx8Vvmyg" className="video colsemegamenu amd-youtube" target="_blank"><span></span></a>
                                                        <a href="https://twitter.com/AmeexDigital" className="twitter colsemegamenu amd-twitter" target="_blank"><span></span></a>
                                                        <a href="https://www.facebook.com/Ameex_Digital-101893662036320" className="facebook colsemegamenu amd-facebook" target="_blank"><span></span></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
        );
    }
}
export default withRouter(GlobalHeader);