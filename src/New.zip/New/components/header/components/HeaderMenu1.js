import React, { useState } from 'react';
import Link from "next/link";

const serviceModules = [
  {
    position: 1,
    href: '/ecommerce',
    moduleName: 'header_ecommerce',
    className: 'ecommerce'
  },
  {
    position: 2,
    href: '/digital-marketing-strategy',
    moduleName: 'header_digitalmarketingstrategy',
    className: 'share-icon'
  },
  {
    position: 3,
    href: '/search-engine-optimization',
    moduleName: 'header_searchengine',
    className: 'search-engine'
  },
  {
    position: 4,
    href: '/performance-marketing',
    moduleName: 'header_performance',
    className: 'performance'
  },
  {
    position: 5,
    href: '/analytics',
    moduleName: 'header_analytics',
    className: 'analytics'
  },
  {
    position: 6,
    href: '/ux-ui-visual-design',
    moduleName: 'header_uxvisualdesign',
    className: 'uiux'
  },
  {
    position: 7,
    href: '/digital-marketing-technology',
    moduleName: 'header_digitalmarketingtechnology',
    className: 'digital'
  },
]

const HeaderMenuSection1 = ({ data={}, closeMenu }) => {
  const [activeServiceIcon, setActiveServiceIcon] = useState()

  const megamenutoggle = (e) => {
    if (window.innerWidth < 767) {
      if (document.getElementById("has-megamenu").classList.contains('show')) {
        document.getElementById("has-megamenu").classList.remove("show");
        document.getElementById("dropdownmegamenu").classList.remove("show");
      } else {
        document.getElementById("has-megamenu").classList.add("show");
        document.getElementById("dropdownmegamenu").classList.add("show");
      }
    }
  }

  const onTouchStart = (e, module, pos) => {
    e.currentTarget.querySelector('source').srcset = data[module]?.field_menu_image_hover; //data.header_ecommerce.field_menu_image_hover;
    e.currentTarget.querySelector('img').src = data[module]?.field_menu_image_hover; //data.header_ecommerce.field_menu_image_hover;
    console.log(e.currentTarget.querySelector('img'));
    setActiveServiceIcon(pos)
  }

  const onTouchEnd = (e, module) => {
    e.currentTarget.querySelector('source').srcset = data[module]?.field_menu_image; //data.header_ecommerce.field_menu_image;
    e.currentTarget.querySelector('img').src = data[module]?.field_menu_image; //data.header_ecommerce.field_menu_image;
    setActiveServiceIcon()
  }

  const ListItem = ({ moduleName, href, className, position, activeIndex }) => {
    return (
      <li className="nav-item" key={position}
      onMouseOver={e => e.currentTarget.querySelector('img').src = data[moduleName]?.field_menu_image_hover}
      onMouseOut={e => e.currentTarget.querySelector('img').src = data[moduleName]?.field_menu_image}
      onTouchStart={e => onTouchStart(e, moduleName, position)}
      onTouchEnd={e => onTouchEnd(e, moduleName)}
      >
        <Link href={href} scroll={true}
        >
          <a className={`nav-link colsemegamenu ${activeIndex === position ? 'active' : ''}`} onClick={closeMenu}>
            <span className={`label ${className}`}>
              <picture className="services-icons">
                <source media="(max-width: 767px)" srcSet={data[moduleName]?.field_menu_image} />
                <img src={data[moduleName]?.field_menu_image} alt="ameex" loading="lazy" />
              </picture>
              <span className="link-cont" dangerouslySetInnerHTML={{ __html: data[moduleName]?.name }}></span>
            </span>
          </a>
        </Link>
      </li>
    )
  }

  return (
    <div className="megamenu-inner megamenu-bg">
      <ul className="navbar-nav">
        <li className="nav-item dropdown has-megamenu head" id="has-megamenu" >
          <div className="desktop-menu-service"><Link href="/service" target="blank"><a className="colsemegamenu nav-link head-link">{data.header_service.name}</a></Link></div>
          <div className="mobile-menu-service"><Link href="/service" target="blank"><a><span className="colsemegamenu nav-link head-link" data-toggle="dropdown">{data.header_service.name}</span></a></Link>
            <span className="dropdown-toggle" onClick={megamenutoggle}> </span></div>
          <div className="dropdown-menu megamenu" id="dropdownmegamenu">
            <ul>
              {
                serviceModules.map((listObj) => <ListItem key={listObj.position} {...listObj} activeIndex={activeServiceIcon} />)
              }
            </ul>
            <Link href="/service" scroll={true}><a className="menu-service arrow-link amd-yellow-arrow colsemegamenu arrow-dropdown"><span className="menu-font">Services</span></a></Link>
          </div>
        </li>
      </ul>
    </div>

  )
}

export default HeaderMenuSection1;
