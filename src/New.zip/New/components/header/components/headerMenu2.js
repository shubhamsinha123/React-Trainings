import React, { useEffect, useState } from "react"
import { useQuery } from "react-query"
import Link from "next/link"
import VideoModal from "../../common/VideoModal/VideoModal"
import { getAllInsights } from "../../../services/insights.service"
const getDataPromise = (url, options) => {
    return new Promise((resolve, reject) => {
        fetch(url)
            .then(res => res.json())
            .then(result => {
                if (options.list) {
                    if (options.firstItem && Array.isArray(result) && result.length) {
                        resolve(result || [])
                    }
                } else {
                    resolve(result)
                }
            })
            .catch(e => {
                reject(e)
            })
    })
}
export const getFooterComp = () => {
    const url = `${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/header-footer`;
    return getDataPromise(url, {
        list: true,
        firstItem: true
    })
}
const HeaderInsight = (props) => {
    const headerInsights = useQuery('header-insight', getFooterComp, {
        initialData: props.data || {},
        refetchOnMount: false,
        refetchOnWindowFocus: false,
    })
    const allInsights = useQuery('all-insights', getAllInsights, {
        initialData: props.allInsights || [],
        refetchOnMount: false,
        refetchOnWindowFocus: false,
        select: (resdata) => {
            var filteryt = resdata.filter(function (obj) {
                return obj.field_watch_video_link.includes("youtube");
            });

            return {    
                insights: resdata[0] || [],
                header_insights_node: filteryt[0] || [],
            }
        },
    })
    const [videoContent, setVideoContent] = useState({})

    useEffect(() => {
        if(!props.data?.length) {
            headerInsights.refetch();
        }
        if(!props.allInsights?.length) {
            allInsights.refetch();
        }
    }, [])

    const handleOpenModal = (title_head, url_video) => {
        setVideoContent({
            title: title_head,
            url: url_video
        })
    }

    const handleCloseModal = () => {
        setVideoContent({})
    }
    console.log(allInsights?.data?.header_insights_node?.view_node)
    return (

            <div className="megamenu-inner megamenu-bg megamenu-insights">
                <ul className="navbar-nav">
                    <li className="nav-item has-megamenu head"> <Link href="/insights"><a className="nav-link head-link colsemegamenu">{headerInsights?.data?.[9]?.name}</a></Link>
                        <div className="dropdown-menu megamenu">
                            <div className="insights-wrapper">
                                <div className="insights-inner">
                                    <div className="insights-video-wrapper">

                                        <img src={allInsights?.data?.header_insights_node?.field_video_thumbnail_image} className="header-image-responsive" loading="lazy" />
                                        <a onClick={() => handleOpenModal(allInsights?.data?.header_insights_node?.title, allInsights?.data?.header_insights_node?.field_watch_video_link)} href="#">
                                            <span className="header-play-btn"></span>
                                        </a>
                                    </div>
                                    <div className="main-insights-megamenu">
                                        <div className="header-videomodal">
                                            <VideoModal
                                                show={videoContent.url}
                                                onClose={handleCloseModal}
                                                url={videoContent.url}
                                                title={videoContent.title}
                                                backLink='Back to page'
                                            />
                                        </div>
                                        <div className="insights-cont">
                                            <a href={`${allInsights?.data?.header_insights_node?.view_node}`} className="colsemegamenu article-title">{allInsights?.data?.header_insights_node?.title}</a>
                                            <p>{allInsights?.data?.header_insights_node?.field_insight_description}</p>
                                            <div className="row">
                                                <div className="col-6"> <a href={`${allInsights?.data?.header_insights_node?.view_node}`} className="read-article colsemegamenu">{allInsights?.data?.header_insights_node?.field_read_more_text}</a></div>
                                                <div className="col-6"> <a href="#" onClick={() => handleOpenModal(allInsights?.data?.header_insights_node?.title, allInsights?.data?.header_insights_node?.field_watch_video_link)} className="watch-ideo">{allInsights?.data?.header_insights_node?.field_wa}</a> </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="insights-barchat-wrapper">
                                        <a href="/#" className="insights-barchat-inner colsemegamenu">
                                            <div className="row">
                                                <div className="col-8">
                                                    <div className="insights-barchat-des"><a href={`${allInsights?.data?.insights?.view_node}`} style={{ textDecoration: "none" }}>{allInsights?.data?.insights?.title}</a></div>
                                                </div>
                                                <div className="col-4">
                                                    <div className="insights-barchat"> </div>
                                                </div>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <Link href="/insights" scroll={true}><a className="arrow-link inshight-arrow amd-yellow-arrow colsemegamenu"><span className="menu-font">{headerInsights?.data?.[9]?.field_button_redirect_text}</span></a></Link> </div>
                    </li>
                </ul>
            </div>
    )
}
export default HeaderInsight