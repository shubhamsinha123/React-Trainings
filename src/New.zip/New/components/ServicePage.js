import React from 'react';
import MonthlyBudget from '../components/common/monthlyBudget/monthlybudget';
import ReactPlaceholder from 'react-placeholder'
import "react-placeholder/lib/reactPlaceholder.css";
import 'react-lazy-load-image-component/src/effects/blur.css';
import { LazyLoadImage } from 'react-lazy-load-image-component';
import parse from 'html-react-parser';
import MetaDecorator from './Util/MetaDecorator';
import Schema from '../components/Util/Schema';



class ServicePage extends React.Component {
    constructor(probs) {
        super(probs);
        const state = {
            visibleTab: "",
            visibleTab_classname: "visibleTab-0",
            dropdownlistopenul: false,
        }
        this.state = state;
    }
    componentDidMount() {
        window.scrollTo(0, 0);
        // this.getlisting1result();
        this.setState({
            visibleTab: "0",
        })
    }

    setVisibleTab(ix, name, event) {
        this.setState({
            visibleTab: this.props.field_service_detail_collection_export[ix].tab_id,
        });

        if (ix === "0") {
            this.setState({
                visibleTab_classname: "visibleTab-0"
            });
        } else if (ix === "1") {
            this.setState({
                visibleTab_classname: "visibleTab-1"
            });
        } else if (ix === "2") {
            this.setState({
                visibleTab_classname: "visibleTab-2"
            });
        } else if (ix === "3") {
            this.setState({
                visibleTab_classname: "visibleTab-3"
            });
        } else if (ix === "4") {
            this.setState({
                visibleTab_classname: "visibleTab-4"
            });
        } else if (ix === "5") {
            this.setState({
                visibleTab_classname: "visibleTab-5"
            });
        } else if (ix === "6") {
            this.setState({
                visibleTab_classname: "visibleTab-6"
            });
        } else {
            this.setState({
                visibleTab_classname: ""
            });
        }
        if (window.innerWidth <= 767) {
            event.currentTarget.parentElement.parentElement.querySelector("span.dropdown").innerHTML = name;
            this.setState({
                dropdownlistopenul: false,
            });
        }
        if (window.innerWidth <= 1024 && window.innerWidth >= 767) {
            event.currentTarget.parentElement.parentElement.querySelector("span.dropdown").innerHTML = name;
            this.setState({
                dropdownlistopenul: false,
            });
        }
    }
    dropdownlistopen() {
        this.setState({
            dropdownlistopenul: !this.state.dropdownlistopenul,
        });
    }
    render() {
        const { pageClass } = this.props || {};
        return (
            <>
             <MetaDecorator
                    description={parse(this.props.servicedetails?.field_meta_description || '')}
                    title={parse(this.props.servicedetails?.field_meta_title || '')}
                    href={this.props.servicedetails.field_meta_canonical_url}
                />
            {
                this.props.servicedetails && this.props.servicedetails.field_schema_types_export?.map((data) =>
                    <Schema data={JSON.parse(data.body)} />
                )
            }
            <section className="service-detail">

                <section className="details-visuval-design">
                    <div className="container-fluid">
                        <div className="wrapper">
                            <div className="row">
                                <div className="col-md-4">
                                    <div className="visuval-details-content">
                                        <div className="visuval-details-content-sub">
                                            {this.props.isLoading ? (
                                                <span className={`hero-title ${pageClass}`}>
                                                    <ReactPlaceholder type="rect" ready={false} style={{ width: "400px", height: "20px", marginTop: "10px", padding: "20px" }} showLoadingAnimation={true}></ReactPlaceholder>
                                                    <ReactPlaceholder type="rect" ready={false} style={{ width: "80%", height: "20px", padding: "20px", marginTop: "10px" }} showLoadingAnimation={true}></ReactPlaceholder>
                                                </span>
                                            ) : (
                                                <h1 className={`hero-title ${pageClass}`}>

                                                    <span dangerouslySetInnerHTML={{ __html: this.props.servicedetails.title }}></span>

                                                </h1>
                                            )}

                                            <ReactPlaceholder type="text" rows={8} ready={!this.props.isLoading} style={{ marginTop: "18px" }} showLoadingAnimation={true}>
                                                <div className = "service-p-wrapper">
                                                    <p>
                                                    {this.props.servicedetails.body}
                                                </p>
                                                {this.props.servicedetails.field_body == "" ? (null) : <p>{this.props.servicedetails.field_body}
                                                </p>
                                                }
                                                </div>
                                            </ReactPlaceholder>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-md-7 offset-md-1">
                                    <div className="air-icon">
                                        <ReactPlaceholder type="rect" ready={!this.props.isLoading} showLoadingAnimation={true} className="details-airicon-placeholder">
                                            <picture>
                                                <source media="(max-width:767px)" srcSet={'/assets/images/icons/air-icon.png'} />
                                                <img src={'/assets/images/icons/air-icon.png'} alt="" />
                                            </picture>
                                        </ReactPlaceholder>
                                    </div>
                                    <div className="right-side-visuval-img">
                                        <ReactPlaceholder className="placeholder-sd-image-first placeholder-rect-home-herobanner" type='rect' style={{ borderRadius: "10px", height: "98%" }} ready={!this.props.isLoading} showLoadingAnimation={true}>

                                            <picture>
                                                <source media="(max-width:767px)" srcSet={this.props.servicedetails.field_service_detail_mobile_imag} />
                                                <LazyLoadImage effect="blur" src={this.props.servicedetails.field_service_category_image} alt="ameex" />
                                            </picture>

                                        </ReactPlaceholder>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section className="clear-content details-clear-content">
                    <div className="wrapper">

                        <ReactPlaceholder type='rect' style={{ width: "70%", height: "100px", margin: "auto" }} ready={!this.props.isLoading} showLoadingAnimation={true}>

                            <div className="alert-messages">
                                <div className="alert-content">

                                    {/* <h4>INDUSTRY <br/>
                                    INTEL</h4> */}
                                    <h4>

                                        <span>{this.props.servicedetails.field_intel_label}</span>
                                    </h4>
                                </div>
                                <div className="alert-img alert-content">

                                    <picture>
                                        <source media="(max-width:767px)" srcSet={this.props.servicedetails.field_intel_mobile_icon} />
                                        {/* <img src={this.props.servicedetails.field_intel_icon} alt="" /> */}
                                        <LazyLoadImage effect="blur" src={this.props.servicedetails.field_intel_icon} alt="ameex" />
                                    </picture>
                                </div>
                                <div className="alert-content bottom-alert-content">
                                    <p>
                                        {this.props.servicedetails.field_intel_description}
                                        <small className="cl-name"dangerouslySetInnerHTML={{ __html: this.props.servicedetails.field_intel_description_name }}></small>
                                    </p>
                                    {/* <small className="cl-name author">{this.props.servicedetails.field_intel_description_name}</small> */}
                                </div>
                            </div>
                        </ReactPlaceholder>

                    </div>
                </section>
                <section className="details-benefits-design">
                    <div className="container-fluid">
                        <div className="wrapper">
                            <div className="row">
                                <div className="col-md-3">
                                    <div className="profile-img-wrapper">
                                        <ReactPlaceholder type='round' className="logo-placeholder-image" ready={!this.props.isLoading} showLoadingAnimation={true}>
                                            <picture>
                                                <source media="(max-width:767px)" srcSet={this.props.servicedetails.field_reviewer_mobile_image} />
                                                <LazyLoadImage effect="blur" src={this.props.servicedetails.field_reviewer_desktop_image} alt="" />
                                            </picture>
                                        </ReactPlaceholder>
                                    </div>

                                </div>
                                <div className="col-md-7">
                                    <div className="profile-img-details-wrapper">
                                        <div className="profile-name-roll">

                                            <ReactPlaceholder type='text' rows={1} ready={!this.props.isLoading} showLoadingAnimation={true}>
                                                <span className="profile-name">
                                                    {
                                                        this.props.servicedetails.field_reviewer_title
                                                    }
                                                    {/* <p>,</p>   */}
                                                    , </span>
                                            </ReactPlaceholder>
                                            <span className="profile-roll">

                                                <ReactPlaceholder type='text' rows={1} ready={!this.props.isLoading} showLoadingAnimation={true}>
                                                    {
                                                        this.props.servicedetails.field_reviewer_sub_title
                                                    }
                                                </ReactPlaceholder>
                                            </span>

                                        </div>
                                        <div className="profile-desc">

                                            <ReactPlaceholder type='text' rows={3} ready={!this.props.isLoading} showLoadingAnimation={true}>

                                                <p>{this.props.servicedetails.field_reviewer_description}</p>
                                            </ReactPlaceholder>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section className="e-commerce-design-u details-e-commerce-design-u">
                    <div className="container-fluid">
                        <div className="wrapper">
                            <div className="row">
                                <div className="col-md-3 e-commerce-left-side-content-wrapper">
                                    <div className="e-commerce-left-side-content">
                                        <div className={`e-commerce-left-headlinks ${pageClass}`}>{this.props.servicedetails.title}</div>
                                        <div className="dropdownlist-wrapper-details">
                                            <div className="dropdown_list">
                                                <span className={`dropdown ${this.state.visibleTab_classname} ${this.state.dropdownlistopenul ? 'is-active' : ''}`} onClick={this.dropdownlistopen.bind(this)} dangerouslySetInnerHTML={{ __html: this.props.servicedetails_default_navigation }}></span>
                                                <ul className="tab drop">

                                                    {this.props.field_service_detail_collection_export.map((tab, index) => (
                                                        <li key={index} data-name={tab.navigation} onClick={this.setVisibleTab.bind(this, tab.tab_id, tab.navigation)} className={`tablinks tablinks_${tab.tab_id} ${this.state.visibleTab === tab.tab_id ? "active" : ""}`} >
                                                            {this.props.isLoading ? (
                                                                <div className="list-placeholder-all">
                                                                    <ReactPlaceholder type='text' rows={1} ready={false} showLoadingAnimation={true}></ReactPlaceholder>
                                                                </div>
                                                            ) : (

                                                                <span className="name" dangerouslySetInnerHTML={{ __html: tab.navigation }}></span>
                                                            )}
                                                        </li>
                                                    ))
                                                    }
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-md-9 header-fix">
                                    {this.props.field_service_detail_collection_export.map((tab, index) => (
                                        <div key={index}>
                                            <div className={`tabcontent ${this.state.visibleTab_classname}`} style={this.state.visibleTab === tab.tab_id ? {} : { display: 'none' }}>
                                                <div className="e-commerce-title-content">
                                                    <h2 className={`${pageClass} headlinks_${tab.tab_id}`}>

                                                        <ReactPlaceholder type="text" className="placeholder-title-performancemarket" rows={1} ready={!this.props.isLoading} showLoadingAnimation={true}>


                                                            <span dangerouslySetInnerHTML={{ __html: this.props.servicedetails.title }}></span>
                                                        </ReactPlaceholder>
                                                    </h2>
                                                </div>
                                                <div className="summary-scroll">
                                                    {
                                                        tab.profile_block_title ? (
                                                            <div className="app-e-commerce">
                                                                <div className="row">
                                                                    <div className="col-md-5 offset-md-1">
                                                                        <div className="e-commerce-web-content">
                                                                            <h3 className={`headlinks_${tab.tab_id} ipad_headlink`} dangerouslySetInnerHTML={{ __html: tab.profile_block_title }}></h3>
                                                                            <div className="e-commerce-web-content-left-side-img">

                                                                                <ReactPlaceholder type='rect' className="placeholder-image-navigation" ready={!this.props.isLoading} showLoadingAnimation={true}>
                                                                                    <picture>
                                                                                        <source media="(max-width:767px)" srcSet={tab.profile_mobile_image} />
                                                                                        <LazyLoadImage effect="blur" src={tab.profile_image} alt="" />
                                                                                    </picture>
                                                                                </ReactPlaceholder>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div className="col-md-5">
                                                                        <div className="e-commerce-web-content-right-side-content">
                                                                            <h3 className={`headlinks_${tab.tab_id}`}>
                                                                                <ReactPlaceholder type="text" rows={1} ready={!this.props.isLoading} showLoadingAnimation={true}>

                                                                                    <span dangerouslySetInnerHTML={{ __html: tab.profile_block_title }}></span>
                                                                                </ReactPlaceholder>
                                                                            </h3>

                                                                            <ReactPlaceholder type="text" rows={6} ready={!this.props.isLoading} showLoadingAnimation={true}>
                                                                                <p>{tab.profile_block_para1}</p>
                                                                            </ReactPlaceholder>

                                                                            <p>
                                                                                <ReactPlaceholder type="text" rows={6} ready={!this.props.isLoading} showLoadingAnimation={true}>
                                                                                    {/* <p>{tab.profile_block_para2}</p> */}
                                                                                    <span className="analytics-list-seperator" dangerouslySetInnerHTML={{ __html: tab.profile_block_para2 }}></span>
                                                                                </ReactPlaceholder>
                                                                            </p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        ) : (<></>)
                                                    }
                                                    {
                                                        tab.approach_block_title ? (
                                                            <div className="summary-apporach-section">
                                                                <div className="row">
                                                                    <div className="col-md-12">
                                                                        <div className="apporoach-title">

                                                                            <ReactPlaceholder type="text" rows={1} className="approach-placeholder" ready={!this.props.isLoading} showLoadingAnimation={true}>
                                                                                <h2>{tab.approach_block_title}</h2>
                                                                            </ReactPlaceholder>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div className="row">
                                                                    <div className="col-md-1">
                                                                    </div>
                                                                    <div className="col-md-12 col-xl-10">
                                                                        <div className="row">
                                                                            <div className="col-md-4">
                                                                                <div className="card-aporoach">
                                                                                    <div className="card-aporoach-img">

                                                                                        <ReactPlaceholder type='round' className="logo-placeholder-image-navigation" ready={!this.props.isLoading} showLoadingAnimation={true}>

                                                                                            <picture>
                                                                                                <source media="(max-width:768px)" srcSet={tab.approach_first_mobile_img} />
                                                                                                <LazyLoadImage effect="blur" src={tab.approach_block_first_image} alt="" />
                                                                                            </picture>
                                                                                        </ReactPlaceholder>

                                                                                    </div>
                                                                                    <ReactPlaceholder type='text' rows={1} ready={!this.props.isLoading} showLoadingAnimation={true}>
                                                                                        <h4 className="apporoach-title-card">{tab.approach_block_first_title}</h4>
                                                                                    </ReactPlaceholder>

                                                                                    <ReactPlaceholder type='text' rows={8} ready={!this.props.isLoading} showLoadingAnimation={true}>

                                                                                        <p>{tab.approach_block_first_descr}</p>
                                                                                    </ReactPlaceholder>

                                                                                </div>
                                                                            </div>
                                                                            <div className="col-md-4">
                                                                                <div className="card-aporoach">
                                                                                    <div className="card-aporoach-img">

                                                                                        <ReactPlaceholder type='round' className="logo-placeholder-image-navigation" ready={!this.props.isLoading} showLoadingAnimation={true}>

                                                                                            <picture>
                                                                                                <source media="(max-width:767px)" srcSet={tab.approach_second_mobile_img} />
                                                                                                <LazyLoadImage effect="blur" src={tab.approach_block_second_imag} alt="" />
                                                                                            </picture>
                                                                                        </ReactPlaceholder>

                                                                                    </div>

                                                                                    <ReactPlaceholder type='text' rows={1} ready={!this.props.isLoading} showLoadingAnimation={true}>

                                                                                        <h4 className="apporoach-title-card">{tab.approach_block_second_titl}</h4>
                                                                                    </ReactPlaceholder>


                                                                                    <ReactPlaceholder type='text' rows={8} ready={!this.props.isLoading} showLoadingAnimation={true}>

                                                                                        <p>{tab.approach_block_second_desc}</p>
                                                                                    </ReactPlaceholder>
                                                                                </div>
                                                                            </div>
                                                                            <div className="col-md-4">
                                                                                <div className="card-aporoach">
                                                                                    <div className="card-aporoach-img">
                                                                                        <ReactPlaceholder type='round' className="logo-placeholder-image-navigation" ready={!this.props.isLoading} showLoadingAnimation={true}>

                                                                                            <picture>
                                                                                                <source media="(max-width:767px)" srcSet={tab.approach_third_mobile_imag} />
                                                                                                <LazyLoadImage effect="blur" src={tab.approach_block_third_image} alt="" />
                                                                                            </picture>
                                                                                        </ReactPlaceholder>

                                                                                    </div>

                                                                                    <ReactPlaceholder type='text' rows={1} ready={!this.props.isLoading} showLoadingAnimation={true}>

                                                                                        <h4 className="apporoach-title-card">{tab.approach_block_third_title}</h4>
                                                                                    </ReactPlaceholder>


                                                                                    <ReactPlaceholder type='text' rows={8} ready={!this.props.isLoading} showLoadingAnimation={true}>

                                                                                        <p>{tab.approach_block_third_descr}</p>
                                                                                    </ReactPlaceholder>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        ) : (<></>)
                                                    }
                                                    {
                                                        tab.summary_block_title ? (
                                                            <div className="summary-apporoach">
                                                                <div className="row">
                                                                    <div className="col-md-5 offset-md-1">
                                                                        <div className="apporoach-summary-left-side">
                                                                            <h4 className={`headlinks_${tab.tab_id}`}>
                                                                                <ReactPlaceholder type='text' rows={1} ready={!this.props.isLoading} showLoadingAnimation={true}>
                                                                                    <span>{tab.summary_block_title}</span>
                                                                                </ReactPlaceholder>
                                                                            </h4>

                                                                            <ReactPlaceholder type='text' rows={5} ready={!this.props.isLoading} showLoadingAnimation={true}>
                                                                                <p>{tab.summary_block_para1}</p>
                                                                                <p>{tab.summary_block_para2}</p>
                                                                            </ReactPlaceholder>
                                                                        </div>
                                                                    </div>
                                                                    <div className="col-md-5">
                                                                        <div className="consequal-content">


                                                                            <ReactPlaceholder type='round' className="placeholder-image-navigation" ready={!this.props.isLoading} showLoadingAnimation={true}>

                                                                                <picture>
                                                                                    <source media="(max-width:767px)" srcSet={tab.summary_block_mobile_image} />
                                                                                    <LazyLoadImage effect="blur" src={tab.summary_block_image} alt="" />
                                                                                </picture>
                                                                            </ReactPlaceholder>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        ) : (<></>)
                                                    }
                                                    {
                                                        tab.testimonial_block_title ? (
                                                            <div className="customer-testimonial-section-content">
                                                                <div className="row">
                                                                    <div className="col-md-10 offset-md-1">
                                                                        <div className="customer-testimonial">
                                                                            <h2>{tab.testimonial_block_title}</h2>
                                                                            <p>{tab.testimonial_title_info}</p>

                                                                            <div className="our-testimonial-content">
                                                                                <p>{tab.testimonial_block_descript}</p>
                                                                            </div>
                                                                            <div className="testimonial-client-name">
                                                                                <p>{tab.singnature_name}</p>
                                                                                <p>{tab.signature_title}</p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        ) : (<></>)
                                                    }
                                                </div>
                                            </div>
                                        </div>
                                    ))
                                    }
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <MonthlyBudget />
            </section>
            </>
        )
    }
}
export default ServicePage;
