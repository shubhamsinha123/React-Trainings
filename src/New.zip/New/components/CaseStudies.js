import React from 'react';
import MonthlyBudget from '../components/common/monthlyBudget/monthlybudget';
import ReactPlaceholder from 'react-placeholder'
import "react-placeholder/lib/reactPlaceholder.css";
import 'react-lazy-load-image-component/src/effects/blur.css';
import { LazyLoadImage } from 'react-lazy-load-image-component';

class CaseStudiesDetailVitaminsIndustry extends React.Component {
    constructor(probs) {
        super(probs);
        this.state = {
            visibleTab: "",
            visibleTab_classname: "visibletab-0",
            dropdownlistopenul: false,
        }
    }
    componentDidMount() {
        // window.scrollTo(0, 0);
        this.setState({
            visibleTab: "0",
        })
    }
 
    setVisibleTab(ix, name, event) {
        this.setState({
            visibleTab: this.props.casestudiesdetails_export_1[ix].tab_id,
        });

        if (ix === "0") {
            this.setState({
                visibleTab_classname: "visibletab-0"
            });
        } else if (ix === "1") {
            this.setState({
                visibleTab_classname: "visibletab-1"
            });
        } else if (ix === "2") {
            this.setState({
                visibleTab_classname: "visibletab-2"
            });
        } else if (ix === "3") {
            this.setState({
                visibleTab_classname: "visibletab-3"
            });
        } else if (ix === "4") {
            this.setState({
                visibleTab_classname: "visibletab-4"
            });
        } else if (ix === "5") {
            this.setState({
                visibleTab_classname: "visibletab-5"
            });
        } else if (ix === "6") {
            this.setState({
                visibleTab_classname: "visibletab-6"
            });
        } else {
            this.setState({
                visibleTab_classname: ""
            });
        }
        if (window.innerWidth <= 767) {
            event.currentTarget.parentElement.parentElement.querySelector("span.dropdown").innerHTML = name;
            this.setState({
                dropdownlistopenul: false,
            });
        }
        if (window.innerWidth <= 1024 && window.innerWidth >= 767) {
            event.currentTarget.parentElement.parentElement.querySelector("span.dropdown").innerHTML = name;
            this.setState({
                dropdownlistopenul: false,
            });
        }
    }
    dropdownlistopen() {
        this.setState({
            dropdownlistopenul: !this.state.dropdownlistopenul,
        });
    }
    render() {
        const { pageClass } = this.props || {};
        return (
            <section className="service-detail">
                <div className="case-studies-detail-overall">
                    <section className="details-visuval-design case-details-visuval-design">
                        <div className="container-fluid">
                            <div className="wrapper">

                                <div className="row">
                                    <div className="col-md-4">
                                        <div className="visuval-details-content">

                                            <div className="visuval-details-content-sub">


                                                {this.props.isLoading ? (
                                                    <h1>
                                                        <ReactPlaceholder type="rect" color='#ffed6d' ready={false} style={{ width: "75%", height: "21px", padding: "20px" }} showLoadingAnimation={true}></ReactPlaceholder>
                                                        <ReactPlaceholder type="rect" color='#ffed6d' ready={false} style={{ width: "100%", height: "20px", marginTop: "10px", padding: "20px" }} showLoadingAnimation={true}></ReactPlaceholder>
                                                        <ReactPlaceholder type="rect" color='#ffed6d' ready={false} style={{ width: "400px", height: "20px", marginTop: "10px", padding: "20px" }} showLoadingAnimation={true}></ReactPlaceholder>

                                                    </h1>
                                                ) : (
                                                    <h1>{this.props.casestudiesdetails.title}</h1>
                                                )}


                                                <ReactPlaceholder type="text" rows={5} ready={!this.props.isLoading} className="details-p-placeholder" style={{ marginTop: "18px" }} showLoadingAnimation={true}>
                                                    <p>{this.props.casestudiesdetails.field_case_study_description}</p>
                                                </ReactPlaceholder>

                                            </div>

                                        </div>
                                    </div>
                                    <div className="col-md-7 offset-md-1">
                                        <div className="air-icon">
                                            {/* style={{ width: "325px", height: "307px" }} */}
                                            <ReactPlaceholder type='rect' ready={!this.props.isLoading} showLoadingAnimation={true} className="details-airicon-placeholder">
                                                <picture>
                                                    <source media="(max-width:767px)" srcSet={'/assets/images/icons/air-icon.png'} />
                                                    <img src={'/assets/images/icons/air-icon.png'} alt="" />
                                                </picture>
                                            </ReactPlaceholder>

                                        </div>
                                        <div className="right-side-visuval-img">

                                            <ReactPlaceholder className="placeholder-sd-image-first placeholder-rect-home-herobanner" type='rect' style={{ borderRadius: "10px", height: "98%" }} ready={!this.props.isLoading} showLoadingAnimation={true}>
                                                <picture>
                                                    <source media="(max-width:767px)" srcSet={this.props.casestudiesdetails.field_mobile_video_thumbnail} />
                                                    <LazyLoadImage effect="blur" src={this.props.casestudiesdetails.field_desktop_video_image} alt="" />
                                                </picture>
                                            </ReactPlaceholder>
                                        </div>
                                    </div>
                                </div>
                                {/* --------------------------------------------------------------- */}


                            </div>
                        </div>
                    </section>
                    <section className="clear-content case-clear-content">
                        <div className="wrapper">

                            <ReactPlaceholder type='rect' style={{ width: "70%", height: "100px", margin: "auto" }} ready={!this.props.isLoading} showLoadingAnimation={true}>

                                <div className="alert-messages">
                                    <div className="alert-content">
                                        <h4>{this.props.casestudiesdetails.field_intel_label}</h4>
                                    </div>
                                    <div className="alert-img alert-content">
                                        <picture>
                                            <source media="(max-width:767px)" srcSet={this.props.casestudiesdetails.field_intel_icon} />
                                            <LazyLoadImage effect="blur" src={this.props.casestudiesdetails.field_intel_icon} alt="" />
                                        </picture>
                                    </div>
                                    <div className="alert-content bottom-alert-content">
                                        <p>
                                            {this.props.casestudiesdetails.field_intel_description}
                                            <small className="cl-name">{this.props.casestudiesdetails.field_intel_description_name}</small>
                                        </p>
                                    </div>
                                </div>
                            </ReactPlaceholder>
                        </div>
                    </section>
                    <section className="benefits -design case-benefits-design">
                        <div className="container-fluid">
                            <div className="wrapper">
                                <div className="row">
                                    <div className="col-md-11 offset-md-1">


                                        <ReactPlaceholder type="text" color="#1c1d21" rows={1} style={{ fontSize: "2.9375rem", width: "20%", lineHeight: "0.76", marginBottom: "37px" }} ready={!this.props.isLoading} showLoadingAnimation={true}>
                                            <h3 className="picture-title">
                                                {
                                                    this.props.casestudiesdetails.field_big_picture_title
                                                }
                                            </h3>
                                        </ReactPlaceholder>
                                    </div>
                                    <div className="col-md-4 offset-md-1">
                                        <div className="benefits-content">
                                            <ReactPlaceholder type="text" color="#1c1d21" rows={1} ready={!this.props.isLoading} showLoadingAnimation={true}>
                                                <h4>{this.props.casestudiesdetails.field_objective_title}</h4>
                                            </ReactPlaceholder>

                                            <ReactPlaceholder type="text" rows={3} ready={!this.props.isLoading} style={{ marginTop: "18px" }} showLoadingAnimation={true}>
                                                <p>{this.props.casestudiesdetails.field_objective_description}</p>
                                            </ReactPlaceholder>

                                        </div>
                                    </div>
                                    <div className="col-md-5 offset-md-1">
                                        <div className="benefits-content">

                                            <ReactPlaceholder type="text" color="#1c1d21" rows={1} ready={!this.props.isLoading} showLoadingAnimation={true}>
                                                <h4>{this.props.casestudiesdetails.field_result_title}</h4>
                                            </ReactPlaceholder>

                                            <ReactPlaceholder type="text" rows={3} ready={!this.props.isLoading} style={{ marginTop: "18px" }} showLoadingAnimation={true}>
                                                <p>{this.props.casestudiesdetails.field_result_description}</p>
                                            </ReactPlaceholder>
                                        </div>
                                    </div>
                                </div>
                                <div className="row">
                                    <div className="col-12">
                                        <div className="case-stats-wrapper">
                                            {
                                                this.props.casestudiesdetails_big_picture_secion_export.percentage_value_0 ? (
                                                    <div className="item">
                                                        <div className="dollar">
                                                            {this.props.casestudiesdetails_big_picture_secion_export.percentage_value_0}
                                                            {/* {this.props.casestudiesdetails_big_picture_secion_export.source_name_0 === "New Users"?
                                                                (<span className="x-arrow"> </span>) :  */}
                                                            <span className="percentage-arrow"></span>
                                                        </div>
                                                        <div className="dollar-name">{this.props.casestudiesdetails_big_picture_secion_export.source_name_0}</div>
                                                    </div>
                                                ) : (<></>)
                                            }
                                            {
                                                this.props.casestudiesdetails_big_picture_secion_export.percentage_value_1 ? (
                                                    <div className="item">
                                                        <div className="dollar">{this.props.casestudiesdetails_big_picture_secion_export.percentage_value_1}
                                                            {/* {this.props.casestudiesdetails_big_picture_secion_export.source_name_1 ==="Page Views" ?
                                                                (<span className="x-arrow"> </span>) :  */}
                                                            <span className="percentage-arrow"></span>
                                                        </div>
                                                        <div className="dollar-name">{this.props.casestudiesdetails_big_picture_secion_export.source_name_1}</div>
                                                    </div>
                                                ) : (<></>)
                                            }
                                            {
                                                this.props.casestudiesdetails_big_picture_secion_export.percentage_value_2 ? (
                                                    <div className="item">
                                                        <div className="dollar">{this.props.casestudiesdetails_big_picture_secion_export.percentage_value_2}<span className="percentage-arrow"></span></div>
                                                        <div className="dollar-name">{this.props.casestudiesdetails_big_picture_secion_export.source_name_2}</div>
                                                    </div>
                                                ) : (<></>)
                                            }
                                            {
                                                this.props.casestudiesdetails_big_picture_secion_export.percentage_value_3 ? (
                                                    <div className="item">
                                                        <div className="dollar">{this.props.casestudiesdetails_big_picture_secion_export.percentage_value_3}
                                                            {this.props.casestudiesdetails_big_picture_secion_export.source_name_3 === "Avg. Cost Per Lead" ?
                                                                (<span className="down-arrow"> </span>) : <span className="percentage-arrow"></span>
                                                            }
                                                        </div>
                                                        <div className="dollar-name">{this.props.casestudiesdetails_big_picture_secion_export.source_name_3}</div>
                                                    </div>
                                                ) : (<></>)
                                            }
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <section className="e-commerce-design-u case-e-commerce-design-u">
                        <div className="container-fluid">
                            <div className="wrapper">
                                <div className="row">
                                    <div className="col-md-3 e-commerce-left-side-content-wrapper">
                                        <div className="e-commerce-left-side-content">
                                            <div className="e-commerce-left-headlinks">Results by Service</div>
                                            <div className="dropdownlist-wrapper-details">
                                                <div className="dropdown_list">
                                                    <span className={`dropdown ${pageClass} ${this.state.visibleTab_classname} ${this.state.dropdownlistopenul ? 'is-active' : ''}`} onClick={this.dropdownlistopen.bind(this)}>{this.props.casestudiesdetails_default_navigation}</span>
                                                    <ul className="tab drop">

                                                        {this.props.casestudiesdetails_export_1.map((tab, index) => (
                                                            <li key={index} data-name={tab.navigation} onClick={this.setVisibleTab.bind(this, tab.tab_id, tab.navigation)} className={`tablinks ${pageClass}_${tab.tab_id} ${this.state.visibleTab === tab.tab_id ? "active" : ""}`} >

                                                                <ReactPlaceholder type='text' rows={1} ready={!this.props.isLoading} showLoadingAnimation={true}>
                                                                    <span className="name" dangerouslySetInnerHTML={{ __html: tab.navigation }}></span>
                                                                </ReactPlaceholder>

                                                                <span className="navigate-img normal-icon">

                                                                    <picture>
                                                                        <source media="(max-width:767px)" srcSet={tab.navigation_normal_icon} />
                                                                        <img src={tab.navigation_normal_icon} alt="" />
                                                                    </picture>

                                                                </span>
                                                                <span className="navigate-img active-icon">

                                                                    <picture>
                                                                        <source media="(max-width:767px)" srcSet={tab.navigation_active_icon} />
                                                                        <img src={tab.navigation_active_icon} alt="" />
                                                                    </picture>

                                                                </span>
                                                            </li>
                                                        ))}
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-9 header-fix">
                                        {this.props.casestudiesdetails_export_1.map((tab, index) => (
                                            <div key={index}>
                                                <div className={`tabcontent ${this.state.visibleTab_classname}`} style={this.state.visibleTab === tab.tab_id ? {} : { display: 'none' }}>
                                                    <div className="e-commerce-title-content">

                                                        <ReactPlaceholder type="text" rows={1} className="placeholder-case-detail-head-1" ready={!this.props.isLoading} showLoadingAnimation={true}>
                                                            <div className="sub-headlinks">
                                                                Results by Service
                                                            </div>
                                                        </ReactPlaceholder>
                                                        <ReactPlaceholder type="text" rows={1} ready={!this.props.isLoading} className="placeholder-case-detail-head-2" showLoadingAnimation={true}>
                                                            <h2 className={`${pageClass}_${tab.tab_id}`} dangerouslySetInnerHTML={{ __html: tab.block_title }}></h2>
                                                        </ReactPlaceholder>
                                                    </div>
                                                    <div className="summary-scroll">
                                                        <div className="app-e-commerce">
                                                            <div className="row">
                                                                <div className="col-md-5 offset-md-1">
                                                                    <div className="e-commerce-web-content">
                                                                        <ReactPlaceholder type='text' rows={2} ready={!this.props.isLoading} showLoadingAnimation={true}>
                                                                            <div className="e-commerce-web-content-top">
                                                                                <p>
                                                                                    {tab.block_top_description}
                                                                                </p>
                                                                            </div>
                                                                        </ReactPlaceholder>
                                                                        <div className="e-commerce-web-content-left-side-img-vit">

                                                                            <ReactPlaceholder type='rect' className="placeholder-image-navigation" ready={!this.props.isLoading} showLoadingAnimation={true}>
                                                                                <picture>
                                                                                    <source media="(max-width:767px)" srcSet={tab.profile_mobile_image} />
                                                                                    <LazyLoadImage effect="blur" src={tab.profile_image} alt="" />
                                                                                </picture>
                                                                            </ReactPlaceholder>
                                                                            {/* <picture>
                                                                                <source media="(max-width:767px)" srcSet={tab.profile_mobile_image} />
                                                                                <img src={tab.profile_image} alt="" />
                                                                            </picture> */}
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div className="col-md-5">
                                                                    <div className="e-commerce-web-content-right-side-content">
                                                                        <h3 className={`${pageClass}_${tab.tab_id}`}>
                                                                            <ReactPlaceholder type="text" rows={1} ready={!this.props.isLoading} showLoadingAnimation={true}>

                                                                                <span dangerouslySetInnerHTML={{ __html: tab.profile_block_title }}></span>
                                                                            </ReactPlaceholder>
                                                                        </h3>

                                                                        <ReactPlaceholder type="text" rows={3} style={{ marginBottom: "1em" }} ready={!this.props.isLoading} showLoadingAnimation={true}>
                                                                            <p>{tab.profile_block_para1}</p>
                                                                        </ReactPlaceholder>


                                                                        <ReactPlaceholder type="text" rows={3} ready={!this.props.isLoading} showLoadingAnimation={true}>
                                                                            <p>{tab.profile_block_para2}</p>
                                                                        </ReactPlaceholder>
                                                                    </div>
                                                                </div>
                                                                {/* <div className="col-md-5">
                                                                    <div className="e-commerce-web-content-right-side-content">
                                                                        <h3 className={`${pageClass}_${tab.tab_id}`} dangerouslySetInnerHTML={{ __html: tab.profile_block_title }}></h3>
                                                                        <p>{tab.profile_block_para1} </p>
                                                                        <p>{tab.profile_block_para2}</p>
                                                                    </div>
                                                                </div> */}
                                                            </div>
                                                        </div>
                                                        <div className="summary-apporach-section">
                                                            <div className="row">
                                                                <div className="col-md-12">
                                                                    <div className="apporoach-title">

                                                                        <ReactPlaceholder type="text" rows={1} className="approach-placeholder" ready={!this.props.isLoading} showLoadingAnimation={true}>
                                                                            <h2>{tab.approach_block_title}</h2>
                                                                        </ReactPlaceholder>
                                                                    </div>
                                                                    {/* <div className="apporoach-title">
                                                                        <h2>{tab.approach_block_title}</h2>
                                                                    </div> */}
                                                                </div>
                                                            </div>
                                                            <div className="row">
                                                                <div className="col-md-1">
                                                                </div>
                                                                <div className="col-md-12 col-xl-10">
                                                                    <div className="row">
                                                                        <div className="col-md-4">
                                                                            <div className="card-aporoach">
                                                                                <div className="card-aporoach-img">

                                                                                    <ReactPlaceholder type='round' className="logo-placeholder-image-navigation" ready={!this.props.isLoading} showLoadingAnimation={true}>

                                                                                        <picture>
                                                                                            <source media="(max-width:768px)" srcSet={tab.approach_first_mobile_img} />
                                                                                            <LazyLoadImage effect="blur" src={tab.approach_block_first_image} alt="" />
                                                                                        </picture>
                                                                                    </ReactPlaceholder>

                                                                                </div>
                                                                                <ReactPlaceholder type='text' rows={1} ready={!this.props.isLoading} showLoadingAnimation={true}>
                                                                                    <h4 className="apporoach-title-card">{tab.approach_block_first_title}</h4>
                                                                                </ReactPlaceholder>

                                                                                <ReactPlaceholder type='text' rows={8} ready={!this.props.isLoading} showLoadingAnimation={true}>

                                                                                    <p>{tab.approach_block_first_descr}</p>
                                                                                </ReactPlaceholder>

                                                                            </div>
                                                                        </div>
                                                                        <div className="col-md-4">
                                                                            <div className="card-aporoach">
                                                                                <div className="card-aporoach-img">

                                                                                    <ReactPlaceholder type='round' className="logo-placeholder-image-navigation" ready={!this.props.isLoading} showLoadingAnimation={true}>

                                                                                        <picture>
                                                                                            <source media="(max-width:767px)" srcSet={tab.approach_second_mobile_img} />
                                                                                            <LazyLoadImage effect="blur" src={tab.approach_block_second_imag} alt="" />
                                                                                        </picture>
                                                                                    </ReactPlaceholder>

                                                                                </div>

                                                                                <ReactPlaceholder type='text' rows={1} ready={!this.props.isLoading} showLoadingAnimation={true}>

                                                                                    <h4 className="apporoach-title-card">{tab.approach_block_second_titl}</h4>
                                                                                </ReactPlaceholder>


                                                                                <ReactPlaceholder type='text' rows={8} ready={!this.props.isLoading} showLoadingAnimation={true}>

                                                                                    <p>{tab.approach_block_second_desc}</p>
                                                                                </ReactPlaceholder>
                                                                            </div>
                                                                        </div>
                                                                        <div className="col-md-4">
                                                                            <div className="card-aporoach">
                                                                                <div className="card-aporoach-img">
                                                                                    <ReactPlaceholder type='round' className="logo-placeholder-image-navigation" ready={!this.props.isLoading} showLoadingAnimation={true}>

                                                                                        <picture>
                                                                                            <source media="(max-width:767px)" srcSet={tab.approach_third_mobile_imag} />
                                                                                            <LazyLoadImage effect="blur" src={tab.approach_block_third_image} alt="" />
                                                                                        </picture>
                                                                                    </ReactPlaceholder>

                                                                                </div>

                                                                                <ReactPlaceholder type='text' rows={1} ready={!this.props.isLoading} showLoadingAnimation={true}>

                                                                                    <h4 className="apporoach-title-card">{tab.approach_block_third_title}</h4>
                                                                                </ReactPlaceholder>


                                                                                <ReactPlaceholder type='text' rows={8} ready={!this.props.isLoading} showLoadingAnimation={true}>

                                                                                    <p>{tab.approach_block_third_descr}</p>
                                                                                </ReactPlaceholder>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div className="summary-apporoach">
                                                            <div className="row">
                                                                <div className="col-md-5 offset-md-1">
                                                                    <div className="apporoach-summary-left-side">
                                                                        <h4 className={`${pageClass}_${tab.tab_id}`}>
                                                                            <ReactPlaceholder type='text' rows={1} ready={!this.props.isLoading} showLoadingAnimation={true}>
                                                                                <span>{tab.summary_block_title}</span>
                                                                            </ReactPlaceholder>
                                                                        </h4>

                                                                        <ReactPlaceholder type='text' rows={5} ready={!this.props.isLoading} showLoadingAnimation={true}>
                                                                            <p>{tab.summary_block_para1}</p>
                                                                            <p>{tab.summary_block_para2}</p>
                                                                        </ReactPlaceholder>
                                                                    </div>
                                                                </div>
                                                                <div className="col-md-5">
                                                                    <div className="consequal-content">


                                                                        <ReactPlaceholder type='round' className="placeholder-image-navigation" ready={!this.props.isLoading} showLoadingAnimation={true}>

                                                                            <picture>
                                                                                <source media="(max-width:767px)" srcSet={tab.summary_block_mobile_image} />
                                                                                <LazyLoadImage effect="blur" src={tab.summary_block_image} alt="" />
                                                                            </picture>
                                                                        </ReactPlaceholder>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        {/* <div className="summary-apporoach">
                                                            <div className="row">
                                                                <div className="col-md-5 offset-md-1">
                                                                    <div className="apporoach-summary-left-side">
                                                                        <h4 className={`${pageClass}_${tab.tab_id}`}>{tab.summary_block_title}</h4>
                                                                        <p>{tab.summary_block_para1}</p>
                                                                        <p>{tab.summary_block_para2}</p>
                                                                    </div>
                                                                </div>
                                                                <div className="col-md-5">
                                                                    <div className="consequal-content">
                                                                        <picture>
                                                                            <source media="(max-width:767px)" srcSet={tab.summary_block_mobile_image} />
                                                                            <img src={tab.summary_block_image} alt="" />
                                                                        </picture>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div> */}
                                                        <div className="customer-testimonial-section-content">
                                                            <div className="row">
                                                                <div className="col-md-10 offset-md-1">
                                                                    <div className="customer-testimonial">
                                                                        <h2>{tab.testimonial_block_title}</h2>
                                                                        {/* <p>{tab.testimonial_title_info}</p> */}

                                                                        <div className="our-testimonial-content">
                                                                            <p>{tab.testimonial_block_descript}</p>
                                                                        </div>
                                                                        <div className="testimonial-client-name">
                                                                            <p>{tab.singnature_name}</p>
                                                                            <p>{tab.signature_title}</p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
                <MonthlyBudget />
            </section>
        )
    }
}
export default CaseStudiesDetailVitaminsIndustry;
