import React from 'react';
import axios from 'axios';
import VideoModal from './VideoModal/VideoModal';

class Omnis extends React.Component {
    constructor(probs) {
        super(probs);
        const state = {
            inshights: [],
            inshights_field_insight_grid_text_export: [],
            inshights_field_v_export: [],
            innovationoverlay_width: 0,
            innovationoverlay_left: 0,
            animation_start: 0,
            data: [],
            showModal: false,
            modelContent: "",
            videoUrl: "",
            insight_title_desc: [],
        }
        this.state = state;
        this.handleOpenModal = this.handleOpenModal.bind(this);
        this.handleCloseModal = this.handleCloseModal.bind(this);

    }

    componentDidMount() {
        this.getomnisbanner();
        window.addEventListener('scroll', this.handleScroll, true);
    }
    getomnisbanner() {
        axios.get(`${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/insights-listing/10`)
            .then(result => {
                var insightarr = result.data
                var filteryt = insightarr.filter(function (obj) {
                    return obj.field_watch_video_link.includes("youtube");
                });
                // console.log(insightarr)
                this.setState({
                    data: insightarr,
                    inshights: filteryt[0],

                });
            })
            .catch(error => {

            })
            axios.get(`${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/homepage/1/section/4`)
            .then((res) => {
                this.setState(
                    {
                        insight_title_desc: res.data[0]
                    },
                );
            })
            .catch((error) => { });
    }

    handleOpenModal(title_head, url_video) {
        this.setState({ showModal: true, modelContent: title_head, videoUrl: url_video });
        window.scrollTo(0, 0);
    }

    handleCloseModal() {
        this.setState({ showModal: false });
    }

    handleScroll = (e) => {
        var innovationLeft = document.getElementById("solutionswidth")?.offsetLeft;
        this.setState({
            innovationoverlay_left: innovationLeft,
        });
        let overlayslider = document.getElementById("scrolloverlayslider");
        let overlaysliderHeight = document.getElementById("scrolloverlayslider")?.offsetHeight;
        // let overlaysliderTop = overlayslider.offsetTop - (overlaysliderHeight/2)+141;
        var screenHeight = window.innerHeight;
        let overlaysliderTop = overlayslider?.offsetTop - screenHeight + 141;
        if (window.scrollY >= overlaysliderTop) {
            this.setState({
                animation_start: 1,
            });
        }
        if (window.scrollY < overlaysliderTop) {
            this.setState({
                animation_start: 2,
            });
        }

    }
    render() {
        // console.log(this.state.data);
        // console.log(this.state.inshights);
        if (typeof window !== "undefined") {
            if (window.innerWidth > 767) {
                const innovationtop = -141;
                var innovationoverlayStyle = {};
                if (this.state.animation_start === 0) {
                    innovationoverlayStyle = {
                    }
                }
                if (this.state.animation_start === 1) {
                    innovationoverlayStyle = {
                        transform: `translate(${this.state.innovationoverlay_left}px, 0)`,

                    }
                }
                if (this.state.animation_start === 2) {
                    innovationoverlayStyle = {
                        transform: 'translate(0, 0)',
                    }
                }
            }
        }
        return (
            <>
                <VideoModal
                    show={this.state.showModal}
                    onClose={this.handleCloseModal}
                    url={this.state.videoUrl}
                    title={this.state.modelContent}
                    backLink='Back to page'
                />
                <section className="slider omins" id="scrolloverlayslider">
                    {/* style={innovationoverlayStyle} */}
                    <div id="innovations-overlay" style={innovationoverlayStyle}></div>
                    <div className="container-fluid">
                        <div className="wrapper">
                            <div className="row">
                                <div className="col-md-4">
                                    <div className="night-slider-content">
                                        <h2>{this.state.insight_title_desc.field_title}</h2>
                                        <p>{this.state.insight_title_desc.field_description}</p>

                                        <div className="night-slider">
                                            <div className="center slider">
                                                <div>
                                                    <div className="media-video youtube-player" data-id="6qGiXY1SB68">
                                                        <span className="thumbvideo amd-play3" style={{ cursor: "pointer" }} onClick={this.handleOpenModal.bind(this, this.state.inshights.title, this.state.inshights.field_watch_video_link)}></span>
                                                        {/* <picture className="rectangle-source-images"> */}
                                                        <picture className="video-thumbnail-image">
                                                            {/* <source media="(max-width: 767px)" srcSet={this.state.inshights.field_mobile_video_thumbnail} /> */}
                                                            <img src={this.state.inshights.field_video_thumbnail_image} alt="video thumbnail" />
                                                        </picture>
                                                        {/* <img src={this.state.inshights.field_mobile_video_thumbnail} style={{width: '100%', height: '307px'}} alt="" /> */}
                                                        <div className="strategy-omins strategy">
                                                            <div className="set">
                                                                <h4><a href={`${this.state.inshights.view_node}`} style={{ cursor: "pointer", color: "white" }}>{this.state.inshights.title}</a></h4>
                                                                <div className="mob-read-art"><a className="read-art" href={`${this.state.inshights.view_node}`} style={{ cursor: "pointer" }}><span className="read-article-omins amd-readarticle"></span> {this.state.inshights.field_read_more_text}</a></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="group-btn">
                                            <div className="bg-two">
                                                <a href="/insights" className="btn" >VIEW ALL INSIGHTS </a> </div>

                                        </div>

                                    </div>
                                </div>
                                <div className="col-md-8 solutions" id="solutionswidth">
                                    <div className="innovations">
                                        <div className="card-discover">
                                            <div className="solutions-content service-card-view view-contents">
                                                <div className="row">
                                                    {this.state.data.map(({ title, field_insight_description, view_node, field_authors_profile_image, field_auth, field_authors_date, field_read_more_text, field_read_more_link }, index) => {
                                                        if (index == 0) {
                                                            return <div className="col-md-6" key={index}>
                                                                <div className="card-solution">
                                                                    <h3><a href={`${view_node}`} style={{ cursor: "pointer", color: "#4e4e56" }}>{title}</a></h3>
                                                                    <p className="card-bg-para"> <span className="bg-solution-desc"> {field_insight_description} </span>
                                                                        <a className="readarticle" href={`${view_node}`} style={{ cursor: "pointer" }}>{field_read_more_text}</a>
                                                                    </p>
                                                                    <div className="amer">
                                                                        <div className="row">
                                                                            <div className="col-2">
                                                                                <div className="article">
                                                                                    <span className="name-date-icon-article"><img src={field_authors_profile_image} className="img-responsive" /></span>
                                                                                </div>
                                                                            </div>
                                                                            <div className="col-10">
                                                                                <div className="elit">
                                                                                    <h4>{field_auth}</h4>
                                                                                    <p>{field_authors_date}</p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        }
                                                        if (index == 1) {
                                                            return <div className="col-md-6" key={index}>
                                                                <div className="bg-solution">
                                                                    <h3><a href={`${view_node}`} style={{ cursor: "pointer", color: "#4e4e56" }}>{title}</a></h3>
                                                                    <p className="card-bg-para"> <span className="bg-solution-desc"> {field_insight_description} </span>
                                                                        <a href={`${view_node}`} style={{ cursor: "pointer" }} className="readarticle">{field_read_more_text}</a>
                                                                    </p>
                                                                    <div className="amer">
                                                                        <div className="row">
                                                                            <div className="col-2">
                                                                                <div className="article">
                                                                                    <span className="name-date-icon-article"><img src={field_authors_profile_image} className="img-responsive" /></span>
                                                                                </div>
                                                                            </div>
                                                                            <div className="col-10">
                                                                                <div className="elit">
                                                                                    <h4>{field_auth}</h4>
                                                                                    <p>{field_authors_date}</p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        }
                                                    })
                                                    }
                                                    <div className="group-btn-ipad">
                                                        <div className="bg-two">
                                                            <a href="/insights" className="btn" >VIEW ALL INSIGHTS </a> </div>

                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>


            </>
        )
    }
}
export default Omnis
