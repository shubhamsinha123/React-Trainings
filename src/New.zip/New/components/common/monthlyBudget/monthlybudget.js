import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import ReactPlaceholder from 'react-placeholder';
import { LazyLoadComponent } from 'react-lazy-load-image-component';
import { Parallax } from 'react-scroll-parallax';
// import { getMonthlyResult } from '../../services/insights.service';
import { getMonthlyResult } from '../../../services/insights.service';
import { useQuery } from 'react-query';
import styles from "./Monthly.module.scss";

const MonthlyBudget = (props) => {
    const monthlyBudget = useQuery('monthly-budget', getMonthlyResult, {
        initialData: props.data || {},
        refetchOnMount: false,
        refetchOnWindowFocus: false,
    })

    useEffect(() => {
        if(!props.data || !Object.keys(props.data).length) {
            monthlyBudget.refetch();
        }
    }, [])
    return (
        <section className={styles.yourMonthly} id="yourMonthly">
                <div className="container-fluid">
                    <div className="wrapper">
                        <div className="row">
                            <div className="col-md-6">
                                <div className={styles.strategy} id="strategy">

                                    <ReactPlaceholder type='text' rows={3} ready={!monthlyBudget.isLoading} showLoadingAnimation={true}>
                                        <h2>{monthlyBudget.data?.field_image_text?.[0]?.sub_title}</h2>
                                    </ReactPlaceholder>

                                    <div className={styles.row}>
                                        <div className="col-5 col-xs-12">
                                            <div className={styles.circleImg}>

                                                <Parallax x={[-200, 10]} >
                                                    <ReactPlaceholder type='round' className="circle-images-placeholder" ready={!monthlyBudget.isLoading} showLoadingAnimation={true}>
                                                        <LazyLoadComponent effect="blur">

                                                            <picture className={styles.circleImages}>
                                                                {/* <source className="improvements" media="(max-width: 767px)" srcSet={this.state.herobanner_text_right.field_mobile_image} /> */}
                                                                <img className={styles.improvements} loading="lazy" src={monthlyBudget.data?.field_desktop_image} alt="" />
                                                            </picture>

                                                        </LazyLoadComponent>
                                                    </ReactPlaceholder>
                                                </Parallax>

                                            </div>

                                        </div>
                                        <div className="col-7 col-xs-12">
                                            <div className={styles.specific}>
                                                <ReactPlaceholder type='text' rows={3} ready={!monthlyBudget.isLoading} showLoadingAnimation={true}>
                                                    <p>{monthlyBudget?.data?.field_image_text?.[0]?.text_description}</p>
                                                </ReactPlaceholder>

                                            </div>
                                        </div>

                                        <div className={styles.accomplish}>

                                            <ReactPlaceholder type='rect' className="accoplish-images-placeholder" ready={!monthlyBudget.isLoading} showLoadingAnimation={true}>
                                                <LazyLoadComponent effect="blur">

                                                    <picture className={styles.accoplishImages}>
                                                        <source className={styles.improvements} media="(max-width: 767px)" srcSet={monthlyBudget.data?.field_banner_mobile_image} />
                                                        <img className={styles.lookingImg} loading="lazy" src={monthlyBudget.data?.field_banner_desktop_image} alt="ameexcircle" />
                                                    </picture>

                                                </LazyLoadComponent>
                                            </ReactPlaceholder>

                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div className="col-md-6">
                                <div className={styles.ameexDigital}>

                                    <ReactPlaceholder type='text' className="placeholder-monthly-data" rows={1} ready={!monthlyBudget.isLoading} showLoadingAnimation={true}>
                                        <h2>{monthlyBudget.data?.field_title}</h2>
                                    </ReactPlaceholder>

                                    <ReactPlaceholder type='text' rows={3} className="placeholder-monthly-btn" ready={!monthlyBudget.isLoading} showLoadingAnimation={true}>
                                        <p>{monthlyBudget.data?.field_description}</p>
                                    </ReactPlaceholder>

                                    <div className={styles.groupBtn}>
                                        <div className={styles.bgThree}>

                                            <ReactPlaceholder type='text' rows={1} ready={!monthlyBudget.isLoading} showLoadingAnimation={true}>
                                                <Link href="/contact-us"><a className="btn">{monthlyBudget.data?.field_cta_button_text} </a></Link>
                                            </ReactPlaceholder>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
    )
}
export default MonthlyBudget;