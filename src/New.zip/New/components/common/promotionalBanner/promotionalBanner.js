import React from 'react';
import axios from 'axios';
import styles from "./promotionalBanner.module.scss";

class PromotionalBanner extends React.Component {
    constructor(props) {
    super(props);
    this.state = {
        result: []
    }
}

getpromoBanner() {
    axios.get(`${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/aboutus/40/promobanner`)
    .then(result=>{
        this.setState ({
            result:result.data[0]
        });
    })
}
componentDidMount() {
    this.getpromoBanner();
}
    render() {
        return (
            <section className={styles.promotionalBanner}>
                <div className="container-fluid">
                    <div className="wrapper">
                        <div className="row">
                        <div className="col-md-8 col-sm-6 col-xs-12">
                            <h2>{this.state.result.field_title}</h2>
                            <p>{this.state.result.field_description}</p>
                        </div>
                        <div className="col-md-4 col-sm-6 col-xs-12">
                        <a href='/contact-us'><button className={styles.promotionalBtn}>{this.state.result.field_cta_button_text}</button></a>
                        </div>
                        </div>
                    </div>
                </div>
            </section>

        )
    }
}
export default PromotionalBanner;