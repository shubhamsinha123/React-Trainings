import React from 'react';
import styles from "./Modal.module.css";

const VideoModal = ({ url, title, onClose = alert, show, backLink }) => {
  return show ? (
    <div className={styles.container} id="modal-container" onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()}>
        <div className={styles.header}>
          <button
            className={styles.closeButton}
            title="Close"
            onClick={onClose}
          >
           X 
          </button>
          {
            backLink && (
              <p className={styles.backArrow} onClick={onClose}>
                <span className={styles.arrow}>&larr;</span> &nbsp;{backLink}</p>
            )
          }
        </div>
        <main className={styles.content}>
          <div className={styles.contentSection}>

            <div className={styles.popupVideoContent}>
              {
                url ?
                  <div className={styles.containerIframe}><iframe className={styles.responsiveIframe} src={url + "?autoplay=1&mute=0&rel=0"}
                    allow='autoplay;fullscreen;'
                    mozallowfullscreen="mozallowfullscreen"
                    msallowfullscreen="msallowfullscreen"
                    oallowfullscreen="oallowfullscreen"
                    webkitallowfullscreen="webkitallowfullscreen" frameborder="0"></iframe></div>
                  : <div>{title}</div>
              }
            </div>
          </div>
        </main>
      </div>
    </div>) : null;
}

export default VideoModal;