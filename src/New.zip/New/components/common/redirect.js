const Redirect = ({ to }) => {
    const router = useRouter();
    React.useEffect(() => {
        router.push(to)
    }, [])

    return null;
}