import React, { useEffect } from 'react';
import Slider from "react-slick";
import { useQuery } from 'react-query'
import { getOurClients } from "../../../services/insights.service";
import styles from "./ourClients.module.scss";

const OurClients = (props) => {
    const clientsData = useQuery('home-clients-data', getOurClients, {
        initialData: props.data || {},
        refetchOnMount: false,
        refetchOnWindowFocus: false,
    })

    useEffect(() => {
        if(!props.data || !Object.keys(props.data).length) {
            clientsData.refetch();
        }
    }, [])

    var ourclients = {
        infinite: clientsData?.data?.field_image_slider?.length > 5,
        slidesToShow: 5,
        slidesToScroll: 1,
        autoplay: !0,
        autoplaySpeed: 2e3,
        mobileFirst: !0,
        responsive: [{
            breakpoint: 1024,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 1,
                dots: !0,
                infinite: clientsData?.data?.field_image_slider?.length > 3,

            }
        },
        {
            breakpoint: 900,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
                infinite: clientsData?.data?.field_image_slider?.length > 2,
            }
        },
        {
            breakpoint: 480,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
                infinite: clientsData?.data?.field_image_slider?.length > 1,
            }
        },
        {
            breakpoint: 319,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
                infinite: clientsData?.data?.field_image_slider?.length > 1,
            }
        }]
    }
    return (
        <>
            <section className={styles.ourClientsContent}>
                <div className="container-fluid">
                    <div className="wrapper">
                        <div className="row">
                            <div className="col-md-12">
                                <div className={styles.ourClientsTitle}>
                                    <h4>{clientsData?.data?.field_title}</h4>
                                    <p>{clientsData?.data?.field_description}</p>
                                </div>
                                <div className={styles.ourClientsPartner}>
                                    <div className={styles.ourClients}>
                                        <Slider {...ourclients}>
                                            {clientsData?.data?.field_image_slider?.map((clientslider, index) => (
                                                <div key={index}>
                                                    <picture className={styles.outClientImage}>
                                                        <source media="(max-width: 767px)" srcSet={clientslider} />
                                                        <img src={clientslider} alt="our-clients" loading="lazy" />
                                                    </picture>
                                                </div>
                                            ))}
                                        </Slider>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>
    )
}
export default OurClients;
