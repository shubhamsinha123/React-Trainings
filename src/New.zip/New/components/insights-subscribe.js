import React from 'react';
import axios from 'axios';
import ReactPlaceholder from 'react-placeholder';
import "react-placeholder/lib/reactPlaceholder.css";

var ApiUrl = `${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}`
var newApiUrl = ApiUrl.replace("api", "");
class InsightsSubscribe extends React.Component {
    constructor(props) {
        super(props);
        this.onChangeUserEmail = this.onChangeUserEmail.bind(this);
        const state = {
            users: [],
            email: "",
            errors: { email: "" },
            success: "",
            isLoading: true
        }
        this.state = state;
    }
    fetchUsers() {
        fetch(`${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/insights-middle/38`)
            .then(response => response.json())
            .then(data =>
                this.setState({
                    users: data,
                    isLoading: false,
                })
            )
            .catch(error => this.setState({ error }));
    }
    componentDidMount() {
        this.fetchUsers();
    }
    onChangeUserEmail(e) {
        this.setState({ email: e.target.value.replace(/\s/g, ""), errors: "", success: "" })
    }
    validateEmail() {
        let email = this.state.email;
        let errors = {};
        let isValid = true;
        if (!email) {
            isValid = false;
            errors["email"] = "Please enter your email Address.";
        }
        if (typeof this.state.email !== "undefined") {
            var patternemail = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
            if (!patternemail.test(this.state.email)) {
                isValid = false;
                errors["email"] = "Please enter valid email address.";
            }
        }
        this.setState({
            errors: errors
        });
        return isValid;
    }
    onSubmit = (e) => {
        e.preventDefault();
        const userObject = {
            webform_id: "subscribe",
            email: this.state.email,
        }
        if (this.validateEmail()) {
            axios.post(`${newApiUrl}webform_rest/submit`, userObject)
                .then((result) => {
                    console.log(result);
                    if (result) {
                        this.setState({
                            success: "Subscribed successfully."
                        })
                    }
                }).catch((error) => {
                    let errors = {};
                    console.log(error.response)
                    console.log(error.response.data)
                    console.log(error.response.data.error.email)
                    if(error.response.data.error.email){
                        errors["email"] = error.response.data.error.email;
                        this.setState({
                            errors: errors
                        });
                    }
                });
            this.setState({
                email: "",
            })
        }
    };
    render() {
        const { users } = this.state;
        return (
            <>
                <div className="col-md-12 col-sm-12 col-xs-12 insights-subscribe">
                    {
                        users.map(user => {
                            return (
                                <div>
                                    <h2>
                                        <ReactPlaceholder type='text' rows={1} ready={!this.state.isLoading} showLoadingAnimation={true}>
                                            <span>{user.field_middle_title}</span>
                                        </ReactPlaceholder>
                                    </h2>
                                    <p>
                                        <ReactPlaceholder type='text' rows={1} ready={!this.state.isLoading} showLoadingAnimation={true}>
                                            {user.field_middle_paragraph}
                                        </ReactPlaceholder>
                                    </p>
                                    <form onSubmit={this.onSubmit}>
                                        <input type="text" id="email" placeholder="Email" value={this.state.email} onChange={this.onChangeUserEmail} />
                                        <button className="insights-btn">
                                            <ReactPlaceholder type='rect' ready={!this.state.isLoading} showLoadingAnimation={true}>
                                                {user.field_middle_button_text}
                                            </ReactPlaceholder>
                                        </button>
                                    </form>
                                    <div className="validation-msg">
                                        {this.state.success ? (<div className="success-msg">{this.state.success}</div>) : (<div className="err-msg">{this.state.errors.email}</div>)}
                                    </div>
                                </div>
                            );
                        })
                    }
                </div>
            </>
        )
    }
}
export default InsightsSubscribe
