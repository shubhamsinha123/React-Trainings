import React from 'react';
import Slider from "react-slick";
import Modal from 'react-modal';
import { LazyLoadImage } from 'react-lazy-load-image-component';

class LeaderMobile extends React.Component {
      constructor(props) {
        super(props);
        this.state = {
            error: false,
            showModal: false,
            modelIcon: "",
            modelTitle: "",
            modelContent: "",
            modelContent1: ""
        };
        this.handleOpenModal = this.handleOpenModal.bind(this);
        this.handleCloseModal = this.handleCloseModal.bind(this);
    }
    handleOpenModal (model_icon, model_title, model_description, model_description1) {
        this.setState({ showModal: true, modelIcon: model_icon, modelTitle: model_title, modelContent: model_description, modelContent1: model_description1 });
    }
    handleCloseModal () {
        this.setState({ showModal: false });
    }
    render () {
    let settings = { 
        dots: true,
        className: 'sample',
        slidesToShow: 1,
        slidesToScroll: 1,
        centerMode: true,
        // variableWidth: true,
        touchMove: true,
        focusOnSelect: true
    }
        const {users} = this.props;
        return (  
            <>
                <section className="our-leaders-content-aboutus2">
                    <div className="container-fluid">
                        <div className="wrapper">
                            <div className="row">
                                <div className="col-md-12">
                                    <div className="our-leaders-title">
                                        {
                                            users.map(user => {
                                                return (
                                                    <div>
                                                    <h2>{user.field_leaders_title}</h2>
                                                    <p>{user.field_leaders_description}</p>
                                                    </div>
                                                );
                                            })
                                        }
                                    </div>
                                    <div className="our-leaders-partner">
                                        <div className="our-leaders">
                                        <Modal 
                                            isOpen={this.state.showModal}
                                            contentLabel="onRequestClose Example"
                                            onRequestClose={this.handleCloseModal}
                                            shouldCloseOnOverlayClick={false}
                                            className="leader-popup"
                                            >
                                                <div className="popup-video-content-2">
                                                    <div className="our-leader-popup-img2">
                                                        <img src={this.state.modelIcon} alt="our-leaders" className="img-responsive" />
                                                    </div>
                                                    <h3>{this.state.modelContent}</h3>
                                                    <h4>{this.state.modelTitle}</h4>
                                                    <p>{this.state.modelContent1}</p>
                                                </div>
                                            <button className="close-btn2" onClick={this.handleCloseModal}>X</button>
                                        </Modal>
                                        <Slider {...settings} >   
                                        {
                                            users.map(user => {
                                                return (
                                                user.field_leaders_export.map( item =>{
                                                    return (
                                                        <div>
                                                            <LazyLoadImage effect="blur" src={item.profile_mobile_icon} alt="our-leaders" className="img-responsive" />
                                                           <div className='leader-descp'> 
                                                                <h3>{item.leader_title}</h3>
                                                                <h4>{item.leader_job_title}</h4>
                                                                <a className="view-bio" onClick={this.handleOpenModal.bind(this,item.profile_mobile_icon,item.leader_job_title,item.leader_title,item.leader_description)}><span className="view-bio-img amd-yellow-arrow"></span>View Bio</a>
                                                           </div>
                                                            
                                                        </div>
                                                        );
                                                    })
                                                );
                                            })
                                        }</Slider> 
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </>
        )
    }
}
export default LeaderMobile;
