import React from 'react';
import { LazyLoadImage } from 'react-lazy-load-image-component';


class Leader extends React.Component {
    
    render () {
        const {users} = this.props;
        return (
            <>
            <section className="leader-section-aboutus2">
                    <div className="container-fluid">
                        <div className="wrapper">
                            <div className="row">
                                <div className="col-md-12 col-sm-12 col-xs-12">
                                    {
                                        users.map(user => {
                                            return (
                                                <div className='leaders-title'>
                                                <h2>{user.field_leaders_title}</h2>
                                                <p>{user.field_leaders_description}</p>
                                                </div>
                                            );
                                        })
                                    }
                                </div>
                                <div className="leader-main-wrapper">                               
                                    <div className="col-md-12 col-sm-12 col-xs-12 leader-box-wrapper  text-center">
                                        <div className="row">
                                            {
                                                users.map(user => {
                                                    return (
                                                    user.field_leaders_export.map( leader =>{
                                                        return (
                                                            <div className="col-md-4 col-sm-4 col-xs-12 leader-box">
                                                                <LazyLoadImage effect="blur" src={leader.profile_desktop_image} className="img-responsive desktop-img" alt=".." />
                                                                {/* <img src={leader.profile_mobile_icon} className="img-responsive mobile-img" alt=".." /> */}
                                                                <div className="leader-hover">
                                                                    <h3>{leader.leader_title}</h3>
                                                                    <h4>{leader.leader_job_title}</h4>
                                                                    <div className ="leader-hover-content">
                                                                        <div className="content-sec">
                                                                            <p>{leader.leader_description}</p>
                                                                        </div>
                                                                    </div>
                                                                </div>                                        
                                                            </div>
                                                            );
                                                        })
                                                    );
                                                })
                                            }
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                </>
        )
    }
}
export default Leader