import React from 'react';
import Link from 'next/dist/client/link';
import { Link as Lk } from 'react-scroll';
import ReactPlaceholder from 'react-placeholder/lib';
import "react-placeholder/lib/reactPlaceholder.css";
import 'react-lazy-load-image-component/src/effects/blur.css';
import { LazyLoadImage } from 'react-lazy-load-image-component';
import MonthlyBudget from '../components/common/monthlyBudget/monthlybudget';
import Slider from 'react-slick'
import VideoModal from './common/VideoModal/VideoModal';
import MetaDecorator from "../components/Util/MetaDecorator";
import Schema from "../components/Util/Schema";
import parse from 'html-react-parser';
import { getAllInsights } from '../services/insights.service';


class Blog extends React.Component {
  constructor(props) {
    super(props);
    this.state =
    {
      items: [],
      blogs: [],
      scrolled: "0%",
      // id: this.props.location.state,
      blog_details: [],
      blogid: 0,
      visible: 0,
      showModal: false,
      modelContent: "",
      videoUrl: "",
      error: false,
      isLoading: true
    };
    this.handleOpenModal = this.handleOpenModal.bind(this);
    this.handleCloseModal = this.handleCloseModal.bind(this);
  }

  handleOpenModal(title_head, url_video) {
    this.setState({ showModal: true, modelContent: title_head, videoUrl: url_video });
  }

  handleCloseModal() {
    this.setState({ showModal: false });
  }

  componentDidMount() {
    window.addEventListener("scroll", this.scrollProgress);

    // console.log(last_element);
    // console.log('> Blog Page: MOUNT >', this.props)
    if (this.props.blogid) {
      console.log('> Blog Page: SSR')
      this.setState({
        items: this.props.items,
        blogid: this.props.blogid,
        isLoading: this.props.isLoading,
      }, () => {
        try {
          console.log('> Blog Page: SSR: BLOG', this.props.blogs)
          const totalwords = JSON.stringify(this.props.blogs?.[0].field_blogs_export).split(' ').length;
          const minutes = Math.ceil(totalwords / 225)
          this.setState({
            blogs: this.props.blogs,
            minutes,
            blog_details: this.props.blogs?.[0].field_blogs_export,
          })
        } catch (e) {
          console.log(e)
          this.handleClick(this.props.blogid);
        }
      });
    } else {
      const url = window.location.href;
      const array_url = url.split("/")
      const last_element = array_url.pop()
      // const id = this.props.match.params.id;
      const id = this.props.id || last_element;
      console.log('> Blog Details Page >> ', id)
      console.log('> Blog Page: Fallback')
      getAllInsights()
        .then(res => {
          var found = res.find(
            function (post, index) {
              return post.view_node?.includes(id)
            });
          console.log(res)
          console.log(found.nid)
          let removenode = res.filter(function (e) { return e.nid != found.nid; });
          this.setState({
            items: removenode,
            blogid: found.nid,
            isLoading: false
          });
          this.handleClick(found.nid);

        })
        .catch(error => {
          console.error(error);
          this.setState({
            error: true
          });
        });
    }
  }

  // response for the particular node and with respect to that, in sldier that particular node doesn't collide, strigify function used
  handleClick = (nid) => {
    fetch(`${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/insights-listing-node/` + nid
    )
      .then(res => res.json())
      .then(res => {
        console.log("RES", res[0].field_blogs_export)
        const totalwords = JSON.stringify(res[0].field_blogs_export).split(' ').length;
        const m = Math.ceil(totalwords / 225)
        this.setState({
          minutes: m,
          blogs: res,
          blog_details: res[0].field_blogs_export,
        });
      })
      .catch(error => {
        console.error(error);
        this.setState({
          error: true
        });
      });
  };

  // componentWillUnmount() {
  //   window.removeEventListener("scroll", this.scrollProgress);
  // }

  // progressbar for the page designed as per javascript documentation and styling done as per required
  scrollProgress = () => {
    const scrollpx = document.documentElement.scrollTop;
    // console.log(scrollpx)
    const winheightpx = document.documentElement.scrollHeight - document.documentElement.clientHeight;
    const scrolled = `${scrollpx / winheightpx * 100}%`;
    // console.log(scrolled)
    this.setState({
      scrolled: scrolled
    });
  };
  messageForComment() {
    alert("comments will be shown later...thankyou..")
  }
  render() {
    // console.log(this.state.blog_details[2])
    // console.log(process.env.REACT_APP_AMEEXDIGITAL)

    // slick slider infinite roller and content restrition managed using props 
    var blogdetails = {
      dots: true,
      infinite: true,
      slidesToShow: 4,
      slidesToScroll: 1,
      mobileFirst: !0,
      responsive: [{
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
          infinite: true,

        }
      }, {
        breakpoint: 900,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
          infinite: true,
        }
      }, {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          infinite: true,
        }
      }, {
        breakpoint: 319,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          infinite: true,
        }
      }]
    }
    const progressContainerStyle = {
      background: "none",
      boxShadow: "0 2px 4px rgba(0, 0, 0,0)",
      height: "5px",
      position: "fixed",
      top: "66.5px",
      left: 0,
      width: "100vw",
      zIndex: 99
    };

    const progressBarStyle = {
      height: "6px",
      top: "66.5px",
      background: "#ffda41",
      width: this.state.scrolled
    };
    // console.log(this.props.blogs?.[0].field_meta_title)
    return (
      <>
      <MetaDecorator
          description={parse(this.props.blogs?.[0].field_meta_description)}
          title={parse(this.props.blogs?.[0].field_meta_title)}
          href={this.props.blogs?.[0].field_meta_canonical_url}
        />
        {
          this.state.blogs[0] && this.state.blogs[0].field_schema_types_export?.map((data) =>
            <Schema data={JSON.parse(data.body)} />
          )
        }
        <div className="service-detail">
          <div className='DesktopBlogDetail'>
            {/* {this.state.blogs.map(({ field_meta_title, field_meta_description, field_meta_image, field_meta_canonical_url }, index) => (<MetaDecorator key={index}
            description={parse(field_meta_description)}
            // title={parse(field_meta_title)}
            // image={parse(field_meta_image)}
            image={field_meta_image}
            href={field_meta_canonical_url}
          />
          ))} */}
            <div className="container-fluid">
              <div className="progress-container" style={progressContainerStyle}>
                <div className="progress-bar" style={progressBarStyle} />
              </div>
              <div className="wrapper">
                <div className="row">
                  <div className='col-lg-2'>
                    <div className='blog'>
                      <div className="social-icons soc-ico-wrapper">
                        <ul>
                          <li><a href="https://twitter.com/AmeexDigital" target="_blank"> <span className="amd-twitter"></span></a></li>
                          <li><a href="https://www.facebook.com/Ameex_Digital-101893662036320" target="_blank"> <span className="amd-facebook"></span></a></li>
                          <li><a href="https://www.youtube.com/channel/UC5sHd3vyJISHaTFLx8Vvmyg" target="_blank"> <span className="amd-youtube"></span></a></li>
                        </ul>
                      </div>
                    </div>

                  </div>
                  <div className='col-lg-10'>
                    <VideoModal
                      show={this.state.showModal}
                      onClose={this.handleCloseModal}
                      url={this.state.videoUrl}
                      title={this.state.modelContent}
                      backLink='Back to page'
                    />

                    {!this.state.blogs.length && this.state.isLoading ?
                      <div className='divcls'>
                        <p className='auth-name'>
                          <ReactPlaceholder type="rect" color="#1c1d21" ready={false} showLoadingAnimation={true}></ReactPlaceholder>
                          <ReactPlaceholder type="text" color="#1c1d21" rows={2} style={{ width: "700px", fontSize: "30px", marginTop: "40px" }} ready={false} showLoadingAnimation={true}></ReactPlaceholder>
                          <ReactPlaceholder type="rect" style={{ marginTop: "30px" }} ready={false} showLoadingAnimation={true}></ReactPlaceholder>
                        </p>
                        <picture>
                          <ReactPlaceholder type='rect' style={{ width: "90%", height: "602px", marginTop: "200px" }} ready={false} showLoadingAnimation={true}></ReactPlaceholder>
                          {/* <p className='videotext'><ReactPlaceholder type = "rect" ready={false} showLoadingAnimation={true}></ReactPlaceholder></p> */}
                        </picture>
                      </div>
                      : null}
                    {/* </div> */}

                    <div className="header-top-blog">
                      {this.state.blogs.map(
                        ({ title, field_auth, field_page_category, field_authors_date, field_watch_video_link, field_mobile_video_thumbnail, field_video_thumbnail_image }, index) => (
                          <div className='divcls' key={index}>

                            <h1 className='blog-title'>
                              <p className='text-style-1'><b>{parse(field_page_category)}</b>&nbsp;|&nbsp;{this.state.minutes} Minute Read</p>
                              {parse(title)}
                            </h1>
                            <p className='auth-name'>{field_auth} | {field_authors_date} </p>
                            {(field_watch_video_link.length) ?
                              <div className="video-blog">
                                <picture>
                                  <source media="(max-width: 767px)" srcSet={field_mobile_video_thumbnail} />
                                  <LazyLoadImage effect="blur" className='sampleimg' src={field_video_thumbnail_image} alt='' />
                                </picture>
                                <p className='videotext-1'>Watch the video related to this article</p>
                                <p className='videotext'> {title} </p>
                                <div className='videothumb amd-play3' onClick={this.handleOpenModal.bind(this, title, field_watch_video_link)} style={{ cursor: "pointer" }}><span></span></div>
                              </div>
                              : null}
                          </div>
                        )
                      )}
                    </div>

                    <div className='divcls'>
                      <h3 className='In-This-Article'>In This Article</h3>
                      {/* <div> */}
                      {!this.state.blogs.length ?
                        <div className='Section-Header-1'>
                          <ReactPlaceholder type="text" rows={1} style={{ width: "700px", marginTop: "10px" }} ready={!this.state.isLoading} showLoadingAnimation={true}>
                            <hr className='Line-3' />
                          </ReactPlaceholder>
                        </div>
                        : null
                      }
                      {/* </div> */}
                      <div>
                        {this.state.blog_details.map(
                          ({ blog_title }, index) =>
                          (<div key={index} className='Section-Header-1'><Lk to={"section" + index} spy={true} offset={-90}>{blog_title}</Lk>
                            <hr className='Line-3' />
                          </div>
                          ))}
                      </div>
                      {/* {this.state.blogs.map(
                      ({ field_insight_description }, index) => (
                        <p className='Introductory-paragra' key={index}>
                          {field_insight_description}
                        </p>
                      ))} */}
                      <div id='section'>
                        {this.state.blog_details.map(
                          ({ blog_title, blogs_description, blog_image_1 }, index) => (
                            <div id={'section' + index} key={index}>
                              <h3 className='sectionheader'>{blog_title}</h3>
                              {blogs_description &&
                                blogs_description.map(({ blog_description, blog_description_html }, index) => (
                                  <div key={index}>
                                    {/* <br></br> */}
                                    {blog_description_html ?
                                      <div dangerouslySetInnerHTML={{ __html: blog_description_html }} className='Introductory-paragra'>
                                      </div>

                                      :
                                      <div className='Introductory-paragra'>{blog_description}
                                      </div>}
                                  </div>
                                ))}
                              {blog_image_1 && <img className="Bitmap" src={blog_image_1} alt='bitmap' />}
                            </div>
                          ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className='blogslider'>
              <section className="feed">

                <div className='container'>
                  <div className='row'>
                    <div className='col-lg-2'></div>
                    <div className='col-lg-10'>
                      <hr className='Line-2' />

                    </div>
                  </div>
                </div>
              </section>
              <div className="main-b">
                <div className="horizontal-line-recommended-1-b"></div>
                <p className="recommended-b">Recommended Articles</p>
                <div className="horizontal-line-recommended-2-b"></div>
              </div>
              <Slider {...blogdetails}>
                {this.state.items.map(
                  ({ title, field_insight_description, field_read_more_text, field_wa, field_watch_video_link, nid, view_node }, index) => (
                    <div className="col-md-4 col-sm-4 col-xs-12 blog-list" key={index}>
                      <p className="title-b"><span>{parse(title)}</span></p>
                      <p className="main_data-b"><span>{parse(field_insight_description)}</span></p>
                      <div className="link-sec">
                        <ul>
                          <li><Link href={`${view_node}`}><a style={{ cursor: "pointer" }} onClick={() => this.handleClick(nid)}><span className="read-article amd-readarticle"></span>{field_read_more_text}</a></Link></li>
                          {(field_watch_video_link.length) ?
                            <li><a href="#" onClick={this.handleOpenModal.bind(this, title, field_watch_video_link)}><span className="watch-video amd-play3"></span> {field_wa}</a></li>
                            : null}
                        </ul>
                      </div>
                      <div className="vertical-line-b">
                        <div className="horizontal-line-b">
                        </div>
                      </div>
                    </div>
                  ))}
              </Slider>
              <div className="down-line"></div>
            </div>
            <br />
            <MonthlyBudget />
          </div>
        </div>
      </>
    )
  }
}

export default Blog;