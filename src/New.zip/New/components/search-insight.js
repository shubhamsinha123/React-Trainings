import React, { useState } from "react";
import axios from "axios";
// import Modal from 'react-modal';
import VideoModal from "../components/common/VideoModal/VideoModal";
import { withRouter } from "next/router";
import MonthlyBudget from '../components/common/monthlyBudget/monthlybudget';


class Searchinsights extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isListActive: true,
      data: [],
      value: '',
      result: this.props.router.query.result,
    };
  }

  ToggleButton(type) {
    const view = type == "list" ? true : false;
    this.setState({
      isListActive: view,
    });
    console.log(view);
  }
  searchapi() {
    // var limited = qs.parse(, {
    //   ignoreQueryPrefix: true,
    // });
    // console.log(limited);
    //get api from 
    console.log(this.state.result);
    axios
      .get(
        `${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/search/insights-node?keys=${this.state.result}`
      )
      .then((res) => {
        console.log(res.data);
        this.setState({
          data: res.data,
          result: this.props.router.query.result,
        });
      });
  }


  handleChange = (e) => {
    console.log(e.target.value);
    this.setState({
      value: e.target.value,
    })
  }
  handleClick = (e) => {
    // alert("abc")
    e.preventDefault();
    this.props.router.push(`/searchinsights?result=${this.state.value}`);
    window.location.assign(`/searchinsights?result=${this.state.value}`);
    // window.location.reload();
  }
  handleSubmit = (e) => {
    e.preventDefault();
    console.log(this.state.value);
    this.props.router.push(`/searchinsights?result=${this.state.value}`);

  }

  componentDidMount() {
    this.searchapi();
  }

  render() {
    {
      console.log(this.state.isListActive ? "list" : "grid");
      console.log(this.props);
      console.log(this.props.router.query.result);
      console.log(this.state.data);
    }
    return (
      <>
        {/* <section className="service-detail"> */}
        <section className="insights-banner-wrapper mob-search-insights">
          <div className="container-fluid">
            <div className="wrapper insights-banner">
              <div className="row">
                <div className="col-12">
                  <h1>Search Results</h1>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section className="insights-search-wrapper">
          <div className="container-fluid">
            <div className="wrapper insights-search-seainsight mob-insights-search">
              <div className="row">
                <div className="col-12">
                  <div class="search-container-insight-result">
                    <form onSubmit={this.handleSubmit}>
                      <input
                        class="insights-input"
                        type="text"
                        placeholder="Search Insights Library"
                        name="search"
                        value={this.state.value}
                        onChange={this.handleChange}
                      />
                      <button type="submit" class="insights-btn" onClick={this.handleClick}>
                        <span className="search-icon amd-search"></span>
                      </button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section className="insights-tab-wrapper search-insights-wrapper">
          <div className="container-fluid">
            <div className="wrapper">
              <div className="row">
                <div className="search-vertical-line"></div>
                <div className="search-top-list">
                  <ul>
                    <li>
                      {this.state.data.length} results found for {this.state.result}
                    </li>
                    <li>
                      View: &nbsp;&nbsp;
                      <span className={this.state.isListActive ? "linelistgrid" : null} onClick={() => this.ToggleButton("list")}>
                        {" "}
                        List{" "}
                      </span>
                      {"|"}
                      <span className={this.state.isListActive ? null : "linelistgrid"} onClick={() => this.ToggleButton("grid")}>
                        {" "}
                        Grid{" "}
                      </span>
                    </li>
                  </ul>
                  <br />
                  {this.state.isListActive ? (
                    <List name="List" content={this.state.data} value={this.state.result} />
                  ) : (
                    <Grid name="Grid" content={this.state.data} value={this.state.result} />
                  )}
                </div>
              </div>
            </div>
          </div>
        </section>
        <MonthlyBudget />
        {/* </section> */}
      </>
    );

  }
}

function List(props) {
  return (
    <section id="listview">
      {/* <h1>Hello, List</h1> */}

      {props.content.length == 0 ? (
        <h1>No data found for {props.value}</h1>
      ) : (
        props.content.map((item, index) => (
          <div className="results-search">
            <h4><a href={`${item.view_node}`}><span>{item.title}</span></a> | {item.type}</h4>
            <p>{item.body}</p>
          </div>
        ))
      )}


    </section>
  );
}
function Grid(props) {
  const [showModal, setshowModal] = useState(false)
  const [modelContent, setmodalContent] = useState("")
  const [videoUrl, setvideoUrl] = useState("")

  function handleOpenModal(title_head, url_video) {
    setshowModal(true)
    setmodalContent(title_head)
    setvideoUrl(url_video)
  }

  function handleCloseModal() {
    setshowModal(false)
  }
  return (
    <>
      <VideoModal
        show={showModal}
        onClose={handleCloseModal}
        url={videoUrl}
        title={modelContent}
        backLink='Back to page'
      />

      <section className="search-grid" id="gridview">
        {/* <h1>Hello, Grid</h1> */}

        {props.content.length == 0 ? (
          <h1>No data found for {props.value}</h1>
        ) : (
          props.content.map((item, index) => (
            <div className="insights-vc search-insights-white-box">
              {item.field_mobile_video_thumbnail_export !== null ? (
                <img src={item.field_mobile_video_thumbnail_export} alt="ameex" />
              ) : (<img src={'/assets/images/article-default-thumbnail.png'} alt="logo" />
              )}
              <h4><span>{item.title}</span></h4>
              <p><span>{item.body}</span></p>

              <div className="link-sec">
                <ul>
                  <li>
                    <a href={`${item.view_node}`}>
                      <span className="read-article amd-readarticle"></span>{item.field_read_more_text}
                    </a>
                  </li>
                  {(item.field_watch_video_link.length) ?
                    <li><a href="#" onClick={() => { handleOpenModal(item.title, item.field_watch_video_link) }}><span className="watch-video amd-play3"></span> {item.field_wa}</a></li>
                    : null}

                </ul>
              </div>
            </div>
          ))
        )}

      </section>
    </>
  );
}

export default withRouter(Searchinsights);



