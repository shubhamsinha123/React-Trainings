import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Link from "next/link";
import ReactPlaceholder from 'react-placeholder';
import { useQuery } from 'react-query'
import styles from './Footer.module.scss'

const getDataPromise = (url, options) => {
    return new Promise((resolve, reject) => {
        fetch(url)
            .then(res => res.json())
            .then(result => {
                if (options.list) {
                    if (options.firstItem && Array.isArray(result) && result.length) {
                        resolve(result || [])
                    }
                } else {
                    resolve(result)
                }
            })
            .catch(e => {
                reject(e)
            })
    })
}
export const getFooterComp = () => {
    const url = `${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/header-footer`;
    return getDataPromise(url, {
        list: true,
        firstItem: true
    })
}
var ApiUrl = `${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}`
var newApiUrl = ApiUrl.replace("api", "");

const GlobalFooter = ({ data = [] }) => {
    const [email, setEmail] = useState("");
    const [errors, setErrors] = useState({ email: "" });
    const [success, setSuccess] = useState("");

    const footerData = useQuery('header-footer', getFooterComp, {
        initialData: data || [],
        refetchOnMount: false,
        refetchOnWindowFocus: false,
    })

    useEffect(() => {
        if (!data?.length) {
            footerData.refetch();
        }
    }, [])

    const validateEmail = () => {
        // let email = email;
        let errors = {};
        let isValid = true;
        if (!email) {
            isValid = false;
            errors["email"] = "Please enter your email Address.";
        }
        if (typeof email !== "undefined") {
            var patternemail = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
            if (!patternemail.test(email)) {
                isValid = false;
                errors["email"] = "Please enter valid email address.";
            }
        }
        setErrors(errors);
        return isValid;
    }
    const onChangeUserEmail = (e) => {
        setEmail(e.target.value.replace(/\s/g, ""), { errors: "" }, { success: "" })
    }
    const onSubmit = (e) => {
        e.preventDefault();
        const userObject = {
            webform_id: "subscribe",
            email: email,
        }
        if (validateEmail()) {
            axios.post(`${newApiUrl}webform_rest/submit`, userObject).then((result) => {
                if (result) {
                    setSuccess("Subscribed successfully.")
                }
            }).catch((error) => {
                let errors = {};
                console.log(error.response)
                console.log(error.response.data)
                console.log(error.response.data.error.email)
                if (error.response.data.error.email) {
                    errors["email"] = error.response.data.error.email;
                    setErrors(errors);
                }
            });
            setEmail("");
        }
    };
    return (
        <>
            <section className={styles.footerSection} id="footerSection">
                <div className="container-fluid">
                    <div className="wrapper">
                        <div className={styles.ameexTechnology}>
                            <ReactPlaceholder type='round' style={{ width: "224px", height: "30px", borderradius: "50%", marginLeft: "42%" }} ready={!footerData.isLoading} showLoadingAnimation={true}>
                                <picture className="ameex-technology-images">
                                    <source media="(max-width: 767px)" srcSet={'/assets/images/group-22.svg'} />
                                    <img src={'/assets/images/group-22.svg'} alt="ameex-technology" loading="lazy" />
                                </picture>
                            </ReactPlaceholder>
                        </div>
                        <div className="row">
                            <div className="col-xl-5 col-lg-5  col-md-5 col-sm-5 col-xs-12">
                                <div className={styles.about}>
                                    <ReactPlaceholder type='text' rows={1} ready={!footerData.isLoading} showLoadingAnimation={true} style={{ width: "33%", marginLeft: "0%" }}>
                                        <b>{footerData?.data?.[11]?.field_name}</b>
                                    </ReactPlaceholder>

                                    <ReactPlaceholder type='text' rows={6} ready={!footerData.isLoading} showLoadingAnimation={true} style={{ width: "33%", marginLeft: "0%" }}>
                                        <p>
                                            <span dangerouslySetInnerHTML={{ __html: footerData?.data?.[11]?.description__value }}></span>
                                        </p>
                                    </ReactPlaceholder>

                                    <span className={styles.footerIndustries}>
                                        <ReactPlaceholder type='text' rows={1} ready={!footerData.isLoading} showLoadingAnimation={true} style={{ width: "33%", marginLeft: "0%" }}>
                                            <Link href='/about-us' scroll={false}><a className="amd-yellow-arrow"><span className={styles.footerFont}>{footerData?.data?.[11]?.field_read_more_text}</span></a></Link>
                                        </ReactPlaceholder>
                                    </span>
                                </div>
                            </div>
                            <div className=" col-xl-2 col-lg-2  col-md-2 col-sm-3 col-xs-12">
                                <div className={styles.deliver}>
                                    <ReactPlaceholder type='text' rows={1} ready={!footerData.isLoading} showLoadingAnimation={true} style={{ width: "33%", marginLeft: "0%" }}>
                                        <b>{footerData?.data?.[12]?.name}</b>
                                    </ReactPlaceholder>

                                    <ul>
                                        <li>
                                            <ReactPlaceholder type='text' rows={1} ready={!footerData.isLoading} showLoadingAnimation={true} style={{ width: "33%", marginLeft: "0%" }}>
                                                <Link href="/service" scroll={false}><a>{footerData?.data?.[13]?.name}</a></Link>
                                            </ReactPlaceholder>
                                        </li>
                                        <li>
                                            <ReactPlaceholder type='text' rows={1} ready={!footerData.isLoading} showLoadingAnimation={true} style={{ width: "33%", marginLeft: "0%" }}>
                                                <Link href="/case-studies-list" scroll={false}><a>{footerData?.data?.[10]?.field_name}</a></Link>
                                            </ReactPlaceholder>
                                        </li>
                                        <li>
                                            <ReactPlaceholder type='text' rows={1} ready={!footerData.isLoading} showLoadingAnimation={true} style={{ width: "33%", marginLeft: "0%" }}>
                                                <Link href="/about-us" scroll={false}><a>{footerData?.data?.[15]?.name}</a></Link>
                                            </ReactPlaceholder>

                                        </li>
                                        <li>
                                            <ReactPlaceholder type='text' rows={1} ready={!footerData.isLoading} showLoadingAnimation={true} style={{ width: "33%", marginLeft: "0%" }}>
                                                <Link href="/insights" scroll={false}><a>{footerData?.data?.[16]?.name}</a></Link>
                                            </ReactPlaceholder>

                                        </li>
                                        <li>
                                            <ReactPlaceholder type='text' rows={1} ready={!footerData.isLoading} showLoadingAnimation={true} style={{ width: "33%", marginLeft: "0%" }}>
                                                <Link href="/contact-us" scroll={false}><a>{footerData?.data?.[17]?.name}</a></Link>
                                            </ReactPlaceholder>

                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div className=" col-xl-5 col-lg-5  col-md-5 col-sm-12 col-xs-12">
                                <div className={styles.multiple}>
                                    <ReactPlaceholder type='text' rows={1} ready={!footerData.isLoading} showLoadingAnimation={true} style={{ width: "33%", marginLeft: "0%" }}>
                                        <b>{footerData?.data?.[18]?.name}</b>
                                    </ReactPlaceholder>
                                    <ReactPlaceholder type='text' rows={2} ready={!footerData.isLoading} showLoadingAnimation={true} style={{ width: "33%", marginLeft: "0%" }}>
                                        <p>{footerData?.data?.[18]?.field_description}</p>
                                    </ReactPlaceholder>

                                    <div className={styles.subScribe}>
                                        <form onSubmit={onSubmit}>
                                            <ReactPlaceholder type='text' rows={1} ready={!footerData.isLoading} showLoadingAnimation={true} style={{ width: "33%", marginLeft: "0%" }}>
                                                <input type="text" placeholder="Your Email..." value={email} onChange={onChangeUserEmail} />
                                            </ReactPlaceholder>

                                            <ReactPlaceholder type='text' rows={1} ready={!footerData.isLoading} showLoadingAnimation={true} style={{ width: "33%", marginLeft: "0%" }}>
                                                <button className={styles.btnSub} href={footerData?.data?.[18]?.field_read_more_link}>{footerData?.data?.[18]?.field_read_more_text}</button>
                                            </ReactPlaceholder>
                                        </form>
                                        {success ? (<div className={styles.subscribeSuccess}>{success}</div>) : (<div className={styles.formerrorFooter}>{errors.email}</div>)}


                                    </div>
                                    <div className={styles.socialIcons}>
                                        <ul>
                                            <li>
                                                <ReactPlaceholder type='round' style={{ width: "60px", height: "60px", borderradius: "50%", marginLeft: "0%", marginRight: "9px" }} ready={!footerData.isLoading} showLoadingAnimation={true}>
                                                    <a href="https://twitter.com/AmeexDigital" target="_blank"><span className="amd-twitter"></span></a>
                                                </ReactPlaceholder>

                                            </li>
                                            <li>
                                                <ReactPlaceholder type='round' style={{ width: "60px", height: "60px", borderradius: "50%", marginLeft: "0%", marginRight: "9px" }} ready={!footerData.isLoading} showLoadingAnimation={true}>
                                                    <a href="https://www.facebook.com/Ameex_Digital-101893662036320" target="_blank"><span className="amd-facebook"></span></a>
                                                </ReactPlaceholder>
                                            </li>
                                            <li>
                                                <ReactPlaceholder type='round' style={{ width: "60px", height: "60px", borderradius: "50%", marginLeft: "0%", marginRight: "9px" }} ready={!footerData.isLoading} showLoadingAnimation={true}>
                                                    <a href="https://www.youtube.com/channel/UC5sHd3vyJISHaTFLx8Vvmyg" target="_blank"><span className="amd-youtube"></span></a>
                                                </ReactPlaceholder>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <footer className={styles.footer}>
                <ReactPlaceholder type='text' rows={1} ready={!footerData.isLoading} showLoadingAnimation={true} style={{ width: "33%", marginLeft: "34%" }}>
                    <p><span>{footerData?.data?.[20]?.field_name} | <Link href="/privacy-policy-statement" scroll={false}><a>{footerData?.data?.[20]?.field_bottom_text}</a></Link></span></p>
                </ReactPlaceholder>
            </footer>
        </>
    );
}
export default GlobalFooter;