import React from "react"
import Head from 'next/head'

const MetaDecorator = ({ title, description, href, image }) => {
  return (
    <Head>
      <title>{title}</title>
      <meta property="og:title" content={title} />
      <meta name="description" content={description} />
      <meta property="og:description" content={description} />
      <meta name="image" content={image} />
      <meta name="og:image" content={image} />
      <link rel="canonical" href={href} />
    </Head>
  );
};

export default MetaDecorator;