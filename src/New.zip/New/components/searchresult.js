import React from 'react';
import axios from 'axios';
import MonthlyBudget from '../components/common/monthlyBudget/monthlybudget';
import Link from 'next/link';
import VideoModal from './common/VideoModal/VideoModal';
import MetaDecorator from '../components/Util/MetaDecorator';
import { withRouter } from "next/router";

class SearchResult extends React.Component {

    constructor(props) {
        super(props);
        this.gridview = this.gridview.bind(this);
        this.listview = this.listview.bind(this);
        this.onChangeResultType = this.onChangeResultType.bind(this);
        this.onChangeInnerSearchKeyValue = this.onChangeInnerSearchKeyValue.bind(this);
        this.innersearchkeyupdate = this.innersearchkeyupdate.bind(this);
        this.loadMore = this.loadMore.bind(this);
        this.onSubmit = this.onSubmit.bind(this);
        this.handleOpenModal = this.handleOpenModal.bind(this);
        this.handleCloseModal = this.handleCloseModal.bind(this);
        // this.loadMoreStatus =  this.loadMoreStatus.bind(this);
        this.onChangeSort = this.onChangeSort.bind(this);
        const state = {
            query: '',
            results: [],
            filteredResult: [],
            results_backup: [],
            loading: false,
            message: '',
            // results_tilte: [],
            grid_view: false,
            list_view: false,
            checkedItems: new Map(),
            filterArray: [],
            innersearchkeyvalue: '',
            innersearchkeyvalueshow: "",
            visibleitem: 4,
            loadmoreinvisible: false,
            loaditem: 4,
            showModal: false,
            modelContent: "",
            videoUrl: "",
            resultLength: 0,
            sortingvalue: "",
        }
        this.state = state;
        this.cancel = '';
    }
    handleOpenModal(url_video) {
        this.setState({ showModal: true, videoUrl: url_video });
        console.log(this.state.videoUrl);
    }

    handleCloseModal() {
        this.setState({ showModal: false });
    }
    componentDidMount() {
        // const query = this.props.match.params.result;
        const url = window.location.href;
        const array_url = url.split("/")
        const last_element = array_url.pop()
        // const id = this.props.match.params.id;
        const query = this.props.id || last_element;
        console.log('Search Insights Page >> ', query)
        if (!query) {
            this.setState({ query, results: {}, message: '' });
        } else {
            this.setState({ query, loading: true, message: '' }, () => {
                this.fetchSearchResults(1, query);
            });
        }
        console.log(query);
        this.setState({ innersearchkeyvalue: query }, () => {
            if (this.state.innersearchkeyvalue !== "") {
                console.log("searchvalue");
                this.setState({ innersearchkeyvalueshow: this.state.innersearchkeyvalue });
            }
        });
        console.log(this.state.innersearchkeyvalue);
        if (window.innerWidth <= 767) {
            this.setState({ visibleitem: 4, loaditem: 4 });
        } else if (window.innerWidth > 767) {
            this.setState({ visibleitem: 10, loaditem: 10 });
        }
    }

    loadMore() {
        if (this.state.visibleitem + this.state.loaditem >= this.state.results.length) {
            this.setState({ loadmoreinvisible: true });
        }
        if (this.state.visibleitem < this.state.results.length) {
            this.setState((prev) => {
                if ((this.state.visibleitem + this.state.loaditem) > this.state.results.length) {
                    return { visibleitem: this.state.results.length };
                } else {
                    return { visibleitem: prev.visibleitem + this.state.loaditem };
                }
            });
        }

    }
    gridview() {
        this.setState({ grid_view: true, list_view: false })
    }
    listview() {
        this.setState({ list_view: true, grid_view: false })
    }
    onChangeSort(e) {
        const query = this.state.innersearchkeyvalue;
        console.log(e.target.value);
        this.setState({ sortingvalue: e.target.value })
        console.log(this.state.sortingvalue);
        // this.fetchSearchResults();
        if (!query) {
            this.setState({ query, results: {}, message: '' });
        } else {
            this.setState({ query, loading: true, message: '' }, () => {
                this.fetchSearchResults(1, query);
            });
        }
    }
    onChangeInnerSearchKeyValue(e) {
        this.setState({ innersearchkeyvalue: e.target.value })
    }

    innersearchkeyupdate(event) {
        event.preventDefault();
        console.log("hi");
        console.log(this.state.innersearchkeyvalue);
        if (this.state.innersearchkeyvalue !== "") {
            console.log("not empty");
            var query = this.state.innersearchkeyvalue;
            console.log(query);
            if (!query) {
                this.setState({ query, results: {}, message: '' });
                console.log("if");

            } else {
                this.setState({ query, loading: true, message: '' }, () => {
                    console.log("got to fetch result");
                    this.fetchSearchResults(1, query);

                });
                console.log("else");
            }
            this.setState({ innersearchkeyvalueshow: this.state.innersearchkeyvalue })
        }
    }
    onSubmit(event) {
        event.preventDefault();
        if (this.state.innersearchkeyvalue !== "") {
            console.log("not empty");
            const query = this.state.innersearchkeyvalue;
            if (!query) {
                this.setState({ query, results: {}, message: '' });
                console.log("if");

            } else {
                this.setState({ query, loading: true, message: '' }, () => {
                    this.fetchSearchResults(1, query);
                });
                console.log("else");
            }
            this.setState({ innersearchkeyvalueshow: this.state.innersearchkeyvalue })
        }
    }
    onChangeResultType(event) {
        var isChecked = event.target.checked;
        var item = event.target.value;
        this.setState(prevState => ({ checkedItems: prevState.checkedItems.set(item, isChecked) }));
        if (isChecked === true) {
            this.setState(prevState => {
                const val = [...prevState.filterArray, item];
                return {
                    filterArray: val,
                    filteredResult: prevState.results.filter(d => {
                        return val.find(data => {
                            return d.type.includes(data);
                        })
                    })

                }
            })
            console.log('state = ', this.state);
            console.log(this.state.filterArray);
            console.log(this.state.filteredResult);
            console.log(this.state.results);
            console.log(this.state.results_backup);
        } else {
            const index = this.state.filterArray.indexOf(item);
            if (index > -1) {
                this.setState(prevState => {
                    const val = [...prevState.filterArray];
                    val.splice(index, 1);
                    return {
                        filterArray: val,
                        filteredResult: prevState.results.filter(d => {
                            return val.find(data => {
                                return d.type.includes(data);
                            })
                        })
                    }
                })
            }
        }
    }
    fetchSearchResults = (updatedPageNo = '', query) => {
        const pageNumber = updatedPageNo ? `&page=${updatedPageNo}` : '';	// By default the limit of results is 20
        console.log("fetch search results");
        console.log(this.state.sortingvalue);
        var searchUrl;
        if (this.state.sortingvalue === 'relevance') {
            console.log("if");
            searchUrl = `${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/search/node?keys=${query}${pageNumber}`;
            console.log(searchUrl);
        } else if (this.state.sortingvalue === 'recently_added') {
            console.log("elseif");
            searchUrl = `${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/search/node?keys=${query}&sort_by=created&sort_order=DESC`;
            console.log(searchUrl);
        } else {
            console.log("else");
            searchUrl = `${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/search/node?keys=${query}${pageNumber}`;
            console.log(searchUrl);
        }
        // const searchUrl = process.env.REACT_APP_AMEEXDIGITAL + `/search/node?keys=${query}${pageNumber}`;	
        if (this.cancel) {
            // Cancel the previous request before making a new request
            this.cancel.cancel();
        }
        // Create a new CancelToken
        this.cancel = axios.CancelToken.source();
        axios.get(searchUrl, {
            cancelToken: this.cancel.token,
        })
            .then((res) => {
                console.log(res);
                const resultNotFoundMsg = !res.data.length ? 'There are no more search results. Please try a new search.' : '';
                this.setState({
                    results: res.data,
                    filteredResult: res.data,
                    results_backup: res.data,
                    message: resultNotFoundMsg,
                    loading: false
                });
                this.renderSearchResults();
            })
            .catch((error) => {
                if (axios.isCancel(error) || error) {
                    this.setState({
                        loading: false,
                        message: 'Failed to fetch results.Please check network',
                    });
                }
            });
    };

    renderSearchResults = () => {
        if (Object.keys(this.state.results).length && this.state.results.length) {
            if (this.state.filterArray.length > 0) {
                console.log("if");
                return (
                    <>
                        {this.state.filterArray.map((filtervalue, index) => {
                            console.log(filtervalue);
                            return (
                                <>
                                    <MetaDecorator />
                                    {
                                        this.state.results.filter(resulting => resulting.type.includes(filtervalue)).slice(0, this.state.visibleitem).map((result, index) => {
                                            return (
                                                <>
                                                    <div className="result-section-item" key={index}>
                                                        <div className="result-section-item-inner">
                                                            {result.field_desktop_image !== "" ? (
                                                                <div className="img-wrap">
                                                                    <picture className="result-image">
                                                                        <source media="(max-width: 767px)" srcSet={result.field_mobile_image} />
                                                                        <img className="" src={result.field_desktop_image} alt="ameex" />
                                                                    </picture>
                                                                </div>
                                                            ) : (
                                                                <div className="img-wrap">
                                                                    <a href="/#">
                                                                        <picture className="placeholder-image"> <img alt="logo" title="logo" className="default-img" src={'/assets/images/article-default-thumbnail.png'} /> </picture>
                                                                    </a>
                                                                </div>
                                                            )}
                                                            {result.title !== "" ? (
                                                                <h3><Link href={{ pathname: result.view_node }}><a className="category"><span className="title">{result.title}</span>    <span className="vertical-bar">|</span> <span className="type">{result.type}</span></a></Link></h3>
                                                            ) : (<></>)}
                                                            <div className="description">
                                                                <p>{result.body}</p>
                                                            </div>

                                                            <div className="row read-watch">
                                                                <div className="col-6"> <Link href={{ pathname: result.view_node }}><a className="read-article">{result.field_read_more_text}</a></Link> </div>
                                                                {result.field_watch_video_link !== "" ? (
                                                                    <div className="col-6">
                                                                        <a href="#" onClick={this.handleOpenModal.bind(this, result.field_watch_video_link)} className="watch-ideo">
                                                                            {result.field_watch_video_text}
                                                                        </a>
                                                                    </div>
                                                                ) : (<></>)
                                                                }
                                                            </div>
                                                        </div>
                                                    </div>
                                                </>
                                            );
                                        })
                                    }
                                </>
                            );
                        })
                        }
                    </>
                );
            } else {
                console.log("else");
                return (
                    <>
                        {
                            this.state.results.filter(resulting => resulting.type.includes(this.state.filterArray)).slice(0, this.state.visibleitem).map((result, index) => {
                                console.log("else map function")
                                return (
                                    //   <>  
                                    <div className="result-section-item" key={index}>
                                        {/* <span> {result}</span> */}
                                        <div className="result-section-item-inner">
                                            {result.field_desktop_image !== "" ? (
                                                <div className="img-wrap">
                                                    <picture className="result-image">
                                                        <source media="(max-width: 767px)" srcSet={result.field_mobile_image} />
                                                        <img className="" src={result.field_desktop_image} alt="ameex" />
                                                    </picture>
                                                </div>
                                            ) : (
                                                <div className="img-wrap">
                                                    <a href="/#">
                                                        <picture className="placeholder-image"> <img alt="logo" title="logo" className="default-img" src={'/assets/images/article-default-thumbnail.png'} /> </picture>
                                                    </a>
                                                </div>
                                            )}
                                            {result.title !== "" ? (
                                                <h3><Link href={{ pathname: result.view_node }}><a className="category"><span className="title">{result.title}</span>    <span className="vertical-bar">|</span> <span className="type">{result.type}</span></a></Link></h3>
                                            ) : (<></>)}
                                            <div className="description">
                                                <p>{result.body}</p>
                                            </div>

                                            <div className="row read-watch">
                                                <div className="col-6"> <Link href={{ pathname: result.view_node }}><a className="read-article">{result.field_read_more_text}</a></Link> </div>
                                                {result.field_watch_video_link !== "" ? (
                                                    <div className="col-6">
                                                        <a href="#" onClick={this.handleOpenModal.bind(this, result.field_watch_video_link)} className="watch-ideo">
                                                            {result.field_watch_video_text}
                                                        </a>
                                                    </div>
                                                ) : (<></>)
                                                }
                                            </div>


                                        </div>
                                    </div>
                                    //  </>
                                );
                            })
                        }

                    </>
                );

            }
        } else {
            console.log(this.state.results.length);
            return (
                <>
                    <div className="result-not" >There are no more search results</div>
                </>
            );
        }
    };
    render() {
        return (
            <>
                {/* <p>This is Search result page {this.props.params.result}</p> */}
                {/* <p>This is Search result page{this.props.match.params.result}</p> */}
                <>
                    <section className="searchresult-wrapper">
                        <div className="title-banner">
                            <div className="container-fluid">
                                <div className="wrapper">
                                    <div className="row">
                                        <div className="col-12">
                                            <h1>Search Results</h1>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="search-banner">
                            <div className="container-fluid">
                                <div className="wrapper">
                                    <div className="row">
                                        <div className="col-12">
                                            <form className="form-inner-wrapper" autoComplete="off" onSubmit={this.onSubmit}>
                                                <div className="form-inner">
                                                    <input className="form-control search-box mr-sm-2" type="text" placeholder="Search" aria-label="Search" name="innersearchkeyvalue" value={this.state.innersearchkeyvalue} onChange={this.onChangeInnerSearchKeyValue} />
                                                    <button className="btn  search-btn amd-search my-2 my-sm-0" type="button" onClick={this.innersearchkeyupdate}></button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="results-container">
                            <div className="container-fluid">
                                <div className="wrapper">
                                    <div className="row">
                                        <div className="col-md-2">
                                            <div className="refine-section">
                                                <div className="total-result-top">{this.state.results.filter(resulting => resulting.type.includes(this.state.filterArray)).slice(0, this.state.visibleitem).length} results found for {this.state.innersearchkeyvalueshow}</div>
                                                <h2>REFINE</h2>
                                                <div className="refine-cont">
                                                    <div className="refine-item">
                                                        <input type="checkbox" id="services" value="Service" onChange={this.onChangeResultType} class="filter-chkbox" />
                                                        <label htmlFor="services"><div class="search-filter">Services</div></label>
                                                    </div>
                                                    <div className="refine-item">
                                                        <input type="checkbox" id="articles" value="Insights" onChange={this.onChangeResultType} class="filter-chkbox" />
                                                        <label htmlFor="articles"><div class="search-filter">Articles</div></label>
                                                    </div>
                                                    <div className="refine-item">
                                                        <input type="checkbox" id="casestudies" value="Case" onChange={this.onChangeResultType} class="filter-chkbox" />
                                                        <label htmlFor="casestudies"><div class="search-filter">Case Studies</div></label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div className={`col-md-10 normal-view ${this.state.grid_view === true ? 'gridview-show' : 'listview-show'}`}>
                                            <div className="result-wrapper">
                                                <div className="resultmenu-header">
                                                
                                                    <div className="total-result">{(this.state.filteredResult.length == this.state.results.length || this.state.filterArray.length == 0)  ? this.state.results.length : this.state.filteredResult.length} results found for {this.state.innersearchkeyvalueshow}</div>
                                                    <div className="list-grid">View: <span className="viewchange list" onClick={this.listview}>List</span> | <span className="viewchange grid" onClick={this.gridview}>Grid</span></div>
                                                    <div className="sort">
                                                        Sort: <select value={this.state.sortingvalue} onChange={this.onChangeSort}>
                                                            <option value="relevance"> Relevance </option>
                                                            <option value="recently_added"> Recently Added </option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div className="result-section">
                                                    <div className="row">
                                                        {this.renderSearchResults()}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    {this.state.results.length > 0 ? (
                                        <div className="row">
                                            <div className="col-12">
                                                {this.state.visibleitem < this.state.results.length ? (
                                                    <div className={`loadmore ${this.state.loadmoreinvisible === true ? 'invisible' : ""}`}>
                                                        {this.state.filteredResult.length > 10 ? (
                                                            <div className="loadmore-inner">
                                                                <div className="group-btn">
                                                                    <div className="bg-two">
                                                                        <button type="button" className="btn" onClick={this.loadMore}>LOAD MORE</button>
                                                                    </div>
                                                                </div>
                                                                <div className="show-result">
                                                                    {this.state.visibleitem > this.state.results.length ? (
                                                                        <>
                                                                            Showing {this.state.results.length} of {this.state.results.length} Result
                                                                        </>
                                                                    ) : (
                                                                        <>
                                                                            Showing {this.state.visibleitem} of {this.state.results.length} Result
                                                                        </>
                                                                    )
                                                                    }
                                                                </div>
                                                            </div>
                                                        ) : (<div></div>)
                                                        }
                                                    </div>
                                                ) : (
                                                    <> </>
                                                )
                                                }
                                            </div>
                                        </div>
                                    ) : (<></>)
                                    }
                                </div>
                            </div>
                        </div>
                        <div className="search-result-video-wrapper">
                            <VideoModal
                                show={this.state.showModal}
                                onClose={this.handleCloseModal}
                                url={this.state.videoUrl}
                                title={this.state.modelContent}
                                backLink='Back to page'
                            />
                        </div>
                    </section>

                    <MonthlyBudget />
                </>

            </>
        )
    }

}
export default withRouter(SearchResult);