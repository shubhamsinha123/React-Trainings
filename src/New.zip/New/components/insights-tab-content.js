import React from 'react';
import IndustryIndights from './industry-insights';
import InsightsSubscribe from './insights-subscribe';
import VideoModal from './common/VideoModal/VideoModal';
import ReactPlaceholder from 'react-placeholder';
import "react-placeholder/lib/reactPlaceholder.css";
import Link from 'next/link';
import 'react-lazy-load-image-component/src/effects/blur.css';
import { LazyLoadImage } from 'react-lazy-load-image-component';
import parse from 'html-react-parser';
import { getAllInsights } from '../services/insights.service';

const VideoThumbnail = ({ item, handleOpenModal, isLoading }) => (
  <div className="col-md-8 col-sm-8 col-xs-12 insights-video-left">
    <div className="video-content-wrapper">
      <div>
        <picture>
          <LazyLoadImage effect='blur' src={item.field_video_thumbnail_image} className="img-responsive thumb-image" />
        </picture>
        <a onClick={() => handleOpenModal(item.title, item.field_watch_video_link)} href="#">
          <span className="play-btn"></span>
        </a>
        <div className="video-content">
          <Link href={`${item.view_node}`}>
            <a>
              <h4>
                <ReactPlaceholder type='text' color='#C4C4C7' rows={2} ready={!isLoading} showLoadingAnimation={true}>
                  <span>{item.title}</span>
                </ReactPlaceholder>
              </h4>
            </a>
          </Link>
          <div className="video-content-date">
            <div className="au-date">
              <ReactPlaceholder type='text' style={{ display: 'none' }} rows={1} ready={!isLoading} showLoadingAnimation={false}>
                <span>{item.field_authors_date}</span>
              </ReactPlaceholder>
            </div>
            <div className="insight-read-art">
              <ReactPlaceholder type='text' style={{ display: 'none' }} rows={1} ready={!isLoading} showLoadingAnimation={false}>
                <Link href={`${item.view_node}`}><a className="read-art" style={{ cursor: "pointer" }}><span className="read-article-icon amd-readarticle"></span> {item.field_read_more_text}</a></Link>
              </ReactPlaceholder>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
)

const PATTERN = 'youtube';
class InsightsTabContent extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      results: [],
      visible: 6,
      error: false,
      showModal: false,
      modelContent: "",
      videoUrl: "",
      isLoading: true,
    };
    this.loadMore = this.loadMore.bind(this);
    this.showLess = this.showLess.bind(this);
  }

  handleOpenModal = (title_head, url_video) => {
    this.setState({ showModal: true, modelContent: title_head, videoUrl: url_video });
  }

  handleCloseModal = () => {
    this.setState({ showModal: false });
  }

  loadMore() {
    this.setState((prev) => {
      return { visible: prev.visible + 6 };
    });
  }
  showLess() {
    this.setState((prev) => {
      return { visible: prev.visible - 6 };
    });
  }

  componentDidMount() {
    window.scrollTo(0, 0);
    getAllInsights().then(res => {
      console.clear()
      // Filter video blog to show under All insights.
      // This will fetch the first blog that has video link.
      // That video blog will be shown under All insights section.
      var findyt = res.find(function (obj) {
        return obj.field_watch_video_link.includes(PATTERN);
      });
      console.log(findyt)
      var filteryt = res.filter(function (obj) { return !obj.nid.includes(findyt.nid); });
      console.log(filteryt)
      const results = findyt ? [{ ...findyt, videoLink: true }, ...filteryt] : [{}, ...filteryt];
      this.setState({
        results,
        isLoading: false
      });
    }).catch(error => {
      console.error(error);
      this.setState({
        error: true
      });
    });
  }

  render() {
    const category = this.state.results.filter(x => x.field_page_category.includes(this.props.name));
    if(category?.length) {
      // Each section/category should have the video blog(if it has any) as the first item to show the thumbnail
      // If not, we need to find a blog with a video link and change the position to first(0).
      const categoryVideoIndex = category.findIndex(x => x.field_watch_video_link?.includes(PATTERN));
      // Change the position only if the blog with the video link is not in 0th position
      if(categoryVideoIndex > 0) {
        const videoItem = category[categoryVideoIndex];
        category.splice(categoryVideoIndex, 1);
        category.unshift(videoItem);
      }
    }
    return (
      <>
        <section className="insights-content-wrapper">
          <div className="container-fluid">
            <div className="wrapper">
              <div className="row">
                <div className="col-md-12 col-sm-12 col-xs-12 insights-video-title">
                  <h3>
                    <ReactPlaceholder type='text' rows={1} color='#95969D' style={{ width: "300px" }} ready={!this.state.isLoading} showLoadingAnimation={true}>
                      <span>{this.props.field_name}</span>
                    </ReactPlaceholder>
                  </h3>
                  <p>
                    <ReactPlaceholder type='text' rows={1} style={{ width: "64%" }} ready={!this.state.isLoading} showLoadingAnimation={true}>
                      Discover innovative digital marketing solutions you can apply to your campaigns today.
                    </ReactPlaceholder>
                  </p>
                </div>
                <div className="col-md-12 col-sm-12 col-xs-12 insights-video">
                  <div className="row m-no-row">
                    <VideoModal
                      show={this.state.showModal}
                      onClose={this.handleCloseModal}
                      url={this.state.videoUrl}
                      title={this.state.modelContent}
                      backLink='Insights page'
                    />
                    {!category.length && this.state.isLoading ?
                      <picture>
                        <ReactPlaceholder type='rect' style={{ width: "800px", height: "500px" }} ready={!this.state.isLoading} showLoadingAnimation={true}></ReactPlaceholder>
                      </picture> : null
                    }

                    {
                      category[0] && category[0]?.field_watch_video_link ? (
                        <VideoThumbnail
                          item={category[0]}
                          isLoading={this.state.isLoading}
                          handleOpenModal={this.handleOpenModal} />
                      ) : (category[0] && (
                        <div className="col-md-4 col-sm-4 col-xs-12 insights-video-right">
                            <div className="col-md-12 col-sm-12 col-xs-12 insights-vc insights-white-box">
                              <h4>
                                <ReactPlaceholder type='text' color='#95969D' rows={2} ready={!this.state.isLoading} showLoadingAnimation={true}>
                                  <span><Link href={`${category[0]?.view_node}`}><a>{category[0]?.title}</a></Link></span>
                                </ReactPlaceholder>
                              </h4>
                              <p>
                                <ReactPlaceholder type='text' rows={3} ready={!this.state.isLoading} showLoadingAnimation={true}>
                                  <span>{category[0]?.field_insight_description}</span>
                                </ReactPlaceholder>
                              </p>
                              <div className="name-date">
                                <span className="name-date-icon">
                                  <picture>
                                    <ReactPlaceholder type='round' ready={!this.state.isLoading} showLoadingAnimation={true}>
                                      <LazyLoadImage effect='blur' src={category[0]?.field_authors_profile_image} className="img-responsive" />
                                    </ReactPlaceholder>
                                  </picture>
                                </span>
                                <p className="name">
                                  <ReactPlaceholder type='text' rows={1} ready={!this.state.isLoading} showLoadingAnimation={true}>
                                    {category[0]?.field_auth}
                                  </ReactPlaceholder>
                                </p>
                                <p className="date">
                                  <ReactPlaceholder type='text' rows={1} ready={!this.state.isLoading} showLoadingAnimation={true}>
                                    {category[0]?.field_authors_date}
                                  </ReactPlaceholder>
                                </p>
                              </div>
                              <div className="link-sec">
                                <ReactPlaceholder type='text' rows={1} ready={!this.state.isLoading} showLoadingAnimation={true}>
                                  <ul>
                                    <li><Link href={`${category[0]?.view_node}`}><a style={{ cursor: "pointer" }}><span className="read-article amd-readarticle"></span> {category[0]?.field_read_more_text}</a></Link></li>
                                    {(category[0]?.field_watch_video_link.length) ?
                                      <li><a href="#" onClick={() => this.handleOpenModal(category[0]?.title, category[0]?.field_watch_video_link)}><span className="watch-video"></span> {category[0]?.field_wa}</a></li>
                                      : null}
                                  </ul>
                                </ReactPlaceholder>
                              </div>
                            </div>
                          </div>)
                      )
                    }

                    <div className="col-md-4 col-sm-4 col-xs-12 insights-video-right">
                      {category.slice(1, 3).map((item, index) => {
                          return <div key={index} className="col-md-12 col-sm-12 col-xs-12 insights-vc insights-white-box" key={index}>
                            <h4>
                              <ReactPlaceholder type='text' color='#95969D' rows={2} ready={!this.state.isLoading} showLoadingAnimation={true}>
                                <span><Link href={`${item.view_node}`}><a>{item.title}</a></Link></span>
                              </ReactPlaceholder>
                            </h4>
                            <p>
                              <ReactPlaceholder type='text' rows={3} ready={!this.state.isLoading} showLoadingAnimation={true}>
                                <span>{item.field_insight_description}</span>
                              </ReactPlaceholder>
                            </p>
                            <div className="name-date">
                              <span className="name-date-icon">
                                <picture>
                                  <ReactPlaceholder type='round' ready={!this.state.isLoading} showLoadingAnimation={true}>
                                    <LazyLoadImage effect='blur' src={item.field_authors_profile_image} className="img-responsive" />
                                  </ReactPlaceholder>
                                </picture>
                              </span>
                              <p className="name">
                                <ReactPlaceholder type='text' rows={1} ready={!this.state.isLoading} showLoadingAnimation={true}>
                                  {item.field_auth}
                                </ReactPlaceholder>
                              </p>
                              <p className="date">
                                <ReactPlaceholder type='text' rows={1} ready={!this.state.isLoading} showLoadingAnimation={true}>
                                  {item.field_authors_date}
                                </ReactPlaceholder>
                              </p>
                            </div>
                            <div className="link-sec">
                              <ReactPlaceholder type='text' rows={1} ready={!this.state.isLoading} showLoadingAnimation={true}>
                                <ul>
                                  <li><Link href={`${item.view_node}`}><a style={{ cursor: "pointer" }}><span className="read-article amd-readarticle"></span> {item.field_read_more_text}</a></Link></li>
                                  {(item.field_watch_video_link.length) ?
                                    <li><a href="#" onClick={() => this.handleOpenModal(item.title, item.field_watch_video_link)}><span className="watch-video"></span> {item.field_wa}</a></li>
                                    : null}
                                </ul>
                              </ReactPlaceholder>
                            </div>
                          </div>;
                      })}
                    </div>
                    <div className="col-md-12 col-sm-12 col-xs-12 mobile-hide">
                      <hr />
                    </div>
                    <div className="col-md-12 col-sm-12 col-xs-12 insights-video-content">
                      <div className="row">
                        {category.slice(3, this.state.visible).map((item, index) => {
                            return <div key={index} className="col-md-4 col-sm-4 col-xs-12 insights-vc-list" key={index}>

                              <ReactPlaceholder type='text' color='#95969D' rows={2} ready={!this.state.isLoading} showLoadingAnimation={true}>
                                <h4><Link href={`${item.view_node}`}><a>{parse(item.title)}</a></Link></h4>
                              </ReactPlaceholder>

                              <p>
                                <ReactPlaceholder type='text' rows={3} ready={!this.state.isLoading} showLoadingAnimation={true}>
                                  <span>{item.field_insight_description}</span>
                                </ReactPlaceholder>
                              </p>
                              <div className="link-sec">
                                <ReactPlaceholder type='text' rows={1} ready={!this.state.isLoading} showLoadingAnimation={true}>
                                  <ul>
                                    <li><Link href={`${item.view_node}`}><a style={{ cursor: "pointer" }}><span className="read-article amd-readarticle"></span> {item.field_read_more_text}</a></Link></li>
                                    {(item.field_watch_video_link.length) ?
                                      (<li><a href="#" onClick={() => this.handleOpenModal(item.title, item.field_watch_video_link)} ><span className="watch-video amd-play3"></span> {item.field_wa}</a></li>)
                                      : null}
                                  </ul>
                                </ReactPlaceholder>
                              </div>
                            </div>;
                        })}
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-md-12 col-sm-12 col-xs-12 insights-loadmore">
                  {this.state.visible < category.length &&
                    <button onClick={this.loadMore} type="button" className="load-more insights-btn">
                      <ReactPlaceholder type='rect' ready={!this.state.isLoading} showLoadingAnimation={true}>
                        <span>LOAD MORE</span>
                      </ReactPlaceholder>
                    </button>
                  }
                  {this.state.visible > 6 &&
                    <button onClick={this.showLess} type="button" className="load-more insights-btn insights-btn-sl">
                      <ReactPlaceholder type='rect' ready={!this.state.isLoading} showLoadingAnimation={true}>
                        <span>SHOW LESS</span>
                      </ReactPlaceholder>
                    </button>
                  }
                  <p>
                    <ReactPlaceholder type='text' rows={1} style={{ width: "200px", marginLeft: "42%" }} ready={!this.state.isLoading} showLoadingAnimation={true}>
                      <span>Showing {(this.state.visible <= category.length) ? this.state.visible : category.length} of {category.length} Insights</span>
                    </ReactPlaceholder>
                  </p>
                </div>
                <div className="col-md-12 col-sm-12 col-xs-12 mob-pad-30">
                  <hr />
                </div>
                <InsightsSubscribe />
                <div className="col-md-12 col-sm-12 col-xs-12 mob-pad-30">
                  <hr />
                </div>
                <IndustryIndights />
              </div>
            </div>
          </div>
        </section>
      </>
    )
  }
}
export default InsightsTabContent;