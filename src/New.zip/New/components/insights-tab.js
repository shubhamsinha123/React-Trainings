import React, { useState, useEffect } from 'react';
import axios from 'axios';
import InsightsTabContent from './insights-tab-content';
// import SEO from './insights/seo';
// import PerformanceMarketing from './insights/performance-marketing';
// import Analytics from './insights/analytics';
// import DMT from './insights/digital-marketing-technology';
// import DMS from './insights/digital-marketing-strategy';
// import EGS from './insights/ecommerce-growth-strategy';
// import Visualdesign from './insights/visual-design';
import ReactPlaceholder from 'react-placeholder';
import "react-placeholder/lib/reactPlaceholder.css";

class Tabs1 extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      loading: true,
      items: [

      ]
    }
  }
  componentDidMount() {
    axios.get(`${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/insights-tabs`)
      .then(result => {
        //console.log(result.data);
        this.setState({
          items: result.data,
          loading: false
        })
      })
      .catch(error => {
        this.state({ loading: false })
      })
  }


  render() {
    return (
      <div className="tabs">
        <Tabs>
          {
            this.state.loading ?
              <Tab key={'ai'} label='All Insights'>
                <div className="tab-buttons">

                  <ReactPlaceholder type='rect' style={{ width: 150, height: 25 }} >
                    <span>{this.props.label}</span>
                  </ReactPlaceholder>

                </div>
              </Tab>
              : this.state.items.map((item, i) => {
                return (
                  <Tab key={i} label={item.field_name}>
                    <div>
                      <InsightsTabContent {...item} />
                    </div>
                  </Tab>
                )
              })
          }
          {/* <Tab label={this.state.items[1].field_name}>
            <div>
              <EGS />
            </div>
          </Tab>
          <Tab label={this.state.items[2].field_name}>
            <div>
              <DMS />
            </div>
          </Tab>
          <Tab label={this.state.items[3].field_name}>
            <div>
              <SEO />
            </div>
          </Tab>
          <Tab label={this.state.items[4].field_name}>
            <div>
              <PerformanceMarketing />
            </div>
          </Tab>
          <Tab label={this.state.items[5].field_name}>
            <div>
              <Analytics />
            </div>
          </Tab>
          <Tab label={this.state.items[6].field_name}>
            <Visualdesign />
          </Tab>
          <Tab label={this.state.items[7].field_name}>
            <DMT />
          </Tab>
          <Tab label={this.state.items[0].field_name}>
            <div>
              <AllInsights></AllInsights>
            </div>
          </Tab> */}
        </Tabs>
      </div>

    )
  }
}

class Tabs extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      activeTab: 0,
      isLoading: true,
    }

  }
  componentDidMount() {
    this.setState({
      isLoading: false,
      activeTab: 0,
    })
  }


  changeTab = (tab) => {
    this.setState({ activeTab: tab });
  };

  render() {
    let content;
    let buttons = [];
    return (
      <div>
        {React.Children.map(this.props.children, (child, i) => {
          buttons.push(child.props.label)
          if (i == this.state.activeTab) content = child.props.children
        })}

        <TabButtons activeTab={this.state.activeTab} buttons={buttons} changeTab={this.changeTab} />
        <TabButtonsMobile activeTab={this.state.activeTab} buttons={buttons} changeTab={this.changeTab} />
        <div className="tab-content">{content}</div>

      </div>
    );
  }
}

const TabButtons = ({ buttons, changeTab, activeTab }) => {
  const [ready, setReady] = useState(false)
  useEffect(() => {
    setReady(true)
  });
  return (
    <div className="tab-buttons">
      {buttons.map((button, i) => {
        return <ReactPlaceholder type='rect' ready={ready} style={{ width: 150, height: 25 }} >
          <span className={i == activeTab ? 'active' : ''} onClick={() => changeTab(i)}>{button}</span>
        </ReactPlaceholder>
      })}
    </div>
  )
}
const TabButtonsMobile = ({ buttons, changeTab, activeTab }) => {
  return (
    <div className="tab-buttons-mobile-wrapper">
      <select className="tab-buttons-mobile" onChange={(event) => changeTab(event.target.value)} value={activeTab}>
        {buttons.map((option, i) => {
          return <option className={i == activeTab ? 'active' : ''} value={i} >{option}</option>
        })}
      </select>
    </div>
  )
}

const Tab = props => {

  return (
    <React.Fragment>
      {props.children}
    </React.Fragment>


  )
}


export default Tabs1;