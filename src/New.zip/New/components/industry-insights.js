import React from 'react';
import ReactPlaceholder from 'react-placeholder';
import "react-placeholder/lib/reactPlaceholder.css";
import 'react-lazy-load-image-component/src/effects/blur.css';
import ShowMoreText from 'react-show-more-text';
class IndustryIndights extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            items: [],
            visible: 5,
            error: false,
            isLoading: true
        };
        this.loadMore = this.loadMore.bind(this);
    }
    loadMore() {
        this.setState((prev) => {
            return { visible: prev.visible + 6 };
        });
    }
    componentDidMount() {
        fetch("/api/scrape").then(
            res => res.json()
        ).then(res => {
            console.log(res)
            res.data.sort(() => Math.random() - 0.5);
            console.log(res)
            this.setState({
                items: res.data,
                itemslength: res.data.length,
                isLoading: false,
            });
        }).catch(error => {
            console.error(error);
            this.setState({
                error: true
            });
        });
    }
    executeOnClick(isExpanded) {
        console.log(isExpanded);
    }
    render() {
        return (
            <>
                <div className="col-md-12 col-sm-12 col-xs-12 insights-industry">
                    <div className="row insights-industry-wrapper">
                        <div className="col-md-8 col-sm-8 col-xs-12 insights-industry-left">
                            <h4>
                                <ReactPlaceholder type='text' rows={1} ready={!this.state.isLoading} showLoadingAnimation={true}>
                                    <span>INDUSTRY NEWS</span>
                                </ReactPlaceholder>
                            </h4>
                            <p className="sub-para">
                                <ReactPlaceholder type='text' rows={1} ready={!this.state.isLoading} showLoadingAnimation={true}>
                                    <span>Explore what's trending in digital marketing around the world.</span>
                                </ReactPlaceholder>
                            </p>
                            <div className="row">
                                {this.state.items.slice(0, this.state.visible).map((item, index) => {
                                    if (index == 0) {
                                        return <div className="col-md-12 col-sm-12 col-xs-12 insights-industry-box" key={index}>
                                            <div className="video-content-wrapper">
                                                <br />
                                                <h5>
                                                    <ReactPlaceholder type='text' color='#95969D' rows={2} ready={!this.state.isLoading} showLoadingAnimation={true}>
                                                        <span><a href={item.link} style={{ cursor: "pointer", color: "#4e4e56" }} target="_blank">{item.title}</a></span>
                                                    </ReactPlaceholder>
                                                </h5>
                                                <p>
                                                    <ReactPlaceholder type='text' rows={2} ready={!this.state.isLoading} showLoadingAnimation={true}>
                                                        <ShowMoreText
                                                            /* Default options */
                                                            lines={2}
                                                            more='Show more'
                                                            less='Show less'
                                                            className='content-css'
                                                            anchorClass='my-anchor-css-class'
                                                            onClick={this.executeOnClick}
                                                            expanded={false}
                                                            width={0}
                                                        > {item.description} </ShowMoreText>
                                                    </ReactPlaceholder>
                                                </p>
                                                <ReactPlaceholder type='text' rows={1} ready={!this.state.isLoading} showLoadingAnimation={true}>
                                                    <span className="source-scrap"><b>SOURCE</b>&nbsp;:&nbsp;{item.source}</span>
                                                </ReactPlaceholder>
                                            </div>
                                        </div>
                                    }
                                })}
                                {this.state.items.slice(0, this.state.visible).map((item, index) => {
                                    if (index >= 1) {
                                        return <div className="col-md-12 col-sm-12 col-xs-12 insights-industry-box" key={index}>

                                            <h5>
                                                <ReactPlaceholder type='text' color='#95969D' rows={2} ready={!this.state.isLoading} showLoadingAnimation={true}>
                                                    <span><a href={item.link} style={{ cursor: "pointer", color: "#4e4e56" }} target="_blank">{item.title}</a></span>
                                                </ReactPlaceholder>
                                            </h5>
                                            <p>
                                                <ReactPlaceholder type='text' rows={2} ready={!this.state.isLoading} showLoadingAnimation={true}>
                                                    <ShowMoreText
                                                        /* Default options */
                                                        lines={2}
                                                        more='Show more'
                                                        less='Show less'
                                                        className='content-css'
                                                        anchorClass='my-anchor-css-class'
                                                        onClick={this.executeOnClick}
                                                        expanded={false}
                                                        width={0}
                                                    > {item.description} </ShowMoreText>
                                                </ReactPlaceholder>
                                            </p>
                                            <ReactPlaceholder type='text' rows={1} ready={!this.state.isLoading} showLoadingAnimation={true}>
                                                <span className="source-scrap"><b>SOURCE</b>&nbsp;:&nbsp;{item.source}</span>
                                            </ReactPlaceholder>
                                        </div>;
                                    }
                                })}
                            </div>
                        </div>
                        <div className="col-md-4 col-sm-4 col-xs-12 insights-industry-right">
                            <h4>
                                <ReactPlaceholder type='text' rows={1} ready={!this.state.isLoading} showLoadingAnimation={true}>
                                    <span>More to Explore</span>
                                </ReactPlaceholder>
                            </h4>
                            {this.state.items.reverse().slice(0, this.state.visible).map((item, index) => {
                                return <div className="scrap-right" key={index}>

                                    <h5>
                                        <ReactPlaceholder type='text' color='#95969D' rows={2} ready={!this.state.isLoading} showLoadingAnimation={true}>
                                            <a href={item.link} style={{ cursor: "pointer", color: "#4e4e56" }} target="_blank">{item.title}</a>
                                        </ReactPlaceholder>
                                    </h5>
                                    <p>
                                        <ReactPlaceholder type='text' rows={2} ready={!this.state.isLoading} showLoadingAnimation={true}>
                                            <ShowMoreText
                                                /* Default options */
                                                lines={2}
                                                more='Show more'
                                                less='Show less'
                                                className='content-css'
                                                anchorClass='my-anchor-css-class'
                                                onClick={this.executeOnClick}
                                                expanded={false}
                                                width={0}
                                            > {item.description} </ShowMoreText>
                                        </ReactPlaceholder>
                                    </p>
                                    <ReactPlaceholder type='text' rows={1} ready={!this.state.isLoading} showLoadingAnimation={true}>
                                        <span className="source-scrap"><b>SOURCE</b>&nbsp;:&nbsp;{item.source}</span>
                                    </ReactPlaceholder>
                                </div>
                            })
                            }
                        </div>
                    </div>
                </div>
                <div className="col-md-12 col-sm-12 col-xs-12 mobile-hide">
                    <hr />
                </div>
                <div className="col-md-12 col-sm-12 col-xs-12 insights-loadmore">
                    {this.state.visible < this.state.items.length &&
                        <button onClick={this.loadMore} type="button" className="load-more insights-btn">
                            <ReactPlaceholder type='rect' ready={!this.state.isLoading} showLoadingAnimation={true}>
                                LOAD MORE
                            </ReactPlaceholder>
                        </button>
                    }
                    <p>
                        <ReactPlaceholder type='text' rows={1} style={{ width: "200px", marginLeft: "42%" }} ready={!this.state.isLoading} showLoadingAnimation={true}>
                            Showing {(this.state.visible <= this.state.itemslength) ? this.state.visible : this.state.itemslength} of {this.state.itemslength} Insights
                        </ReactPlaceholder>
                    </p>
                </div>
            </>
        )
    }
}
export default IndustryIndights;