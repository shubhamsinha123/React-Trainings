
const getDataPromise = (url, options) => {
  return new Promise((resolve, reject) => {
    fetch(url)
      .then(res => res.json())
      .then(result => {
        if(options.list) {
          if(options.firstItem && Array.isArray(result) && result.length) {
            resolve(result[0] || {})
          } else {
            resolve(result || [])
          }
        } else {
          resolve(result)
        }
      })
      .catch(e => {
        reject(e)
      })
  })
}
export const getHeaderFooterData = () => {
  const url = `${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/header-footer`;
  return getDataPromise(url, {
    list: true,
    // firstItem: true
  })
}
export const getHomeHeroBanner = () => {
  const url = `${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/homepage/1/section/1`;
  return getDataPromise(url, {
    list: true,
    firstItem: true
  })
}
export const getSeeresults = () => {
  const url  = `${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/homepage/1/section/6`;
  return getDataPromise(url, {
    
  })
}
export const getlaptopservice = () => {
  const url = `${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/homepage/1/section/3`;
  return getDataPromise(url, {
    list: true,
    firstItem: true
  })
}
export const getMonthlyResult = () => {
  const url = `${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/homepage/1/section/5`;
  return getDataPromise(url, {
    list: true,
    firstItem: true
  })
}
export const getHomePageInsights = () => {
  const url = `${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/homepage/1/section/4`;
  return getDataPromise(url, {
    list: true,
    firstItem: true
  })
}

export const getAllInsights = () => {
  const url = `${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/insights-listing/10`;
  return getDataPromise(url, {
    list: true,
    // firstItem: true
  })
}

  export const getHomeAwards = () => {
    const url = `${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/homepage/1/section/8`;
    return getDataPromise(url, {
      list: true,
    firstItem: true
    })
}

export const getHomeBrand = () => {
  const url = `${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/homepage/1/section/2`;
  return getDataPromise(url, {
    list: true,
  firstItem: true
  })
}
export const getOurClients = () => {
  const url = `${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/homepage/1/section/7`;
  return getDataPromise(url, {
    list: true,
  firstItem: true
  })
}
