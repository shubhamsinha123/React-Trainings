import React, { PureComponent } from 'react';
import Tabs1 from '../components/insights-tab';
import MetaDecorator from "../components/Util/MetaDecorator";
import { withRouter } from "next/router";

const insights = require("../data/insights");

class Insights extends PureComponent {
    constructor() {
        super();
        this.state = {
            showPopup: false,
            value: '',
        };
    }

    componentDidMount(){
        setTimeout(() => {
            window.scrollTo(0, 0);
        }, 300)
    }
    
    handleChange = (e) => {
        console.log(e.target.value);
        this.setState({
            value: e.target.value
        })
    }

    handleSubmit = (e) => {
        e.preventDefault();
        console.log(this.state.value);
        this.props.router.push(`/searchinsights?result=${this.state.value}`);
        
    }

    render() {
        return (
            <>

                <MetaDecorator
                    description={insights.metaDescription}
                    title={insights.pageTitle}
                    href={insights.canonicalUrl}
                />
                <section className="insights-banner-wrapper">
                    <div className="container-fluid">
                        <div className="wrapper insights-banner">
                            <div className="row">
                                <div className="col-12">
                                    <h1>Insights</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section className="insights-search-wrapper">
                    <div className="container-fluid">
                        <div className="wrapper insights-search">
                            <div className="row">
                                <div className="col-12">
                                    <div className="search-container">
                                        <form onSubmit={this.handleSubmit} >
                                            <input className="insights-input" type="text" placeholder="Search Insights Library" name="search" value={this.state.value}
                                                onChange={this.handleChange} />
                                            <button type="submit" className="insights-btn">
                                                <span className="search-icon amd-search"></span>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section className="insights-tab-wrapper">
                    <div className="container-fluid">
                        <div className="wrapper">
                            <div className="row">
                                <div className="insights-tab">
                                    <Tabs1 />
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </>
        )
    }
}
export default withRouter(Insights);
