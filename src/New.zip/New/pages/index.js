import React, { useEffect } from 'react'
import dynamic from 'next/dynamic';
import home from '../data/home.json'
// import { QueryClient, dehydrate } from 'react-query'
import MetaDecorator from '../components/Util/MetaDecorator'
import Schema from '../components/Util/Schema';
// import HomeHeroBanner from '../components/home/home-herobanner'
import HomeHeroBanner from '../components/home/home-banner/home-herobanner';
// import HomeBrand from '../components/home/home-brand'
import HomeBrand from '../components/home/home-brand/home-brand';
import LazyLoad from 'react-lazyload'

const HomeSeeResult = dynamic(() => import('../components/common/seeResults/seeresult'), {
  ssr: false
})
const HomeLaptopService = dynamic(() => import('../components/home/home-laptopservice'), {
  ssr: false
})
const HomeAwards = dynamic(() => import('../components/home/home-awards'), {
  ssr: true
})
const HomeGreySlider = dynamic(() => import('../components/home/home-grayslider/home-greyslider'), {
  ssr: true
})
const MonthlyBudget = dynamic(() => import('../components/common/monthlyBudget/monthlybudget'), {
  ssr: true
})
// const OurClients = dynamic(() => import('../components/common/ourClients/ourclients'), {
//   ssr: true
// })

export default function Home(props) {
  useEffect(() => {
    if (window?.innerWidth < 1023) {
      const bodyStyles = document.body.style;
      bodyStyles.setProperty('--test', 0);
        window.onscroll = () => {
            bodyStyles.setProperty('--test', -(window.scrollY) + 'px');
        };
    }
  }, [])
  return (
    <>
      <MetaDecorator
        description={home.metaDescription}
        title={home.pageTitle}
        href={home.canonicalUrl}
      />
      {
        props.schemaHome && props.schemaHome[0].field_schema_types_export.map((data) =>
          <Schema data={JSON.parse(data.body)} />
        )
      }
      <div className='homepage-wrapper'>
        <HomeHeroBanner data={props.bannerData} />

        {/* <LazyLoad height={750} offset={450}> */}
        <HomeBrand data={props.brandData} />
        {/* </LazyLoad> */}

        <LazyLoad height={750} offset={450}>
          <HomeLaptopService data={props.serviceData} />
        </LazyLoad>

        <LazyLoad height={750} offset={450}>
          <HomeGreySlider homeInsightsData={props.insightsData} allInsights={props.allInsightsData} />
        </LazyLoad>

        <LazyLoad height={750} offset={450}>
          <MonthlyBudget data={props.budgetData} />
        </LazyLoad>

        <LazyLoad height={750} offset={700}>
          <HomeSeeResult data={props.resultsData} />
        </LazyLoad>

        {/* <LazyLoad height={750} offset={450}>
          <OurClients data={props.clientsData} />
        </LazyLoad> */}

        <LazyLoad height={750} offset={450}>        
          <HomeAwards data={props.awardsData} />
        </LazyLoad>
      </div>
    </>
  )
}

export async function getStaticProps() {
  try {
    const insightServiceFile = require('../services/insights.service');
    const {
      getAllInsights,
      getMonthlyResult,
      // getOurClients,
      getHeaderFooterData,
      getHomeBrand,
      getHomeAwards,
      getHomeHeroBanner,
      getlaptopservice,
      getHomePageInsights,
    } = insightServiceFile;

    const schemaHomeRes = await fetch(`${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/schema/home`);
    // const insightsRes = await fetch(`${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/homepage/1/section/4`);
    // const monthlyBudget = await fetch(`${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/homepage/1/section/5`);
    const resultRes = await fetch(`${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/homepage/1/section/6`);
    // const clientsRes = await fetch(`${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/homepage/1/section/7`);
    // const awardsRes = await fetch(`${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/homepage/1/section/8`);
    
    // const queryClient = new QueryClient()
    // await queryClient.prefetchQuery('homepage-HeroBanner', getHomeHeroBanner, {
    //   initialData: {}
    // })
    // await queryClient.prefetchQuery('home-brand', getHomeBrand, {
    //   initialData: {},
    // })
    const resultBanner = await getHomeHeroBanner();
    const resultBrand = await getHomeBrand();
    const resultLaptop = await getlaptopservice();
    const resultSchemaHome = await schemaHomeRes.json();
    const resultInsights = await getHomePageInsights(); //insightsRes.json();
    const resultBudget = await getMonthlyResult(); //monthlyBudget.json();
    const resultSeeResult = await resultRes.json();
    // const resultClients = await getOurClients(); // clientsRes.json();
    const resultAwards = await getHomeAwards(); // awardsRes.json();
    const resultAllInsights = await getAllInsights();
    const resutlHeaderFooter = await getHeaderFooterData();

    console.log('---> HOME >>', resultBanner)

    return {
      props: {
        // dehydratedState: dehydrate(queryClient),
        bannerData: resultBanner || {},
        brandData: resultBrand || {},
        serviceData: resultLaptop || {},
        schemaHome: resultSchemaHome || {},
        insightsData: resultInsights || {},
        // clientsData: resultClients || {},
        budgetData: resultBudget || {},
        resultsData: resultSeeResult?.[0] || {},
        awardsData: resultAwards || {},
        allInsightsData: resultAllInsights || [], 
        headerData: resutlHeaderFooter || [],
        footerData: resutlHeaderFooter || [],
      },
      revalidate: 600,
    }
  } catch(e) {
    console.log('----> HOME >>>>', e)
    return {
      props: {},
      // revalidate: 10,
    }
  }
}

