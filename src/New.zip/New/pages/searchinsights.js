import React, { useState } from 'react';
import { useRouter } from 'next/router'
import Searchinsights from "../components/search-insight"

const q = 'result';

const Searchins = () => {
  const router = useRouter()
  const id = router.query[q] || router.asPath.match(new RegExp(`[&?]${q}=(.*)(&|$)`))

  return <Searchinsights id={id} />
}

export default Searchins