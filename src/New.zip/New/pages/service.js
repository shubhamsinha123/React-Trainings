import React from 'react';
import axios from 'axios';
import Omnis from '../components/common/omnis';
import MonthlyBudget from '../components/common/monthlyBudget/monthlybudget';
import { LazyLoadImage } from 'react-lazy-load-image-component'
import MetaDecorator from "../components/Util/MetaDecorator";
import ReactPlaceholder from 'react-placeholder';
import 'react-lazy-load-image-component/src/effects/blur.css';
import "react-placeholder/lib/reactPlaceholder.css";
import Link from 'next/link';
import { withRouter, useRouter } from 'next/router'
import Redirect from '../components/common/redirect';
const service = require("../data/service.json");

class Servicepage extends React.Component {
    constructor(props) {
        super(props);
        const state = {
            // calculate_startegy: [],
            // calculate_startegy_field_image_text: [],
            ecommerce_referrer: false,
            digitalmarketstrategy_referrer: false,
            uxui_referrer: false,
            performancemarket_referrer: false,
            searchengine_referrer: false,
            digitalmarkettechnology_referrer: false,
            analytics_referrer: false,
            digital_services: {},
            digital_services_field_services_list_export: [],
            isLoading: true
            // data: null,
        }
        this.state = state;
        this.handleOpenModal = this.handleOpenModal.bind(this);
        this.handleCloseModal = this.handleCloseModal.bind(this);
    }

    handleOpenModal(title_head, url_video) {
        this.setState({ showModal: true, modelContent: title_head, videoUrl: url_video });
    }

    handleCloseModal() {
        this.setState({ showModal: false });
    }

    componentDidMount() {
        console.log("cdp");
        window.scrollTo(0, 0);
        // console.log(this.props)
        // this.getservicebanner();
        // this.getpromotionalbanner();
        if(this.props.isLoading) {
            fetch(`${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/services/2`)
                .then(res => res.json())
                .then(result => {
                    console.log('__RES__:From Service Page', result)
                    this.setState({
                        digital_services: result[0],
                        digital_services_field_services_list_export: result[0].field_services_list_export,
                        isLoading: false
                    })
                })
                .catch(e => console.log('__ERROR__:From Service Page', e))
        } else {
            this.setState({
                digital_services: this.props.digital_services,
                digital_services_field_services_list_export: this.props.digital_services_field_services_list_export,
                isLoading: false
            })
        }
    }
    // getservicebanner() {
    //     axios.get(`${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/services/2`)
    //         .then(result => {

    //             this.setState({
    //                 data: result,
    //                 digital_services: result.data[0],
    //                 digital_services_field_services_list_export: result.data[0].field_services_list_export,
    //                 //calculate_startegy: result.data[2],
    //                 //calculate_startegy_field_image_text: result.data[2].field_image_text[0],
    //                 isLoading: false,
    //             });
    //         })
    //         .catch(error => {

    //         })
    // }
    // getpromotionalbanner() {
    //     axios.get(`${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/homepage/1`)
    //         .then(result => {
    //             this.setState({
    //             });
    //         })
    //         .catch(error => {
    //         })
    // }
    learnmore_link_redirect(title) {
        console.log(title);
        if (title === "ECOMMERCE GROWTH STRATEGY") {
            this.setState({
                ecommerce_referrer: true
            })
        } else if (title === "DIGITAL MARKETING STRATEGY") {
            this.setState({
                digitalmarketstrategy_referrer: true
            })
        } else if (title === "UX/UI &amp; VISUAL DESIGN") {
            this.setState({
                uxui_referrer: true
            })
        } else if (title === "PERFORMANCE MARKETING") {
            this.setState({
                performancemarket_referrer: true
            })
        } else if (title === "SEARCH ENGINE OPTIMIZATION") {
            this.setState({
                searchengine_referrer: true
            })
        } else if (title === "DIGITAL MARKETING TECHNOLOGY") {
            this.setState({
                digitalmarkettechnology_referrer: true
            })
        } else if (title === "ANALYTICS") {
            this.setState({
                analytics_referrer: true
            })
        }
    }
    render() {

        const { pageClass } = this.props || {};
        const { isLoading, digital_services, digital_services_field_services_list_export } = this.state;

        const ecommerce_referrer = this.state.ecommerce_referrer;
        if (ecommerce_referrer) {
            return <Redirect to="/ecommerce-details" />
        }
        const digitalmarketstrategy_referrer = this.state.digitalmarketstrategy_referrer;
        if (digitalmarketstrategy_referrer) {
            return <Redirect to="/digitalmarketstrategy-details" />
        }
        const uxui_referrer = this.state.uxui_referrer;
        if (uxui_referrer) {
            return <Redirect to="/uxuivisualdesign-details" />
        }
        const performancemarket_referrer = this.state.performancemarket_referrer;
        if (performancemarket_referrer) {
            return <Redirect to="/performancemarket-details" />
        }
        const searchengine_referrer = this.state.searchengine_referrer;
        if (searchengine_referrer) {
            return <Redirect to="/searchengine-details" />
        }
        const digitalmarkettechnology_referrer = this.state.digitalmarkettechnology_referrer;
        if (digitalmarkettechnology_referrer) {
            return <Redirect to="/digitalmarkettechnology-details" />
        }
        const analytics_referrer = this.state.analytics_referrer;
        if (analytics_referrer) {
            return <Redirect to="/analytics-details" />
        }
        return (
            <div className="service-detail">

                <MetaDecorator
                    description={service.metaDescription}
                    title={service.pageTitle}
                    href={service.canonicalUrl}
                />

                <section className="digital-services">
                    <div className="container-fluid">
                        <div className="wrapper">
                            <div className="title-service">

                                <ReactPlaceholder className="placeholder-service-title" type='text' rows={1} color="yellow" ready={!isLoading} showLoadingAnimation={true}>
                                    <h1>{digital_services.field_title}</h1>
                                </ReactPlaceholder>


                                <ReactPlaceholder type='text' className="placeholder-service-data" rows={2} ready={!isLoading} showLoadingAnimation={true}>
                                    <p>

                                        {digital_services.field_description}

                                    </p>
                                </ReactPlaceholder>

                            </div>
                            <div className="row">
                                {digital_services_field_services_list_export.map((digitalcard, index) => (
                                    <div key={index} className={`col-md-6 col-lg-4 col-xl-3 col-sm-6 col-xs-12 card_${index}`}>
                                        <Link href={{ pathname: digitalcard.learn_more_link }}><a><div className="digital-marketing"
                                            onMouseOver={e => e.currentTarget.querySelector('p').innerHTML = digitalcard.category_hover_description}
                                            onMouseOut={e => e.currentTarget.querySelector('p').innerHTML = digitalcard.category_description}
                                        >
                                            <div className="result-across">
                                                <ReactPlaceholder type='round' ready={!isLoading} showLoadingAnimation={true}>
                                                    <picture>
                                                        <source media="(max-width: 767px)" srcSet={digitalcard.category_mobile_image} />
                                                        <LazyLoadImage effect="blur" src={digitalcard.category_desktop_image} alt="digital-icon" />
                                                    </picture>
                                                </ReactPlaceholder>
                                            </div>

                                            <ReactPlaceholder type='text' rows={2} ready={!isLoading} showLoadingAnimation={true}>
                                                <h2>
                                                    <span dangerouslySetInnerHTML={{ __html: digitalcard.category_title }}></span>
                                                </h2>
                                            </ReactPlaceholder>

                                            <ReactPlaceholder type='text' rows={3} ready={!isLoading} showLoadingAnimation={true}>
                                                <p>
                                                    {digitalcard.category_description}
                                                </p>
                                            </ReactPlaceholder>

                                            <ReactPlaceholder type='text' rows={1} ready={!isLoading} showLoadingAnimation={true}>
                                                <div className="learn-more">
                                                    <Link href={{ pathname: digitalcard.learn_more_link }}>
                                                        <a className="learn-more-link" >
                                                            <img src={"images/services/line-pink.svg"} alt="" loading="lazy" />
                                                            {digitalcard.learn_more_text}
                                                        </a>
                                                    </Link>
                                                </div>
                                            </ReactPlaceholder>

                                        </div>
                                        </a>
                                        </Link>
                                    </div>
                                ))
                                }
                            </div>
                        </div>
                    </div>
                </section>
                <Omnis />
                <MonthlyBudget />
            </div>
        )
    }
}
export default withRouter(Servicepage)

export async function getStaticProps(context) {
    try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/services/2`);
        const result = await res.json();
        console.log("props check", result)
        return {
            props: {
                // data: result,
                digital_services: result[0],
                digital_services_field_services_list_export: result[0].field_services_list_export,
                //calculate_startegy: result.data[2],
                //calculate_startegy_field_image_text: result.data[2].field_image_text[0],
                isLoading: false
            },
            revalidate: 10,
        }
    }
    catch (e) {
        console.log('__ERROR__:Service Page:', e);
        // const res = await fetch(`${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/services/2`);
        return {
            props: {
                // errorObj: e,
                // resObj: JSON.stringify(res),
                digital_services: {},
                digital_services_field_services_list_export: [],
                isLoading: true
            },
            revalidate: 10,
        }
    }
}
