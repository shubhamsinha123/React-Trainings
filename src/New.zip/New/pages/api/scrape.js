const axios = require("axios");
const cheerio = require("cheerio");
const one = "https://moz.com/blog"
const two = "https://blog.hootsuite.com/";
const three = "https://yoast.com/seo-blog/";
const four = "https://www.searchenginejournal.com/";
const five = "https://www.crazyegg.com/blog/"
const six = "https://searchengineland.com/"
const seven = "https://martech.org/"
const eight = "https://www.semrush.com/blog/"
const nine = "https://about.ads.microsoft.com/en-us/blog"
const ten = "https://ppcprotect.com/blog/"
const eleven = "https://www.justinmind.com/blog/"
const twelve = "https://blog.optimizely.com/"
const thirteen = "https://buffer.com/library/"
const fourteen = "https://www.affiliatesummit.com/blog"
const requestOne = axios.get(one);
const requestTwo = axios.get(two);
const requestThree = axios.get(three);
const requestFour = axios.get(four);
const requestFive = axios.get(five);
const requestSix = axios.get(six);
const requestSeven = axios.get(seven);
const requestEight = axios.get(eight);
const requestNine = axios.get(nine);
const requestTen = axios.get(ten);
const requestEleven = axios.get(eleven);
const requestTwelve = axios.get(twelve);
const requestThirteen = axios.get(thirteen);
const requestFourteen = axios.get(fourteen);
export default (req, res) => {
    axios
        .all([requestOne, requestTwo, requestThree, requestFour, requestFive, requestSix, requestSeven, requestEight, requestNine, requestTen, requestEleven, requestTwelve, requestThirteen, requestFourteen])
        .then(
            axios.spread((...responses) => {
                const responseOne = responses[0];
                const responseTwo = responses[1];
                const responesThree = responses[2];
                const requestFour = responses[3];
                const requestFive = responses[4];
                const requestSix = responses[5];
                const requestSeven = responses[6];
                const requestEight = responses[7];
                const requestNine = responses[8];
                const requestTen = responses[9];
                const requestEleven = responses[10];
                const requestTwelve = responses[11];
                const requestThirteen = responses[12];
                const requestFourteen = responses[13];
                const dataOne = scrapeOne(responseOne)
                const dataTwo = scrapeTwo(responseTwo)
                const dataThree = scrapeThree(responesThree)
                const dataFour = scrapeFour(requestFour)
                const dataFive = scrapeFive(requestFive)
                const dataSix = scrapeSix(requestSix)
                const dataSeven = scrapeSeven(requestSeven)
                const dataEight = scrapeEight(requestEight)
                const dataNine = scrapeNine(requestNine)
                const dataTen = scrapeTen(requestTen)
                const dataEleven = scrapeEleven(requestEleven)
                const dataTwelve = scrapeTwelve(requestTwelve)
                const dataThirteen = scrapeThirteen(requestThirteen)
                const dataFourteen = scrapeFourteen(requestFourteen)
                const data = [...dataOne, ...dataTwo, ...dataThree, ...dataFour, ...dataFive, ...dataSix, ...dataSeven, ...dataEight, ...dataNine, ...dataTen, ...dataEleven, ...dataTwelve, ...dataThirteen, ...dataFourteen]
                res.status(200).json({data})
            })
        )
        .catch(errors => {
            console.error(errors);
        });
}
//https://moz.com/blog
function scrapeOne(response) {
    let $ = cheerio.load(response.data);
    let website = $("title").html();
    let data = []
    $("article.col-md-6").each(function (i, e) {
        data.push({
            title: $(e).find("h2").text(),
            description: $(e).find("p").text(),
            link: $(e).find("a").attr("href"),
            image: $(e).find("img").attr("src"),
            source: website
        });
    });
    return data
}
//https://blog.hootsuite.com/
function scrapeTwo(response) {
    let data = []
    let $ = cheerio.load(response.data);
    let website = $("title").html().replace(/&amp;/g, "&");
    $("article").each(function (i, e) {
        data.push({
            title: $(e).find(".post-title").text(),
            description: $(e).find("p").text(),
            link: $(e).find("a").attr("href"),
            image: $(e).find("img").attr("src"),
            source: website
        });
    });
    return data
}
//https://yoast.com/seo-blog/
function scrapeThree(response) {
    let data = []
    let $ = cheerio.load(response.data);
    let website = $("title").html();
    $("div.card").each(function (i, e) {
        data.push({
            title: $(e).find(".card__title").text(),
            description: $(e).find("p").text(),
            link: $(e).find("a").attr("href"),
            image: $(e).find("img").attr("src"),
            source: website
        });
    });
    return data
}
//https://www.searchenginejournal.com/
function scrapeFour(response) {
    let data = []
    let $ = cheerio.load(response.data);
    let website = $("title").html();
    $("#posts-tab-1  article.sej-post").each(function (i, e) {
        data.push({
            title: $(e).find("h2.sej-ptitle").text().trim(),
            description: $(e).find("p").text(),
            link: $(e).find("h2.sej-ptitle a").attr("href"),
            image: $(e).find("img:first").attr('data-src2'),
            source: website
        });
    });
    return data
}
//https://www.crazyegg.com/blog/
function scrapeFive(response) {
    let data = []
    let $ = cheerio.load(response.data);
    let website = $("title").html();
    $("div.post.entry.latest").each(function (i, e) {
        data.push({
            title: $(e).find("h2.entry-title").text(),
            description: $(e).find("p:first").text().trim(),
            link: $(e).find("a.entry-title-link").attr("href"),
            image: $(e).find("img").attr('src'),
            source: website
        });
    });
    return data
}
//https://searchengineland.com/
function scrapeSix(response) {
    let data = []
    let $ = cheerio.load(response.data);
    let website = $("title").html().replace(/&amp;/g, "&");;
    $("article.stream-article.latest.hidden-md").each(function (i, e) {
        data.push({
            title: $(e).find("h2.headline").text().replace(/\t?\n|\t/g, ''),
            description: $(e).find("p:first").text().trim().replace(/\t?\n|\t/g, ''),
            link: $(e).find("h2.headline a").attr("href"),
            image: $(e).find("img").attr('src'),
            source: website
        });

    });
    data = data.filter(function(x) { return  x.image !== "" });
    return data
}
//https://martech.org/
function scrapeSeven(response) {
    let data = []
    let $ = cheerio.load(response.data);
    let website = $("title").html().replace(/&amp;/g, "&");
    $("article.stream-article.latest").each(function (i, e) {
        data.push({
            title: $(e).find("h2.headline").text().replace(/\t?\n|\t/g, ''),
            description: $(e).find("p.dek").text().trim().replace(/\t?\n|\t/g, ''),
            link: $(e).find("h2.headline a").attr("href"),
            image: $(e).find("img").attr('src'),
            source: website
        });
    });
    data = data.filter(function(x) { return  x.description !== "" });
    return data
}
//https://www.semrush.com/blog/
function scrapeEight(response) {
    let data = []
    let $ = cheerio.load(response.data);
    let hostname = response.config.url.replace('/blog/','')
    let website = $("title").html().replace(/&amp;/g, "&");
    $("[data-test*='post-card-small']").each(function (i, e) {
        data.push({
            title: $(e).find("[data-test*='title']").text(),
            description: $(e).find("[data-test*='description']").text(),
            link: hostname + $(e).find("[data-test*='title']").attr("href"),
            image: $(e).find("img").attr('src'),
            source: website
        });
    });
    return data
}
//"https://about.ads.microsoft.com/en-us/blog
function scrapeNine(response) {
    let data = []
    let $ = cheerio.load(response.data);
    let website = $("title").html().replace(/\t?\n|\t/g, "");
    $("article.blog-post-item").each(function (i, e) {
        data.push({
            title: $(e).find("h2.blog-post-title").text(),
            description: $(e).find("p:first").text(),
            link: $(e).find("a.btn-outline-gray").attr("href"),
            image: $(e).find("img").attr('src'),
            source: website
        });
    });
    return data
}
//https://ppcprotect.com/blog/
function scrapeTen(response) {
    let data = []
    let $ = cheerio.load(response.data);
    let hostname = response.config.url.replace('/blog/','')
    let website = $("title").html().replace(/&amp;/g, "&");
    $("div.postbox").each(function (i, e) {
        data.push({
            title: $(e).find("p.postbox__title").text(),
            description: $(e).find("p.postbox__title").next().text(),
            link: hostname + $(e).find("a").attr("href"),
            image: hostname + $(e).find("img:eq(1)").attr('data-src'),
            source: website
        });
    });
    return data
}
//https://www.justinmind.com/blog/
function scrapeEleven(response) {
    let data = []
    let $ = cheerio.load(response.data);
    //let hostname = response.config.url.replace('/blog/','')
    let website = $("title").html().replace(/&amp;/g, "&");
    $("div.mixin-pillar-guide-other--banner").each(function (i, e) {
        data.push({
            title: $(e).find("h2").text(),
            description: $(e).find("div.excerpt").text(),
            link: $(e).find("a").attr("href"),
            image: $(e).find("img").attr('data-src'),
            source: website
        });
    });
    return data
}
//https://blog.optimizely.com/
function scrapeTwelve(response) {
    let data = []
    let $ = cheerio.load(response.data);
    let website = $("title").html().replace(/&amp;/g, "&");
    $("article.post.type-post.status-publish").each(function (i, e) {
        data.push({
            title: $(e).find("h2.post-title").text(),
            description: $(e).find("p").text(),
            link: $(e).find("a").attr("href"),
            image: $(e).find("img").attr('src'),
            source: website
        });
    });
    return data
}
//https://buffer.com/library/
function scrapeThirteen(response) {
    let data = []
    let $ = cheerio.load(response.data);
    let hostname = response.config.url.replace('/library/','')
    let website = $("title").html().replace(/&amp;/g, "&");
    $("article.gh-card.post").each(function (i, e) {
        data.push({
            title: $(e).find("h3.gh-card-title").text(),
            description: $(e).find("p").text(),
            link: hostname + $(e).find("a").attr("href"),
            image: hostname + $(e).find("img").attr('src'),
            source: website
        });
    });
    return data
}
//https://www.affiliatesummit.com/blog
function scrapeFourteen(response) {
    let data = []
    let $ = cheerio.load(response.data);
    let hostname = response.config.url.replace('blog','')
    let website = $("title").html().replace(/&amp;/g, "&");
    $("li.m-libraries-blogs-list__items__item").each(function (i, e) {
        data.push({
            title: $(e).find("h2").text().replace(/\t?\n|\t/g, ''),
            description: $(e).find("div.m-libraries-blogs-list__items__item__body").text().replace(/\t?\n|\t/g, ''),
            link: hostname + $(e).find("a").attr("href"),
            image: $(e).find("img").attr('src'),
            source: website.replace(/\t?\n|\t/g, '')
        });
    });
    return data
}