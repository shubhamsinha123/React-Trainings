const jsforce = require("jsforce");
var conn = new jsforce.Connection();

const USERNAME = process.env.SF_USERNAME || "rajkumar.velayudham@ameexusa.com.ameexpoc";
const PASSWORD = process.env.SF_PASSWORD || "Ameexusa#123";

export default (request, response) => {
    conn.login(USERNAME, PASSWORD, function (err, userInfo) {
        if (err) {
          response.status(400).json({ err: err.message });
          return console.error(err);
        }
        //console.log(conn.accessToken);
        //console.log(conn.instanceUrl);
        console.log("User ID: " + userInfo.id);
        console.log("Org ID: " + userInfo.organizationId);
        response.status(200).json({ status: "online",  status_msg: "connected to salesforce app", connected: true, userInfo: userInfo });
    });
}
  