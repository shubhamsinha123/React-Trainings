const jsforce = require("jsforce");
var conn = new jsforce.Connection();

const USERNAME = process.env.SF_USERNAME || "rajkumar.velayudham@ameexusa.com.ameexpoc";
const PASSWORD = process.env.SF_PASSWORD || "Ameexusa#123";

export default (request, response) => {
  if (request.method === "POST") {
    // Process a POST request
    const data = request.body;
    console.log("Got body:", data);
    conn.login(USERNAME, PASSWORD, function (err, userInfo) {
      if (err) {
        response.status(400).json({ err: err.message });
        return console.error(err);
      }
      conn.sobject("Account").create(data, function (err, ret) {
        if (err || !ret.success) {
          response.status(404).json({ err: err.message, res: ret });
          return console.error(err, ret);
        }
        console.log("Created record id : " + ret.id);
        response.json(ret);
      });
    });
  } else {
    // Handle any other HTTP method
    conn.login(USERNAME, PASSWORD, function (err, res) {
      if (err) {
        response.status(400).json({ err: err.message });
        return console.error(err);
      }
      conn.sobject("Account").describe(function (err, meta) {
        if (err) {
          response.status(404).json({ err: err.message });
          return console.error(err);
        }
        //console.log("Label : " + meta.label);
        //console.log("Num of Fields : " + meta.fields.length);
        const arr = meta.fields;
        response.json(arr);
      });
    });
  }
};