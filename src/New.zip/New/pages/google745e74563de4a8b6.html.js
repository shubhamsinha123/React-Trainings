// google-site-verification: google745e74563de4a8b6.html
const Google = () => {};
export const getServerSideProps = async ({ res }) => {
    res.setHeader("Content-Type", "text/html");
    res.write('google-site-verification: google745e74563de4a8b6.html');
    res.end();
    return {
        props: {},
    };
};
export default Google