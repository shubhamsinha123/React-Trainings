import React from 'react';
import { useRouter } from 'next/router'
import Blog from "../../components/blog"
import { getAllInsights } from '../../services/insights.service';

const Post = (props) => {
  const router = useRouter()
  const { title } = router.query

  return <Blog id={title} {...props} />
  
}

export async function getServerSideProps(context) {
  try {
    const { params } = context;
    console.log('> Blog Details Page: PARAMS >', params);
    const result = await getAllInsights();
    const found = result.find((post) => post?.view_node === `/blog-detail/${params?.title}`);
    // console.log(result)
    console.log(found?.nid)
    let removenode = result.filter(function (e) { return e.nid != found.nid; });
    const detailsPromise = await fetch(`${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/insights-listing-node/${found?.nid}`)
    const detailsObj = await detailsPromise.json();
    console.log('> Blog Details Page: Details >', detailsObj)
    return {
      props: {
        blogid: found.nid,
        items: removenode,
        isLoading: false,
        blogs: detailsObj,
      }, // will be passed to the page component as props
    }
  } catch(e) {
    console.log('> Blog Detail Page Error >>', e)
    return {
      props: {},
      notFound: true,
      // redirect:
      // {

      // }
    }
  }
}

export default Post