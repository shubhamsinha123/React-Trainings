import React from 'react';
import axios from 'axios';
import Link from 'next/link';
import Slider from "react-slick";
// import OurClients from '../components/common/ourClients/ourclients';
import MonthlyBudget from '../components/common/monthlyBudget/monthlybudget';
import Omnis from '../components/common/omnis';
import PhoneInput, { isValidPhoneNumber } from 'react-phone-number-input';
import { PopupButton } from 'react-calendly';
import ReactPlaceholder from 'react-placeholder';
import "react-placeholder/lib/reactPlaceholder.css";
import VideoModal from '../components/common/VideoModal/VideoModal';
import MetaDecorator from '../components/Util/MetaDecorator';
import NumberFormat from 'react-number-format';
import Select from 'react-select';
import { getAllInsights } from '../services/insights.service';

const contact = require("../data/contactus");

const optionsct = [
    { value: '-- : --', label: '-- : --' },
    { value: '09 : 00 AM', label: '09 : 00 AM' },
    { value: '09 : 30 AM', label: '09 : 30 AM' },
    { value: '10 : 00 AM', label: '10 : 00 AM' },
    { value: '10 : 30 AM', label: '10 : 30 AM' },
    { value: '11 : 00 AM', label: '11 : 00 AM' },
    { value: '11 : 30 AM', label: '11 : 30 AM' },
    { value: '12 : 00 PM', label: '12 : 00 PM' },
    { value: '12 : 30 PM', label: '12 : 30 PM' },
    { value: '01 : 00 PM', label: '01 : 00 PM' },
    { value: '01 : 30 PM', label: '01 : 30 PM' },
    { value: '02 : 00 PM', label: '02 : 00 PM' },
    { value: '02 : 30 PM', label: '02 : 30 PM' },
    { value: '03 : 00 PM', label: '03 : 00 PM' },
    { value: '03 : 30 PM', label: '03 : 30 PM' },
    { value: '04 : 00 PM', label: '04 : 00 PM' },
    { value: '04 : 30 PM', label: '04 : 30 PM' },
];
const optionset = [
    { value: '10 : 00 AM', label: '10 : 00 AM' },
    { value: '10 : 30 AM', label: '10 : 30 AM' },
    { value: '11 : 00 AM', label: '11 : 00 AM' },
    { value: '11 : 30 AM', label: '11 : 30 AM' },
    { value: '12 : 00 PM', label: '12 : 00 PM' },
    { value: '12 : 30 PM', label: '12 : 30 PM' },
    { value: '01 : 00 PM', label: '01 : 00 PM' },
    { value: '01 : 30 PM', label: '01 : 30 PM' },
    { value: '02 : 00 PM', label: '02 : 00 PM' },
    { value: '02 : 30 PM', label: '02 : 30 PM' },
    { value: '03 : 00 PM', label: '03 : 00 PM' },
    { value: '03 : 30 PM', label: '03 : 30 PM' },
    { value: '04 : 00 PM', label: '04 : 00 PM' },
    { value: '04 : 30 PM', label: '04 : 30 PM' },
    { value: '05 : 00 PM', label: '05 : 00 PM' },
    { value: '05 : 30 PM', label: '05 : 30 PM' },
];
const optionspt = [
    { value: '07 : 00 AM', label: '07 : 00 AM' },
    { value: '07 : 30 AM', label: '07 : 30 AM' },
    { value: '08 : 00 AM', label: '08 : 00 AM' },
    { value: '08 : 30 AM', label: '08 : 30 AM' },
    { value: '09 : 00 AM', label: '09 : 00 AM' },
    { value: '09 : 30 AM', label: '09 : 30 AM' },
    { value: '10 : 00 AM', label: '10 : 00 AM' },
    { value: '10 : 30 AM', label: '10 : 30 AM' },
    { value: '11 : 00 AM', label: '11 : 00 AM' },
    { value: '11 : 30 AM', label: '11 : 30 AM' },
    { value: '12 : 00 PM', label: '12 : 00 PM' },
    { value: '12 : 30 PM', label: '12 : 30 PM' },
    { value: '01 : 00 PM', label: '01 : 00 PM' },
    { value: '01 : 30 PM', label: '01 : 30 PM' },
    { value: '02 : 00 PM', label: '02 : 00 PM' },
    { value: '02 : 30 PM', label: '02 : 30 PM' },
];
const optionsmt = [
    { value: '08 : 00 AM', label: '08 : 00 AM' },
    { value: '08 : 30 AM', label: '08 : 30 AM' },
    { value: '09 : 00 AM', label: '09 : 00 AM' },
    { value: '09 : 30 AM', label: '09 : 30 AM' },
    { value: '10 : 00 AM', label: '10 : 00 AM' },
    { value: '10 : 30 AM', label: '10 : 30 AM' },
    { value: '11 : 00 AM', label: '11 : 00 AM' },
    { value: '11 : 30 AM', label: '11 : 30 AM' },
    { value: '12 : 00 PM', label: '12 : 00 PM' },
    { value: '12 : 30 PM', label: '12 : 30 PM' },
    { value: '01 : 00 PM', label: '01 : 00 PM' },
    { value: '01 : 30 PM', label: '01 : 30 PM' },
    { value: '02 : 00 PM', label: '02 : 00 PM' },
    { value: '02 : 30 PM', label: '02 : 30 PM' },
    { value: '03 : 00 PM', label: '03 : 00 PM' },
    { value: '03 : 30 PM', label: '03 : 30 PM' },
];
const optionsgmt = [
    { value: '03 : 00 PM', label: '03 : 00 PM' },
    { value: '03 : 30 PM', label: '03 : 30 PM' },
    { value: '04 : 00 PM', label: '04 : 00 PM' },
    { value: '04 : 30 PM', label: '04 : 30 PM' },
    { value: '05 : 00 PM', label: '05 : 00 PM' },
    { value: '05 : 30 PM', label: '05 : 30 PM' },
    { value: '06 : 00 PM', label: '06 : 00 PM' },
    { value: '06 : 30 PM', label: '06 : 30 PM' },
    { value: '07 : 00 PM', label: '07 : 00 PM' },
    { value: '07 : 30 PM', label: '07 : 30 PM' },
    { value: '08 : 00 PM', label: '08 : 00 PM' },
    { value: '08 : 30 PM', label: '08 : 30 PM' },
    { value: '09 : 00 PM', label: '09 : 00 PM' },
    { value: '09 : 30 PM', label: '09 : 30 PM' },
];
const optionstime = [
    { value: 'CT', label: 'CT' },
    { value: 'ET', label: 'ET' },
    { value: 'PT', label: 'PT' },
    { value: 'MT', label: 'MT' },
    { value: 'GMT', label: 'GMT' },
];
const CHECKBOX_VALUES = {
    "E-commerce Growth Strategy": "ECOMMERCE GROWTH STRATEGY",
    "Digital Marketing Strategy": "DIGITAL MARKETING STRATEGY",
    "Search Engine Optimization": "SEARCH ENGINE OPTIMIZATION",
    "Performance Marketing": "PERFORMANCE MARKETING",
    "Analytics": "ANALYTICS",
    "UX & Visual Design": "UX & VISUAL DESIGN",
    "Digital Marketing Technology": "DIGITAL MARKETING TECHNOLOGY"
}
var ApiUrl = `${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}`
var newApiUrl = ApiUrl.replace("api", "");
class ContactUs extends React.Component {
    constructor(props) {
        super(props);
        this.firstnext = this.firstnext.bind(this);
        this.secondnext = this.secondnext.bind(this);
        this.skip = this.skip.bind(this);
        this.secondprevious = this.secondprevious.bind(this);
        this.thirdprevious = this.thirdprevious.bind(this);
        this.onSubmit = this.onSubmit.bind(this);
        this.onChangeUserName = this.onChangeUserName.bind(this);
        this.onChangeUserEmail = this.onChangeUserEmail.bind(this);
        this.onChangeUserMessage = this.onChangeUserMessage.bind(this);
        this.onChangeUserCheckbox = this.onChangeUserCheckbox.bind(this);
        this.onChangeUserBrand_url = this.onChangeUserBrand_url.bind(this);
        this.onChangeUserAccomplish = this.onChangeUserAccomplish.bind(this);
        this.onChangeUserCategories = this.onChangeUserCategories.bind(this);
        this.onChangeUserBudget = this.onChangeUserBudget.bind(this);
        this.onChangeUserTimeline = this.onChangeUserTimeline.bind(this);
        this.onChangeUserContacting_through = this.onChangeUserContacting_through.bind(this);
        this.onChangeUserPhone_number = this.onChangeUserPhone_number.bind(this);
        this.onChangeUserTime = this.onChangeUserTime.bind(this);
        this.onChangeUserTime_zone = this.onChangeUserTime_zone.bind(this);

        this.state = {
            data: null,
            // getcontactus: [],
            webform_id: "contact",
            name: "",
            email: "",
            message: "",
            brand_url: "",
            accomplish: "",
            categories: [],
            budget: "",
            timeline: "",
            contacting_through: [],
            phone_number: "",
            time: "",
            time_zone: "",
            token: "",
            phone_contact: false,
            redirectToReferrer: false,
            errors: [
                { name: "" },
                { email: "" },
                { message: "" },
                { checkbox: "" },
                { chkbox: "" },
            ],
            checkbox: "",
            showModal: false,
            modelContent: "",
            videoUrl: "",
            // isLoading: true,
            insightsbanner_leftsider: [],
            inshights: [],
            selectedOption: null,
            selectedtz: null,
            options: [],
            timedefault: "--:--",
            termscheck: false,
            filterinsight: [],
            activeSlide: 0,
        }
        this.handleOpenModal = this.handleOpenModal.bind(this);
        this.handleCloseModal = this.handleCloseModal.bind(this);
    }
    componentDidMount() {
        setTimeout(() => {
            window.scrollTo(0, 0);
        }, 300)
        this.getcontactus();
        this.gettotken();
        this.setState({ options: optionsct, timedefault: optionsct[0], })
        // this.postdetails();
    }
    getcontactus() {
        getAllInsights()
            .then(result => {
                var insightarr = result
                var filteryt = insightarr?.filter(function (obj) { return obj.field_watch_video_link.includes("youtube"); });

                //  const inshights=insightarr.splice(insightarr.length - 5)
                console.log(insightarr)
                this.setState({
                    inshightsdata: filteryt,
                    filterinsight: filteryt,
                    insightsbanner_leftsider: filteryt,
                    inshights: filteryt[0],
                });
            })
            .catch(error => {

            })
    }
    gettotken() {
        axios.get(`${newApiUrl}session/token`)
            .then(result => {
                console.log(result);
                this.setState({
                    token: result.data
                });
            })
            .catch(error => {
            })

    }
    onSubmit(e) {
        e.preventDefault();
        console.log("submit start");
        const userObject = {
            webform_id: "contact",
            name: this.state.name,
            email: this.state.email,
            message: this.state.message,
            brand_url: this.state.brand_url,
            accomplish: this.state.accomplish,
            categories: this.state.categories,
            budget: this.state.budget,
            timeline: this.state.timeline,
            contacting_through: this.state.contacting_through,
            phone_number: this.state.phone_number,
            time: this.state.time,
            time_zone: this.state.time_zone,
            checkbox: this.state.checkbox,
        };
        const userSFObject = {
            Name: this.state.name,
            Email__c: this.state.email,
            Description: this.state.message,
            Website: this.state.brand_url,
            Accomplish__c: this.state.accomplish,
            category__c: this.state.categories.join(';'),
            Budget__c: this.state.budget,
            Timeline__c: this.state.timeline,
            Contacting_Through__c: this.state.contacting_through.join(';'),
            Phone_Number__c: this.state.phone_number,
            Time__c: this.state.time,
            Time_Zone__c: this.state.time_zone,
        };
        if (this.validate()) {
            if (this.state.token !== "") {
                console.log("token success");
                console.log(userSFObject);
                axios.post(`${newApiUrl}webform_rest/submit`, userObject)
                    .then((result) => {
                        console.log(result);
                        this.sendDataToSalesforce(userSFObject);
                        this.setState({
                            redirectToReferrer: true
                        });
                    }).catch((error) => {
                    });

                this.setState({
                    name: "",
                    email: "",
                    message: "",
                    brand_url: "",
                    accomplish: "",
                    categories: [],
                    budget: "",
                    timeline: "",
                    contacting_through: [],
                    phone_number: null,
                    time: "",
                    time_zone: "",
                    checkbox: "",

                })
                // return false;
                this.slider.slickGoTo(2);

            }
        }
    }
    sendDataToSalesforce(userSFObject) {
        console.log('sending data to salesforce...')
        axios.post('/api/sfameex/post', userSFObject)
            .then((result) => {
                if (result.data.success) {
                    console.log('data sent sucessfully to SF')
                }
                console.log(result);
            }).catch((error) => {
                console.log(error);
            });
    }
    validatefirst() {
        let errors = {};
        let isValid = true;
        var patternename = new RegExp(/^[A-Za-z\s]{1,}[\.]{0,1}[A-Za-z\s]{0,}$/);
        if (!this.state.name) {
            isValid = false;
            errors["name"] = "What’s your name?";

        } else if (this.state.name.length < 3) {
            isValid = false;
            errors["name"] = "Minimum 3 characters required.";
        } else if (this.state.name.length > 21) {
            isValid = false;
            errors["name"] = "Maximum 20 characters allowed.";
        }
        else if (!patternename.test(this.state.name)) {
            isValid = false;
            errors["name"] = "What’s your name?";
        }
        if (!this.state.email) {
            isValid = false;
            errors["email"] = "Please enter a valid email address.";
        }
        if (typeof this.state.email !== "undefined") {
            var patternemail = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
            if (!patternemail.test(this.state.email)) {
                isValid = false;
                errors["email"] = "Please enter a valid email address.";
            }
        }
        console.log(this.state.termscheck)
        console.log(this.state.checkbox)
        if (!this.state.checkbox || this.state.termscheck == false) {
            isValid = false;
            errors["checkbox"] = "Please agree to the terms above.";
        }
        if (!this.state.message) {
            isValid = false;
            errors["message"] = "How can we help you?";
        }
        else if (this.state.message.length < 3) {
            isValid = false;
            errors["message"] = "Minimum 3 characters required.";
        } else if (this.state.message.length > 301) {
            isValid = false;
            errors["message"] = "Maximum 300 characters allowed.";
        }
        this.setState({
            errors: errors
        });
        return isValid;
    }
    validatesecond() {
        let errors = {};
        let isValid = true;

        if (!this.state.brand_url) {
            if (this.state.brand_url === undefined) {
                this.setState({ brand_url: "" })
            }
        } else if (this.state.brand_url.length < 3) {
            isValid = false;
            errors["brand_url"] = "Minimum 3 characters required.";
        } else if (this.state.brand_url.length > 41) {
            isValid = false;
            errors["brand_url"] = "Maximum 40 characters allowed.";
        }
        var urlregex = new RegExp('^(https?:\\/\\/)?' + // protocol
            '((([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}|' + // domain name
            '((\\d{1,3}\\.){3}\\d{1,3}))' + // OR ip (v4) address
            '(\\:\\d+)?(\\/[-a-z\\d%_.~+]*)*' + // port and path
            '(\\?[;&a-z\\d%_.~+=-]*)?' + // query string
            '(\\#[-a-z\\d_]*)?$', 'i'); // fragment locator
        // var urlregex = new RegExp(/^((ftp|http|https):\/\/)?(www.)?(?!.*(ftp|http|https|www.))[a-zA-Z0-9_-]+(\.[a-zA-Z]+)+((\/)[\w#]+)*(\/\w+\?[a-zA-Z0-9_]+=\w+(&[a-zA-Z0-9_]+=\w+)*)?$/);
        if (!urlregex.test(this.state.brand_url)) {
            isValid = false;
            errors["brand_url"] = "Please enter a valid url.";
        }
        if (this.state.brand_url == "") {
            isValid = true;
            errors["brand_url"] = "";
        }
        if (!this.state.accomplish) {
            if (this.state.accomplish === undefined) {
                this.setState({ accomplish: "" })
            }
        } else if (this.state.accomplish.length < 3) {
            isValid = false;
            errors["accomplish"] = "Minimum 3 characters required.";
        } else if (this.state.accomplish.length > 301) {
            isValid = false;
            errors["accomplish"] = "Maximum 300 characters allowed.";
        }

        this.setState({
            errors: errors
        });
        return isValid;
    }
    validate() {
        let errors = {};
        let isValid = true;


        if (!this.state.budget) {
            if (this.state.budget === undefined) {
                this.setState({ budget: "" })
            }
        } else if (this.state.budget.length < 3) {
            isValid = false;
            errors["budget"] = "Minimum 3 characters required.";
        } else if (this.state.budget.length > 21) {
            isValid = false;
            errors["budget"] = "Maximum 20 characters allowed.";
        }

        if (!this.state.timeline) {
            if (this.state.timeline === undefined) {
                this.setState({ timeline: "" })
            }
        } else if (this.state.timeline.length < 3) {
            isValid = false;
            errors["timeline"] = "Minimum 3 characters required.";
        } else if (this.state.timeline.length > 21) {
            isValid = false;
            errors["timeline"] = "Maximum 20 characters allowed.";
        }
        if (!this.state.contacting_through.length) {
            isValid = false;
            errors["chkbox"] = "How should we contact you?";
        }
        if (!this.state.phone_number) {
            if (this.state.phone_number === undefined) {
                this.setState({ phone_number: "" })
            }
        } else if (!isValidPhoneNumber(this.state.phone_number)) {
            isValid = false;
            errors["phone_number"] = "Please provide a valid phone number."
        }
        if (this.state.contacting_through.includes('Phone')) {
            if (!this.state.phone_number.length > 0) {
                isValid = false;
                errors["phone_number"] = "Please enter your phone number";
            }
        }

        this.setState({
            errors: errors
        });
        return isValid;
    }
    firstnext() {
        if (this.validatefirst()) {
            this.slider.slickNext();
        }
    }
    secondnext() {
        if (this.validatesecond()) {
            this.slider.slickNext();
        }

    }
    skip() {
        this.setState({
            brand_url: "",
            accomplish: "",
            categories: [],
        });
        this.slider.slickNext();
    }
    secondprevious() {
        this.slider.slickPrev();
    }
    thirdprevious() {
        this.slider.slickPrev();
    }
    onChangeUserName(e) {
        this.setState({ name: e.target.value.replace(/\s/g, " ") })
    }
    onChangeUserEmail(e) {
        this.setState({ email: e.target.value.replace(/\s/g, "") })
    }
    onChangeUserMessage(e) {
        this.setState({ message: e.target.value.replace(/\s/g, " ") })
    }
    onChangeUserCheckbox(e) {
        this.setState({ checkbox: e.target.value, termscheck: e.target.checked })
        console.log(e.target.checked)
    }
    onChangeUserBrand_url(e) {
        this.setState({ brand_url: e.target.value })
    }
    onChangeUserAccomplish(e) {
        this.setState({ accomplish: e.target.value })
    }
    handleOpenModal(title_head, url_video) {
        this.setState({ showModal: true, modelContent: title_head, videoUrl: url_video });
    }

    handleCloseModal() {
        this.setState({ showModal: false });
    }
    handleChangeselect = selectedOption => {
        this.setState({ selectedOption, timedefault: selectedOption });
        console.log(`Option selected:`, selectedOption);
    }
    handleSelecttz = selectedtz => {
        console.log(`Option selected:`, selectedtz);
        console.log(selectedtz);
        console.log(selectedtz.value);
        if (selectedtz.value == "CT") {
            this.setState({ options: optionsct, timedefault: optionsct[0] })
        }
        else if (selectedtz.value == "PT") {
            this.setState({ options: optionspt, timedefault: optionspt[0] })
        }
        else if (selectedtz.value == "ET") {
            this.setState({ options: optionset, timedefault: optionset[0] })
        }
        else if (selectedtz.value == "MT") {
            this.setState({ options: optionsmt, timedefault: optionsmt[0] })
        }
        else if (selectedtz.value == "GMT") {
            this.setState({ options: optionsgmt, timedefault: optionsgmt[0] })
        }
        else {
            this.setState({ options: optionsct })
        }
    }
    onChangeUserCategories(e) {
        const target = e.target;
        var value = target.value;
        console.log(value);

        // this.state.categories.push(value);
        this.setState(prevState => {
            if (target.checked) {
                return {
                    ...prevState,
                    categories: prevState.categories.concat(value)
                }
            } else {
                const index = prevState.categories.indexOf(value);
                prevState.categories.splice(index, 1);
                if (index > -1) {
                    return {
                        ...prevState,
                        categories: prevState.categories
                    }
                } else {
                    return prevState;
                }
            }
        }, () => {
            const names = this.state.categories.map(item => {
                return CHECKBOX_VALUES[item]
            })
            console.log("names", names, this.state.inshightsdata)

            const insightsname = this.state.inshightsdata.filter(item => {
                console.log("item", item)
                const temp = names.find(name => {
                    return item.field_page_category.includes(name)
                })
                console.log("temp", temp)
                return temp ? true : false
            });
            console.log("insightsname", insightsname)
            this.setState(prevState => {
                return {
                    ...prevState,
                    filterinsight: insightsname.length ? insightsname : prevState.inshightsdata,
                    isFilterSelectedCategory: insightsname.length,
                    filterinsight: insightsname.length == 0 || insightsname.length == 1 ? prevState.inshightsdata : insightsname
                }

            })

        })
    }

    onChangeUserBudget(e) {
        this.setState({ budget: e.target.value.replace(/\s/g, "") })
    }
    onChangeUserTimeline(e) {
        this.setState({ timeline: e.target.value })
    }
    onChangeUserContacting_through(e) {
        // this.setState({ contacting_through: e.target.value.replace(/\s/g, "") })
        const target = e.target;
        var value = target.value;
        console.log(value);
        if (target.checked) {
            // this.state.categories[value] = value;   
            this.state.contacting_through.push(value);
            console.log("checked");
            if (value === "Phone") {
                this.setState({
                    phone_contact: true
                });
            }
            // this.setState({ categories:this.state.categories.push(value) });
        } else {
            const index = this.state.contacting_through.indexOf(value);
            console.log(index)
            if (index > -1) {
                //   array.splice(index, 1);
                this.state.contacting_through.splice(index, 1);
            }
            if (value === "Phone") {
                this.setState({
                    phone_contact: false
                });
            }
            // this.state.categories.splice(value, 1);
            console.log("unchecked");
            // this.setState({ categories:this.state.categories.splice(value, 1)});
        }
        console.log(this.state.contacting_through);
    }
    onChangeUserPhone_number(e) {
        this.setState({ phone_number: e.target.value.replace(/\s/g, "") })
    }
    onChangeUserTime(e) {
        this.setState({ time: e.target.value.replace(/\s/g, "") })
    }
    onChangeUserTime_zone(e) {
        this.setState({ time_zone: e.target.value.replace(/\s/g, "") })
    }
    onSlideChange = (oldIndex, newIndex) => {
        this.setState({ activeSlide: newIndex })
    }

    render() {
        var contactus = {
            dots: true,
            infinite: false,
            slidesToShow: 1,
            slidesToScroll: 1,
            arrows: false,
            draggable: false,
            pauseOnDotsHover: true,
            swipe: false,
            touchMove: false,
            beforeChange: this.onSlideChange
        }
        var insights = {
            dots: !1,
            infinite: !0,
            centerMode: !0,
            slidesToShow: 1,
            slidesToScroll: 1
        }
        // const datasplit = this.props.getcontactus.field_contact_title_text;
        // console.log(datasplit)
        // let data1 = datasplit.split(' (');
        // let data2 = '(' + data1[1];
        // console.log("1st", data1[0] + "2nd", data2)
        return (

            <>
                <VideoModal
                    show={this.state.showModal}
                    onClose={this.handleCloseModal}
                    url={this.state.videoUrl}
                    title={this.state.modelContent}
                    backLink='Back to page'
                />
                <MetaDecorator
                    description={contact.metaDescription}
                    title={contact.pageTitle}
                    href={contact.canonicalUrl}
                />
                <section className="digital-services">
                    <div className="wrapper">

                        <div className="title-service contact-title-content">
                            <h1>
                                {/* <ReactPlaceholder type='text' style={{ width: "400px", height: "50px" }} classname="placeholder-contact-title" rows={1} color="#ffda41" ready={!this.props.isLoading} showLoadingAnimation={true}> */}
                                {this.props.getcontactus.title}
                                {/* </ReactPlaceholder> */}
                            </h1>
                        </div>

                        <div className="form-slider contactus-slider">
                            <form autoComplete="off" onSubmit={this.onSubmit}>
                                <Slider ref={c => (this.slider = c)} {...contactus}>
                                    <div>
                                        <div className="contact-page" style={this.state.activeSlide !== 0 ? { display: 'none' } : {}}>
                                            <div className="row">
                                                <div className="col-md-6">
                                                    <div className="grow-brand-search">
                                                        <div className="contact-page-title">
                                                            <div className="title">
                                                                {/* <ReactPlaceholder type='text' style={{ width: "330px", height: "70px", marginBottom: "5px" }} rows={1} color="#ffda41" ready={!this.props.isLoading} showLoadingAnimation={true}> */}
                                                                {this.props.getcontactus.field_contact_title_text}
                                                                {/* </ReactPlaceholder> */}
                                                            </div>

                                                            <p>
                                                                {/* <ReactPlaceholder type='text' rows={2} ready={!this.props.isLoading} showLoadingAnimation={true}> */}
                                                                {this.props.getcontactus.field_form_description}
                                                                {/* </ReactPlaceholder> */}
                                                            </p>
                                                            <div className="schedul">
                                                                <ul className="shedul-img-content">
                                                                    <li>
                                                                        <a>
                                                                            {this.props.isLoading ? (
                                                                                <span className="">
                                                                                    <ReactPlaceholder type='rect' style={{ width: "35px", height: "35px", marginTop: "6px", marginRight: "20px", }} ready={false} showLoadingAnimation={true}>
                                                                                    </ReactPlaceholder>
                                                                                </span>
                                                                            ) : (<span className="img amd-calendly"></span>)}
                                                                            {/* {this.props.isLoading ? ( */}
                                                                            <ReactPlaceholder type='rect' color="#ffda41" style={{ width: "185px", height: "45px", padding: "8px 19px", borderRadius: "4px" }} ready={!this.props.isLoading} showLoadingAnimation={true}>
                                                                                <PopupButton
                                                                                    className="cont"
                                                                                    text="SCHEDULE A CALL"
                                                                                    url="https://calendly.com/ameexdigital/schedule-meeting-with-ameex-digital-team"
                                                                                />
                                                                            </ReactPlaceholder>
                                                                            {/* </span> */}
                                                                        </a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="col-md-6">
                                                    <div className="contact-page-title-form">
                                                        <div className="form">
                                                            <div className="form-group">
                                                                <ReactPlaceholder type='text' rows={1} style={{ width: "120px", marginBottom: "4px" }} ready={!this.props.isLoading} showLoadingAnimation={true}>
                                                                    <label htmlFor="name">Name <span style={{ color: "#eb0023" }}>*</span></label>
                                                                </ReactPlaceholder>


                                                                <input type="text" className="form-control" id="name" aria-describedby="namehelp" value={this.state.name} onChange={this.onChangeUserName} />
                                                                <div className="formerror">{(this.state.errors.name) ? (<span className="ex-warn"> ! </span>) : (null)}{this.state.errors.name}</div>
                                                            </div>
                                                            <div className="form-group">

                                                                <ReactPlaceholder type='text' rows={1} style={{ width: "120px", marginBottom: "4px" }} ready={!this.props.isLoading} showLoadingAnimation={true}>
                                                                    <label htmlFor="exampleInputEmail1">Email <span style={{ color: "#eb0023" }}>*</span></label>
                                                                </ReactPlaceholder>

                                                                <input type="text" className="form-control" id="exampleInputEmail1"
                                                                    aria-describedby="emailHelp" value={this.state.email}
                                                                    onChange={this.onChangeUserEmail} />
                                                                <div className="formerror">{(this.state.errors.email) ? (<span className="ex-warn"> ! </span>) : (null)}{this.state.errors.email}</div>
                                                            </div>
                                                            <div className="form-group">
                                                                <ReactPlaceholder type='text' rows={1} style={{ width: "135px", marginBottom: "4px" }} ready={!this.props.isLoading} showLoadingAnimation={true}>
                                                                    <label htmlFor="exampleFormControlTextarea1">Message <span style={{ color: "#eb0023" }}>*</span></label>
                                                                </ReactPlaceholder>

                                                                <textarea className="form-control" id="exampleFormControlTextarea1" rows="4" value={this.state.message} onChange={this.onChangeUserMessage}></textarea>
                                                                {/* <input type="text" className="form-control" id="name" aria-describedby="namehelp" value={this.state.name} onChange={this.onChangeUserMessage} /> */}
                                                                <div className="formerror">{(this.state.errors.message) ? (<span className="ex-warn"> ! </span>) : (null)}{this.state.errors.message}</div>
                                                            </div>


                                                            <div className="form-check b-check">
                                                                {this.props.isLoading ? (null) : (
                                                                    <input type="checkbox" className="form-check-input" id="exampleCheck1" onChange={this.onChangeUserCheckbox} className="filter-chkbox" />
                                                                )}
                                                                <label className="form-check-label" htmlFor="exampleCheck1">
                                                                    <ReactPlaceholder type='text' rows={3} style={{ width: "450px", height: "54px" }} ready={!this.props.isLoading} showLoadingAnimation={true}>
                                                                        <span className="terms-chk">By checking this box you confirm that you have read and agree to our <Link href="/privacy-policy-statement"><a className="contact-terms" style={{ color: "#8f7200" }}>Privacy Policy.</a></Link>
                                                                        </span>
                                                                    </ReactPlaceholder>
                                                                </label>
                                                            </div>
                                                            <div className="formerror">{(this.state.errors.checkbox) ? (<span className="ex-warn"> ! </span>) : (null)}{this.state.errors.checkbox}</div>
                                                            <ReactPlaceholder type='rect' color="#383f4e" style={{ width: "117px", height: "42px", borderRadius: "4px", marginTop: "50px", }} ready={!this.props.isLoading} showLoadingAnimation={true}>
                                                                <a className="btn f-submit next-contactslide" onClick={this.firstnext}>NEXT</a>
                                                            </ReactPlaceholder>
                                                            <p className="" style={{ paddingTop: "30px", fontFamily: 'hindregular' }}><span style={{ color: "#eb0023" }}>*</span> Indicates required field.</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div>
                                        <div className="contact-page" style={this.state.activeSlide !== 1 ? { display: 'none' } : {}}>
                                            <div className="row">
                                                <div className="col-md-6">
                                                    <div className="grow-brand-search">
                                                        <div className="contact-page-title">
                                                            <div className="title">
                                                                {this.props.getcontactus.field_contact_title_text}
                                                            </div>
                                                            {/* <p>Let’s get started with a few details <br/> and we’ll reach out to you.</p> */}
                                                            <p>
                                                                {this.props.getcontactus.field_form_description}
                                                            </p>
                                                            <div className="schedul">
                                                                <ul className="shedul-img-content">
                                                                    <li>
                                                                        <a>
                                                                            <span className="img amd-calendly"> </span>
                                                                            <PopupButton
                                                                                className="cont"
                                                                                text="SCHEDULE A CALL"
                                                                                url="https://calendly.com/ameexdigital/schedule-meeting-with-ameex-digital-team"
                                                                            />
                                                                        </a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="col-md-6">
                                                    <div className="contact-page-title-form">
                                                        <div className="form">
                                                            <div className="form-group">
                                                                <label htmlFor="name">What is your brand’s URL</label>
                                                                <input type="text" className="form-control" id="name" aria-describedby="namehelp" value={this.state.brand_url} onChange={this.onChangeUserBrand_url} />
                                                                <div className="formerror">{(this.state.errors.brand_url) ? (<span className="ex-warn"> ! </span>) : (null)}{this.state.errors.brand_url}</div>
                                                            </div>
                                                            <div className="form-group">
                                                                <label htmlFor="exampleInputEmail1">What are you looking to accomplish?</label>
                                                                <input type="text" className="form-control" id="exampleInputEmail1"
                                                                    aria-describedby="emailHelp" value={this.state.accomplish} onChange={this.onChangeUserAccomplish} />
                                                                <div className="formerror">{(this.state.errors.accomplish) ? (<span className="ex-warn"> ! </span>) : (null)}{this.state.errors.accomplish}</div>
                                                            </div>
                                                            <div className="form-check filter-chk">
                                                                <input type="checkbox" className="form-check-input" id="exampleCheck2" name="categories" value="E-commerce Growth Strategy" onChange={this.onChangeUserCategories} className="filter-chkbox" />
                                                                &nbsp;&nbsp;&nbsp;<label className="form-check-label-chk" htmlFor="exampleCheck2">E-Commerce Growth Strategy
                                                                </label>
                                                            </div>
                                                            <div className="form-check filter-chk">
                                                                <input type="checkbox" className="form-check-input" id="exampleCheck3" name="categories" value="Digital Marketing Strategy" onChange={this.onChangeUserCategories} className="filter-chkbox" />
                                                                &nbsp;&nbsp;&nbsp;<label className="form-check-label-chk" htmlFor="exampleCheck3">Digital Marketing Strategy
                                                                </label>
                                                            </div>
                                                            <div className="form-check filter-chk">
                                                                <input type="checkbox" className="form-check-input" id="exampleCheck4" name="categories" value="Search Engine Optimization" onChange={this.onChangeUserCategories} className="filter-chkbox" />
                                                                &nbsp;&nbsp;&nbsp;<label className="form-check-label-chk" htmlFor="exampleCheck4">Search Engine Optimization
                                                                </label>
                                                            </div>
                                                            <div className="form-check filter-chk">
                                                                <input type="checkbox" className="form-check-input" id="exampleCheck5" name="categories" value="Performance Marketing" onChange={this.onChangeUserCategories} className="filter-chkbox" />
                                                                &nbsp;&nbsp;&nbsp;<label className="form-check-label-chk" htmlFor="exampleCheck5">Performance Marketing
                                                                </label>
                                                            </div>
                                                            <div className="form-check filter-chk">
                                                                <input type="checkbox" className="form-check-input" id="exampleCheck6" name="categories" value="Analytics" onChange={this.onChangeUserCategories} className="filter-chkbox" />
                                                                &nbsp;&nbsp;&nbsp;<label className="form-check-label-chk" htmlFor="exampleCheck6">Analytics
                                                                </label>
                                                            </div>
                                                            <div className="form-check filter-chk">
                                                                <input type="checkbox" className="form-check-input" id="exampleCheck7" name="categories" value="UX &amp; Visual Design" onChange={this.onChangeUserCategories} className="filter-chkbox" />
                                                                &nbsp;&nbsp;&nbsp;<label className="form-check-label-chk" htmlFor="exampleCheck7">UX &amp; Visual Design
                                                                </label>
                                                            </div>
                                                            <div className="form-check filter-chk">
                                                                <input type="checkbox" className="form-check-input" id="exampleCheck8" name="categories" value="Digital Marketing Technology" onChange={this.onChangeUserCategories} className="filter-chkbox" />
                                                                &nbsp;&nbsp;&nbsp;<label className="form-check-label-chk" htmlFor="exampleCheck8">Digital Marketing Technology
                                                                </label>
                                                            </div>
                                                            <div className="group-of-button">
                                                                <ul>
                                                                    <li><a className="btn back prev-contactslide" onClick={this.secondprevious}>BACK</a></li>
                                                                    <li><a className="btn skip next-contactslide" onClick={this.skip}>SKIP</a></li>
                                                                    <li><a className="btn active next-contactslide" onClick={this.secondnext}>NEXT</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        {this.state.redirectToReferrer === false ? (
                                            <div className="contact-page" style={this.state.activeSlide !== 2 ? { display: 'none' } : {}}>
                                                <div className="row">
                                                    <div className="col-md-6">
                                                        <div className="grow-brand-search">
                                                            <div className="contact-page-title">
                                                                <div className="title">
                                                                    {this.props.getcontactus.field_contact_title_text}
                                                                </div>
                                                                {/* <p>Let’s get started with a few details <br/> and we’ll reach out to you.</p> */}
                                                                <p>
                                                                    {this.props.getcontactus.field_form_description}
                                                                </p>
                                                                <div className="schedul">
                                                                    <ul className="shedul-img-content">
                                                                        <li>
                                                                            <a>
                                                                                <span className="img amd-calendly"></span>
                                                                                <PopupButton
                                                                                    className="cont"
                                                                                    text="SCHEDULE A CALL"
                                                                                    url="https://calendly.com/ameexdigital/schedule-meeting-with-ameex-digital-team"
                                                                                />
                                                                            </a>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="col-md-6">
                                                        <div className="contact-page-title-form">
                                                            <div className="form">
                                                                <div className="form-group">
                                                                    <label htmlFor="name">What is your budget?</label>
                                                                    <NumberFormat thousandSeparator={true} prefix={'$ '} />
                                                                    {/* <input type="text" className="form-control" id="name" aria-describedby="namehelp" value={this.state.budget} onChange={this.onChangeUserBudget} /> */}
                                                                    <div className="formerror">{this.state.errors.budget}</div>
                                                                </div>
                                                                <div className="form-group">
                                                                    <label htmlFor="exampleInputEmail1">What is your timeline?</label>
                                                                    <input type="text" className="form-control" id="exampleInputEmail1"
                                                                        aria-describedby="emailHelp" value={this.state.timeline} onChange={this.onChangeUserTimeline} />
                                                                    <div className="formerror">{(this.state.errors.timeline) ? (<span className="ex-warn"> ! </span>) : (null)}{this.state.errors.timeline}</div>
                                                                </div>
                                                                <div className="formerror contacted-error">{(this.state.errors.chkbox) ? (<span className="ex-warn"> ! </span>) : (null)} {this.state.errors.chkbox}</div>
                                                                <div className="form-group">
                                                                    <label htmlFor="exampleInputEmail1">How do you want to be contacted? <span style={{ color: "#eb0023" }}>*</span></label>
                                                                </div>
                                                                {this.state.phone_contact === true ? (<div className="phone-content">Great! Please let us know your phone number.</div>) : (<></>)}
                                                                <div className="to-be-conected">
                                                                    <div className="form-check filter-phne">
                                                                        <input type="checkbox" className="form-check-input" id="exampleCheck10" name="contacting_through" value="Phone" onChange={this.onChangeUserContacting_through} className="filter-chkbox" />
                                                                        &nbsp;&nbsp;<label className="form-check-label-phne" htmlFor="exampleCheck10" >Phone
                                                                        </label>
                                                                    </div>&nbsp;&nbsp;
                                                                    {this.state.phone_contact === false ? (
                                                                        <div className="form-check filter-phne">
                                                                            <input type="checkbox" className="form-check-input" id="exampleCheck9" name="contacting_through" value="Email" onChange={this.onChangeUserContacting_through} className="filter-chkbox" />
                                                                            &nbsp;&nbsp;<label className="form-check-label-phne" htmlFor="exampleCheck9">Email
                                                                            </label>
                                                                        </div>
                                                                    ) : (<></>)}
                                                                    {this.state.phone_contact === true ? (
                                                                        <div className="form-group">
                                                                            <PhoneInput
                                                                                name="phone_number"
                                                                                className="textbox phone"
                                                                                placeholder="Enter your mobile number"
                                                                                tabIndex="4"
                                                                                defaultCountry="US"
                                                                                value={this.state.phone_number}
                                                                                onChange={phone_number => this.setState({ phone_number })}
                                                                            />
                                                                            <div className="formerror">{(this.state.errors.phone_number) ? (<span className="ex-warn"> ! </span>) : (null)} {this.state.errors.phone_number}</div>
                                                                        </div>
                                                                    ) : (<></>)}

                                                                </div>
                                                                {this.state.phone_contact === true ? (
                                                                    <>
                                                                        <div className="form-group">
                                                                            <label htmlFor="exampleInputEmail1">Let us know a good time to call. (optional)</label>
                                                                        </div>
                                                                        <div className="to-be-conected time-zoone">
                                                                            <div className="form-group">
                                                                                <Select
                                                                                    // value={selectedOption}
                                                                                    onChange={this.handleChangeselect}
                                                                                    value={this.state.timedefault}
                                                                                    options={this.state.options}
                                                                                    className="form-control"
                                                                                    classNamePrefix="custom-dd"
                                                                                />
                                                                            </div>
                                                                            <div className="form-group stdtime-btn">
                                                                                <Select
                                                                                    onChange={this.handleSelecttz}
                                                                                    defaultValue={optionstime[0]}
                                                                                    options={optionstime}
                                                                                    className="form-group stdtime-btn"
                                                                                    classNamePrefix="custom-dd"
                                                                                />
                                                                            </div>

                                                                        </div>
                                                                    </>
                                                                ) : (<></>)}
                                                                <div className="group-of-button submit-btn">
                                                                    <ul>
                                                                        <li><a className="btn back prev-contactslide" onClick={this.thirdprevious}>BACK</a></li>
                                                                        {/* <li><a className="btn active" onClick={this.postdetails}>SUBMIT</a></li> */}
                                                                        <li><input type="submit" className="btnsub" value=" SUBMIT" /></li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        ) : (<></>)}
                                        {this.state.redirectToReferrer === true ? (
                                            <div className="contact-page">
                                                <div className="row">
                                                    <div className="col-md-6">
                                                        <div className="grow-brand-search">
                                                            <div className="contact-page-title">
                                                                <h1>
                                                                    Looks great
                                                                </h1>
                                                                <p>We’ll be in touch soon to get <br /> started on your business goals.</p>

                                                                <div className="schedul">
                                                                    <ul className="shedul-img-content">
                                                                        <li><a href=""><span className="img amd-calendly"></span>
                                                                            <PopupButton
                                                                                className="cont"
                                                                                text="SCHEDULE A CALL"
                                                                                url="https://calendly.com/ameexdigital/schedule-meeting-with-ameex-digital-team"
                                                                            />
                                                                        </a></li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="col-md-6">

                                                        <div className="contact-page-title-form">
                                                            <div className="thank-page">
                                                                <h2>Thank You</h2>
                                                                <p className="s-based">In the meantime, check out these insights{this.state.isFilterSelectedCategory ? ` based on the services you selected.` : ':'}</p>

                                                                <div className="smart-video-conetne">
                                                                    <div className="check-out">
                                                                        <div className="s-card">
                                                                            <img className="video-img" src={this.state.filterinsight[0]?.field_mobile_video_thumbnail} />
                                                                            <a href="#" className="play-icon" onClick={this.handleOpenModal.bind(this, this.state.filterinsight[0]?.title, this.state.filterinsight[0]?.field_watch_video_link)}> <span className="video-icon amd-play3"></span> </a>
                                                                            {/* <p>{this.state.filterinsight[0].title}</p> */}
                                                                        </div>
                                                                        <div className="s-user-content">
                                                                            <p className="title-line-wrap"><a href={`${this.state.filterinsight[0]?.view_node}`} style={{ cursor: "pointer" }}>{this.state.filterinsight[0]?.title}</a></p>
                                                                            <div className="s-user-profile">
                                                                                <img src={this.state.filterinsight[0]?.field_authors_profile_image} alt="user-icons" />
                                                                                <p>{this.state.filterinsight[0]?.field_auth} <br /> <span>{this.state.filterinsight[0]?.field_authors_date} </span> </p>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div className="check-out">
                                                                        <div className="s-card">
                                                                            <img className="video-img" src={this.state.filterinsight[1]?.field_mobile_video_thumbnail} />
                                                                            <a href="#" className="play-icon" onClick={this.handleOpenModal.bind(this, this.state.filterinsight[1]?.title, this.state.filterinsight[1]?.field_watch_video_link)}> <span className="video-icon amd-play3"></span> </a>
                                                                            {/* <p>{this.state.filterinsight[1].title}</p> */}
                                                                        </div>
                                                                        <div className="s-user-content-sec">
                                                                            <div className="s-user-content-second">
                                                                                <p className="sec-content"><a href={`${this.state.filterinsight[1]?.view_node}`} style={{ cursor: "pointer" }}>{this.state.filterinsight[1]?.title}</a></p>
                                                                                <div className="s-user-profile">
                                                                                    <img src={this.state.filterinsight[1]?.field_authors_profile_image} alt="user-icons" />
                                                                                    <p>{this.state.filterinsight[1]?.field_auth} <br /> <span>{this.state.filterinsight[1]?.field_authors_date} </span> </p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div className="mobile-thankyou ipad-thankyou">
                                                                    <div className="night-slider">
                                                                        <div className="center slider" style={{ width: "120%", marginLeft: "-31px" }}>
                                                                            <Slider {...insights}>
                                                                                {this.state.insightsbanner_leftsider.map((insightleftsider, index) => (
                                                                                    <div key={index}>
                                                                                        <div className="media-video youtube-player" >
                                                                                            <span className="thumbvideo-home amd-play3" style={{ cursor: "pointer" }} onClick={this.handleOpenModal.bind(this, insightleftsider.title, this.state.inshights.field_watch_video_link)}></span>
                                                                                            <img href="#" onClick={this.handleOpenModal.bind(this, insightleftsider.title, insightleftsider.field_watch_video_link)} src={insightleftsider.field_mobile_video_thumbnail} style={{ width: '100%', height: '352px', cursor: 'pointer' }} alt="" />
                                                                                            <div className="strategy">
                                                                                                <div className="set">
                                                                                                    <a href={`${insightleftsider.view_node}`} style={{ cursor: "pointer" }}><h4>{insightleftsider.title}</h4></a>
                                                                                                    {/* <p>{insightleftsider.field_insight_description}</p> */}
                                                                                                    <div><a className="read-art amd-readarticle" href={`${insightleftsider.view_node}`} style={{ cursor: "pointer", color: "#ffffff" }}><span className="read-article1"></span><span className="mob-art">{insightleftsider.field_read_more_text}</span></a></div>
                                                                                                </div>
                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                ))
                                                                                }
                                                                            </Slider>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div className="insights-btn">
                                                                    <Link href="/insights" className="btn"><a> MORE INSIGHTS</a></Link>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        ) : (<></>)}
                                    </div>
                                </Slider>
                            </form>
                        </div>
                    </div>
                </section>
                <section className="tab-mob-calendly">
                    <div className="schedul">
                        <ul className="shedul-img-content">
                            <li><a href=""><span className="img amd-calendly"></span>
                                <PopupButton
                                    className="cont"
                                    text="SCHEDULE A CALL"
                                    url="https://calendly.com/ameexdigital/schedule-meeting-with-ameex-digital-team"
                                />
                            </a></li>
                        </ul>
                    </div>
                </section>
                <Omnis />
                <MonthlyBudget />
                {/* -- start-searching-doing --> */}
                <section className="contact-services">
                    <div className="container-fluid">
                        <div className="wrapper">
                            <div className="row">
                                <div className="col-md-2 col-sm-4 col-xs-12">
                                    <div className="office-address">
                                        <p>Headquarters</p>
                                        <h4> Ameex Technologies Corp HQ
                                            1701 E Woodfield Rd, Suite 710
                                            Schaumburg, IL 60173</h4>
                                    </div>
                                </div>
                                <div className="col-md-2 col-sm-4 col-xs-12">
                                    <div className="office-address">
                                        <p>Other US Offices </p>
                                        <h4> California <br />
                                            Colorado<br />
                                            Texas<br />
                                            Virginia<br />
                                            Washington, D.C</h4>
                                    </div>
                                </div>

                                <div className="col-md-2 col-sm-4 col-xs-12">
                                    <div className="office-address">
                                        <p>Pune India</p>
                                        <h4> Marisoft IT park building 3
                                            Third floor office 339
                                            Kalyaninagar Pune 411015</h4>
                                    </div>
                                </div>
                                <div className="col-md-2 col-sm-4 col-xs-12">
                                    <div className="office-address">
                                        <p>Chennai India</p>
                                        <h4>
                                            6th Floor, IIFL Tower,
                                            143, MGR Road, Perungudi
                                            Chennai
                                        </h4>
                                    </div>
                                </div>
                                <div className="col-md-2 col-sm-4 col-xs-12">
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-md-2 col-sm-4 col-xs-12">
                                    <div className="office-address">
                                        <p>Singapore </p>
                                        <h4>
                                            17, upper circular road
                                            02-00 Juta Building
                                            Singapore 058415</h4>
                                    </div>
                                </div>
                                <div className="col-md-2 col-sm-4 col-xs-12">
                                    <div className="office-address">
                                        <p>BELGIUM</p>
                                        <h4> Ham 32 <br />
                                            9000, Gent <br />
                                            Belgium</h4>
                                    </div>
                                </div>
                                <div className="col-md-8 col-sm-12">
                                    <div className="office-address">
                                        <h1><img src={'/assets/images/location.png'} alt="" />Where We Are</h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                {/* <div className="contactus-our-clients">
                    <OurClients />
                </div> */}
            </>
        );

    }
}
export default ContactUs;
export async function getStaticProps(context) {
    try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/contacts/35`);
        const result = await res.json();

        return {
            props: {
                // data: result,
                getcontactus: result?.[0],
                isLoading: false
            },
            revalidate: 10,
        }
    } catch (e) {
        console.log("catch error", e)
        return {
            props: {
                getcontactus: {},
                isLoading: false

            },
            revalidate: 10,
        }
    }
}
