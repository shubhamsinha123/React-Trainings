import React from 'react';
import { useRouter } from 'next/router'
import SearchResult from "../../components/searchresult"

const Searchres = () => {
  const router = useRouter()
  const { search } = router.query
  return <SearchResult id={search}/>
}

export default Searchres