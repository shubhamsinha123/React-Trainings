import Document, { Html, Head, Main } from 'next/document'
import DeferNextScript from '../components/DeferNextScript';
// import Script from 'next/script'

const GTM_ID = 'GTM-K4PWR74';
class MyDocument extends Document {
  static async getInitialProps(ctx) {
    const initialProps = await Document.getInitialProps(ctx)
    return { ...initialProps }
  }

  render() {
    return (
      <Html>
        <Head>
          {/* {process.env.NODE_ENV === 'production' && */}
            <meta httpEquiv="Content-Security-Policy" />
            {/* <link rel="canonical" href="https://www.ameexdigital.com"/> */}
          {/* } */}
          {/* Google Tag Manager */}
          {/* {process.env.NODE_ENV === 'production' &&
            <script defer
              dangerouslySetInnerHTML={{
                __html: GTMJs
              }}
            />
          }  */}
          {/* End Google Tag Manager */}

          {/* CloudFlare started */}
          {/* {process.env.NODE_ENV === 'production'
          <Script
          defer
          id="cloudflare-script"
          strategy='lazyOnload'
          src = 'https://static.cloudflareinsights.com/beacon.min.js?token=v64f9daad31f64f81be21cbef6184a5e31634941392597'
        />
          }  */}
          {/* CloudFlare Ended */}
          <link
            rel='preload'
            as="image"
            href='https://prod-drupal.ameexdigital.com/sites/default/files/2021-11/hero-banner-mobile.webp'
            crossOrigin='anonymous'
          />
          <link
            rel='preload'
            as="image"
            href ='https://prod-drupal.ameexdigital.com/sites/default/files/2022-01/thrive-mobile.webp'
            crossOrigin='anonymous'
          />
          <link
            rel='preload'
            as='font'
            href='/assets/fonts/Hind-Regular.woff2'
            type='font/woff2'
            crossOrigin='anonymous'
          />
          <link
            rel='preload'
            as='font'
            href='/assets/fonts/Hind-Light.woff2'
            type='font/woff2'
            crossOrigin='anonymous'
          />
          <link
            rel='preload'
            as='font'
            href='/assets/fonts/Hind-Medium.woff2'
            type='font/woff2'
            crossOrigin='anonymous'
          />
          <link
            rel='preload'
            as='font'
            href='/assets/fonts/Hind-SemiBold.woff2'
            type='font/woff2'
            crossOrigin='anonymous'
          />
          <link
            rel='preload'
            as='font'
            href='/assets/fonts/Hind-Bold.woff2'
            type='font/woff2'
            crossOrigin='anonymous'
          />
          <link
            rel='preload'
            as='font'
            href='/assets/fonts/ameexdigital-icons.ttf'
            type='font/ttf'
            crossOrigin='anonymous'
          />
          <link
            rel='preload'
            as="image"
            href='/assets/images/group.svg'
          />
          
        </Head>
        <body>
          {/* {process.env.NODE_ENV === 'production' && */}
            <noscript defer
              dangerouslySetInnerHTML={{
                __html: `<iframe src="https://www.googletagmanager.com/ns.html?id=${GTM_ID}" height="0" width="0" style="display:none;visibility:hidden"></iframe>`,
              }}
            />
          {/* } */}
          <Main />
          <DeferNextScript />
        </body>
      </Html>
    )
  }
}

export default MyDocument