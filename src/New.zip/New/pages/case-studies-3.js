import React, { useEffect } from 'react';
import CaseStudies from '../components/CaseStudies'
import Head from 'next/head';
import MetaDecorator from '../components/Util/MetaDecorator';
import Schema from '../components/Util/Schema';

const casestudy2 = require("../data/casestudy2");

const CaseStudiesDetailVitaminsIndustry2 = (props) => {
    useEffect(() => {
        setTimeout(() => {
            window.scrollTo(0, 0);
        }, 300)
    }, []);
    return (
        <>
            <MetaDecorator
                description={casestudy2.metaDescription}
                title={casestudy2.pageTitle}
                href={casestudy2.canonicalUrl}
            />
            {
                props.casestudiesdetails_schema_types_export && props.casestudiesdetails_schema_types_export.map((data) =>
                    <Schema data={JSON.parse(data.body)} />
                )
            }
            <CaseStudies caseId={25} pageClass='headlinks' {...props} />
        </>
    )
}
export default CaseStudiesDetailVitaminsIndustry2
export async function getStaticProps(context) {
    try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/case-study-detail/25`);
        const result = await res.json();
        console.log("case check", result)
        return {
            props: {
                casestudiesdetails: result[0],
                casestudiesdetails_big_picture_secion_export: result[0].field_big_picture_secion_export[0],
                casestudiesdetails_export_1: result[0].field_case_studies_detail_export_1,
                casestudiesdetails_default_navigation: result[0].field_case_studies_detail_export_1[0].navigation,
                casestudiesdetails_schema_types_export: result[0].field_schema_types_export,
                isLoading: false
            },
            revalidate: 10,
        }
    } catch (e) {
        return {
            props: {
                data: [],
                casestudiesdetails: [],
                casestudiesdetails_big_picture_secion_export: [],
                casestudiesdetails_export_1: [],
                casestudiesdetails_default_navigation: [],
                casestudiesdetails_schema_types_export: [],
                isLoading: false
            },
            revalidate: 10,
        }
    }
}