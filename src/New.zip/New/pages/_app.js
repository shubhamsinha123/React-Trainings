// import '../styles/globals.css'
import '../styles/scss/global.scss'
import '../styles/scss/variables.scss'
import '../styles/scss/mixins.scss'
import '../styles/scss/mobile.scss'
import '../styles/scss/ipad.scss'
import '../styles/scss/desktop.scss'

require('../styles/scss/bottom-mobile.scss')
require('../styles/scss/bottom-ipad.scss')
require('../styles/scss/bottom-desktop.scss')
require('../styles/scss/home-page.scss')

// import Script from 'next/script';
import { useEffect, useState } from 'react'
import { useRouter } from 'next/router'
import { Hydrate, QueryClient, QueryClientProvider } from 'react-query'
import Layout from '../components/layout';
import React from 'react';
import { ParallaxProvider } from 'react-scroll-parallax';

const GTM_ID = 'GTM-K4PWR74';

const GTMJs = `
(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','${GTM_ID}');
`;

const pageview = (url) => {
  window.dataLayer.push({
    event: 'pageview',
    page: url,
  })
}
function MyApp({ Component, pageProps }) {
  const router = useRouter();
  const [queryClient] = useState(() => new QueryClient())

  useEffect(() => {
    // if(process.env.NODE_ENV === 'production') {
      setTimeout(() => {
        const fragment = document.createDocumentFragment();
        const script = document.createElement('script');
        script.defer = '';
        script.innerHTML = GTMJs;
        fragment.appendChild(script);
        
        const cfScript = document.createElement('script');
        cfScript.id = 'cloudflare-script';
        cfScript.defer = '';
        cfScript.src = 'https://static.cloudflareinsights.com/beacon.min.js?token=v64f9daad31f64f81be21cbef6184a5e31634941392597';
        fragment.appendChild(cfScript);

        document.body.appendChild(fragment);
        // console.log('SCRIPTS >>', script, cfScript)
      }, 8000);
    // }
    const handleRouteChange = (url) => {
      pageview(url);
      // window.scroll({
      //   top: 0,
      //   left: 0,
      // });
    }

    router.events.on('routeChangeComplete', handleRouteChange)

    return () => {
      router.events.off('routeChangeComplete', handleRouteChange)
    }
  }, []);

  return (
    <>
      <ParallaxProvider>
        <QueryClientProvider client={queryClient}>
          <Hydrate state={pageProps.dehydratedState}>
            <Layout header={pageProps.headerData} footer={pageProps.footerData} allInsights={pageProps.allInsightsData}>
              <Component {...pageProps} />
            </Layout>
          </Hydrate>
        </QueryClientProvider>
      </ParallaxProvider>
    </>
  )
}

export default MyApp
