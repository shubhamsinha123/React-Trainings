import React from 'react';
// import OurClients from '../components/common/ourClients/ourclients';
import PromotionalBanner from '../components/common/promotionalBanner/promotionalBanner';
import Leader from '../components/about/leader-section';
import LeaderMobile from '../components/about/leader-section-mobile';
import MetaDecorator from "../components/Util/MetaDecorator";
import { PopupButton } from "react-calendly";
import Link from 'next/link';
import ReactPlaceholder from 'react-placeholder';
import "react-placeholder/lib/reactPlaceholder.css";
import { LazyLoadImage } from 'react-lazy-load-image-component';
import 'react-lazy-load-image-component/src/effects/blur.css';
const aboutus = require("../data/aboutus.json");

class Aboutus extends React.Component {
    constructor(props) {

        super(props);
        this.state = {
            users: [],
            isLoading: true
        }
    }
    componentDidMount() {
        setTimeout(() => {
            window.scrollTo(0, 0);
        }, 300)
        if (this.props.isLoading) {
            fetch(`${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/aboutus/36`)
                .then(res => res.json())
                .then(result => {
                    console.log('__RES__:From About Us Page', result)
                    this.setState({
                        users: result,
                        isLoading: false,
                    })
                })
                .catch(e => console.log('__ERROR__:From About Us Page', e))
        }
        else {
            this.setState({
                users: this.props.users,
                isLoading: false
            })
        }
    }
    render() {
        // console.log(process.env);
        // const { users } = this.props;
        const { users, isLoading } = this.state;
        return (
            <>
                <MetaDecorator
                    description={aboutus.metaDescription}
                    title={aboutus.pageTitle}
                    href={aboutus.canonicalUrl}
                />
                <section className="aboutus-banner">
                    {isLoading ? (
                        <>
                            <picture>
                                <ReactPlaceholder type='rect' className="img about-placeholder-mobile" height="652px" position="relative" ready={false} showLoadingAnimation={true}></ReactPlaceholder>

                            </picture>

                            <div className="container-fluid">
                                <div className="wrapper">
                                    <div className="row">

                                        <div className="col-md-12 col-sm-12 col-xs-12 pad-lr-0">

                                            {/* <img src={user.field_desktop_banner} className="img-responsive desktop-img" alt=".." />
                                            <img src={user.field_mobile_banner1} className="img-responsive mobile-img" alt=".." /> */}
                                            <div className="aboutus-banner-content">
                                                <div>
                                                    <h1>

                                                        <ReactPlaceholder type='text' rows={2} style={{ width: "530px" }} color="#1c1d21" className="about-placeholder-title" ready={false} showLoadingAnimation={true}></ReactPlaceholder>

                                                    </h1>
                                                    <p>

                                                        <ReactPlaceholder type='text' rows={4} color="#1c1d21" style={{ width: "500px" }} className="about-placeholder-para" ready={false} showLoadingAnimation={true}></ReactPlaceholder>

                                                    </p>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </>
                    ) : (

                        users.map(user => {
                            return (
                                <>
                                    {/* <LazyLoadComponent effect="blur"> */}
                                    <picture>
                                        {/* <source media="(max-width: 767px)" className="img-responsive" srcSet={user.field_mobile_banner1} /> */}

                                        <LazyLoadImage effect="blur" src={user.field_desktop_banner} className="img" alt=".." />

                                    </picture>
                                    {/* </LazyLoadComponent> */}
                                    <div className="container-fluid">
                                        <div className="wrapper">
                                            <div className="row">
                                                <div className="col-md-12 col-sm-12 col-xs-12 pad-lr-0">
                                                    <div className="aboutus-banner-content">
                                                        <div>
                                                            <h1>

                                                                {user.field_banner_title}

                                                            </h1>
                                                            <p>
                                                                <span dangerouslySetInnerHTML={{ __html: user.field_banner_description }}></span>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </>
                            );
                        })

                    )}



                </section>
                <section className="aboutus-subbanner">
                    <div className="container-fluid">
                        <div className="wrapper">
                            <div className="row">

                                <ul>
                                    {isLoading ? (
                                        <>
                                            <li>
                                                <h2>
                                                    <ReactPlaceholder type='text' rows={1} color="#ffda41" ready={false} showLoadingAnimation={true}></ReactPlaceholder>
                                                </h2>
                                                <p>
                                                    <ReactPlaceholder type='text' rows={1} ready={false} showLoadingAnimation={true}></ReactPlaceholder>
                                                </p>
                                            </li>
                                            <li>
                                                <h2>
                                                    <ReactPlaceholder type='text' rows={1} color="#ffda41" ready={false} showLoadingAnimation={true}></ReactPlaceholder>
                                                </h2>
                                                <p>
                                                    <ReactPlaceholder type='text' rows={1} ready={false} showLoadingAnimation={true}></ReactPlaceholder>
                                                </p>
                                            </li>
                                            <li>
                                                <h2>
                                                    <ReactPlaceholder type='text' rows={1} color="#ffda41" ready={false} showLoadingAnimation={true}></ReactPlaceholder>
                                                </h2>
                                                <p>
                                                    <ReactPlaceholder type='text' rows={1} ready={false} showLoadingAnimation={true}></ReactPlaceholder>
                                                </p>
                                            </li>
                                        </>
                                    ) : (

                                        users.map(user => {
                                            return (
                                                user.field_range_export.map(range => {
                                                    return (
                                                        <li>
                                                            <h2>

                                                                {range.range_value}</h2>
                                                            <p>
                                                                {range.range_title1}</p>
                                                        </li>
                                                    );
                                                })
                                            );
                                        })

                                    )}
                                </ul>
                            </div>
                        </div>
                    </div>
                </section>
                <div className="desktop-only">
                    <Leader users={users} />
                </div>
                <div className="mobile-only">
                    <LeaderMobile users={users} />
                </div>
                <section className="book-appointment">
                    <div className="container-fluid">
                        <div className="wrapper">
                            <div className="row">
                                <div className="col-md-8 col-sm-6 col-xs-12">
                                    {isLoading ? (
                                        <div>
                                            <h2>
                                                <ReactPlaceholder type='text' rows={1} style={{ width: "500px" }} color="#ffda41" ready={false} showLoadingAnimation={true}></ReactPlaceholder>
                                            </h2>
                                            <p>

                                                <ReactPlaceholder type='text' rows={1} style={{ width: "540px" }} ready={false} showLoadingAnimation={true}></ReactPlaceholder>
                                            </p>
                                        </div>
                                    ) : (

                                        users.map(user => {
                                            return (
                                                <div>
                                                    <h2>
                                                        {user.field_middle_title}
                                                    </h2>
                                                    <p>
                                                        {user.field_middle_paragraph}
                                                    </p>
                                                </div>
                                            );
                                        })

                                    )}
                                </div>
                                <div className="col-md-4 col-sm-6 col-xs-12">
                                    {isLoading ? (
                                        <span className=""> <ReactPlaceholder type='rect' style={{ width: "35px", height: "35px", marginTop: "6px", marginRight: "20px", }} ready={false} showLoadingAnimation={true}></ReactPlaceholder> </span>
                                    ) : (<span className="img-book-appointment img amd-calendly"></span>)}
                                    {isLoading ? (
                                        <ReactPlaceholder type='rect' style={{ width: "300px", height: "60px" }} color="#ffda41" ready={false} showLoadingAnimation={true}></ReactPlaceholder>
                                    ) : (
                                        <PopupButton
                                            className="schedule-btn"
                                            text="SCHEDULE A CALL"
                                            url="https://calendly.com/ameexdigital/schedule-meeting-with-ameex-digital-team"
                                        />
                                    )}

                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section className="our-histry">
                    <div className="container-fluid">
                        <div className="wrapper">
                            <div className="row">
                                <div className="col-md-12 col-sm-12 col-xs-12">
                                    <div className="row">
                                        <div className="title-block-mobile">
                                            {isLoading ? (
                                                <div>
                                                    <h2>
                                                        <ReactPlaceholder type='text' rows={1} ready={false} showLoadingAnimation={true}></ReactPlaceholder>
                                                    </h2>
                                                    <p>

                                                        <ReactPlaceholder type='text' rows={10} ready={false} showLoadingAnimation={true}></ReactPlaceholder>
                                                    </p>
                                                </div>
                                            ) : (
                                                users.map(user => {
                                                    return (
                                                        <div>
                                                            <h2>
                                                                {user.field_our_history_title}</h2>
                                                            <p>
                                                                {user.field_our_history_description}</p>
                                                        </div>
                                                    );
                                                })
                                            )}
                                        </div>
                                        <div className="col-md-6 col-sm-6 col-xs-12 our-histry-left">
                                            <div className="title-block">
                                                {isLoading ? (
                                                    <div>
                                                        <h2>

                                                            <ReactPlaceholder type='text' rows={1} ready={false} showLoadingAnimation={true}></ReactPlaceholder>
                                                        </h2>
                                                        <p>

                                                            <ReactPlaceholder type='text' rows={2} ready={false} showLoadingAnimation={true}></ReactPlaceholder>
                                                        </p>
                                                    </div>
                                                ) : (
                                                    users.map(user => {
                                                        return (
                                                            <div>
                                                                <h2>
                                                                    {user.field_our_history_title}</h2>
                                                                <p>
                                                                    {user.field_our_history_description}</p>
                                                            </div>
                                                        );
                                                    })
                                                )}
                                            </div>
                                            {isLoading ? (
                                                <div className="star-box">
                                                    <div className="star-logo">
                                                        <picture>
                                                            {/* <source media="(max-width: 767px)" className="img-responsive" srcSet={history.star_desktop_image} /> */}
                                                            <ReactPlaceholder type='round' style={{ width: "125px", height: "125px", borderradius: "50%", marginLeft: "80%" }} ready={false} showLoadingAnimation={true}></ReactPlaceholder>
                                                        </picture>
                                                    </div>
                                                    <div className="col-md-12 col-sm-12 col-xs-12 year-des">
                                                        <div className="row">
                                                            <div className="star-des">
                                                                <p>

                                                                    <ReactPlaceholder type='text' rows={5} style={{ width: "400px", height: "110px" }} ready={false} showLoadingAnimation={true}></ReactPlaceholder>
                                                                </p>
                                                            </div>
                                                            <div className="star-year">
                                                                <h3>
                                                                    <ReactPlaceholder type='text' rows={1} style={{ width: "200px", height: "70px" }} ready={false} showLoadingAnimation={true}></ReactPlaceholder>
                                                                </h3>
                                                            </div>
                                                        </div>
                                                    </div>

                                                </div>
                                            ) : (
                                                users.map(user => {
                                                    return (
                                                        user.field_history_export.map((history, num) => {
                                                            if (num % 2 !== 0) {
                                                                return (
                                                                    <div className="star-box">
                                                                        <div className="star-logo">
                                                                            <picture>
                                                                                <source media="(max-width: 767px)" className="img-responsive" srcSet={history.star_desktop_image} />
                                                                                <LazyLoadImage effect="blur" src={history.star_desktop_image} className="img-responsive" alt=".." />
                                                                            </picture>

                                                                        </div>
                                                                        <div className="col-md-12 col-sm-12 col-xs-12 year-des">
                                                                            <div className="row">
                                                                                <div className="copy-logo">

                                                                                </div>
                                                                                <div className="star-des">
                                                                                    <p>
                                                                                        {history.history_content}</p>
                                                                                </div>
                                                                                <div className="star-year">
                                                                                    <h3>
                                                                                        {history.year_of_publishing}
                                                                                    </h3>
                                                                                </div>
                                                                            </div>
                                                                        </div>

                                                                    </div>
                                                                );
                                                            }
                                                        })
                                                    );
                                                })
                                            )}
                                        </div>
                                        <div className="col-md-6 col-sm-6 col-xs-12 our-histry-right">
                                            {isLoading ? (
                                                <div className="star-box">
                                                    <div className="star-logo">
                                                        <picture>
                                                            {/* <source media="(max-width: 767px)" className="img-responsive" srcSet={history.star_desktop_image} /> */}
                                                            <ReactPlaceholder type='round' style={{ width: "125px", height: "125px", borderradius: "50%", }} ready={false} showLoadingAnimation={true}></ReactPlaceholder>
                                                        </picture>

                                                    </div>
                                                    <div className="col-md-12 col-sm-12 col-xs-12 year-des">
                                                        <div className="row">
                                                            <div className="copy-logo">
                                                            </div>
                                                            <div className="star-year">
                                                                <h3>
                                                                    <ReactPlaceholder type='text' rows={1} style={{ width: "200px", height: "70px" }} ready={false} showLoadingAnimation={true}></ReactPlaceholder>
                                                                </h3>
                                                            </div>
                                                            <div className="star-des">
                                                                <p>
                                                                    <ReactPlaceholder type='text' rows={5} style={{ width: "400px", height: "110px" }} ready={false} showLoadingAnimation={true}></ReactPlaceholder>
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            ) : (
                                                users.map(user => {
                                                    return (
                                                        user.field_history_export.map((history, num) => {
                                                            if (num % 2 == 0) {
                                                                return (
                                                                    <div className="star-box">
                                                                        <div className="star-logo">
                                                                            <picture>
                                                                                <source media="(max-width: 767px)" className="img-responsive" srcSet={history.star_desktop_image} />
                                                                                <LazyLoadImage effect="blur" src={history.star_desktop_image} className="img-responsive" alt=".." />
                                                                            </picture>

                                                                        </div>
                                                                        <div className="col-md-12 col-sm-12 col-xs-12 year-des">
                                                                            <div className="row">
                                                                                <div className="copy-logo">
                                                                                </div>
                                                                                <div className="star-year">
                                                                                    <h3>
                                                                                        {history.year_of_publishing}
                                                                                    </h3>
                                                                                </div>
                                                                                <div className="star-des">
                                                                                    <p>
                                                                                        {history.history_content}
                                                                                    </p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                );
                                                            }
                                                        })
                                                    );
                                                })
                                            )}
                                        </div>
                                        {isLoading ? (
                                            <div className="col-md-12 col-sm-12 col-xs-12 text-center our-histry-bottom">
                                                <p>
                                                    <ReactPlaceholder type='text' rows={1} ready={false} showLoadingAnimation={true}></ReactPlaceholder>
                                                </p>
                                            </div>) : (
                                            users.map(user => {
                                                return (
                                                    <div className="col-md-12 col-sm-12 col-xs-12 text-center our-histry-bottom">
                                                        <p>
                                                            {user.field_our_history_bottom_descrip}
                                                        </p>
                                                    </div>
                                                );
                                            })
                                        )}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <section className="find-us">
                    <picture>
                        <source media="(max-width: 767px)" className="mobile-img " srcSet={'/assets/images/findus-device.svg'} />
                        <img src={'/assets/images/findus.svg'} className="desktop-img" alt=".." usemap="#findusmap" />
                    </picture>
                    {/* <img src={findus} alt=".." className="desktop-img" usemap="#findusmap" />
                    <img src={findusdevice} alt=".." className="mobile-img"  usemap="#findusmap" /> */}
                    <div className="tooltip-section">
                        <a data-tooltip="Singapore 17, upper circular road 02-00 Juta Building Singapore 058415" className="map-location singapore"></a>
                        <a data-tooltip="Chennai India 6th Floor, IIFL Tower, 143, MGR Road, Perungudi Chennai" className="map-location india1"></a>
                        <a data-tooltip="Pune India Marisoft IT park building 3 Third floor office 339 Kalyaninagar Pune 411015" className="map-location india2"></a>
                        <a data-tooltip="Belgium Ham 32 9000, Gent Belgium" className="map-location uk"></a>
                        <a data-tooltip="Washington, D.C" className="map-location usa1"></a>
                        <a data-tooltip="Virginia" className="map-location usa2"></a>
                        <a data-tooltip="Texas" className="map-location usa3"></a>
                        <a data-tooltip="Colorado" className="map-location usa4"></a>
                        <a data-tooltip="California" className="map-location usa5"></a>
                        <a data-tooltip="Headquarters Ameex Technologies Corp HQ 1701 E Woodfield Rd, Suite 710 Schaumburg, IL 60173" className="map-location usa6"></a>
                    </div>
                    <div className="container-fluid desktop-img">
                        <div className="wrapper find-us-wrapper">
                            <div className="row">
                                <div className="findus-content">
                                    {isLoading ? (
                                        <div>
                                            <h2>
                                                <ReactPlaceholder type='text' rows={1} color="#ffda41" style={{ width: "300px", height: "50px" }} ready={false} showLoadingAnimation={true}></ReactPlaceholder>
                                            </h2>
                                            <p>
                                                <ReactPlaceholder type='text' rows={2} style={{ width: "1000px", height: "40px" }} ready={false} showLoadingAnimation={true}></ReactPlaceholder>
                                            </p>
                                            <ReactPlaceholder type='text' rows={1} color="#ffda41" style={{ width: "150px", height: "60px" }} ready={false} showLoadingAnimation={true}></ReactPlaceholder>
                                        </div>
                                    ) : (
                                        users.map(user => {
                                            return (
                                                <div>
                                                    <h2>
                                                        {user.field_location_title}</h2>
                                                    <p>
                                                        {user.field_location_description}</p>
                                                    <Link href='/contact-us'><a><button className="findus-btn">{user.field_location_button_text}</button></a></Link>
                                                </div>
                                            );
                                        })
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <div className="container-fluid mobile-img">
                    <div className="wrapper find-us-wrapper">
                        <div className="row">
                            <div className="findus-content">
                                {
                                    users.map(user => {
                                        return (
                                            <div>
                                                <h2>{user.field_location_title}</h2>
                                                <p>{user.field_location_description}</p>
                                                <Link href='/contact-us'><a><button className="findus-btn">{user.field_location_button_text}</button></a></Link>
                                            </div>
                                        );
                                    })
                                }
                            </div>
                        </div>
                    </div>
                </div>
                {/* <div className="aboutus-our-clients">
                    <OurClients />
                </div> */}
                <PromotionalBanner />
            </>
        )
    }
}
export default Aboutus

export async function getStaticProps(context) {
    try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/aboutus/36`);
        const data = await res.json();

        return {
            props: {
                users: data,
                isLoading: false
            },
            revalidate: 10,
        }
    } catch (e) {
        console.log('__ERROR__:About Page:', e);
        return {
            props: {
                // errorObj: e,
                users: [],
                isLoading: true
            },
            revalidate: 10,
        }
    }
}
