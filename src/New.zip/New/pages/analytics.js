import React from 'react';
import ServicePage from '../components/ServicePage';

const AnalyticsDetail = (props) => {
    return (
        <>
            <ServicePage pageClass='analytics' {...props} />
        </>
    )
}
export default AnalyticsDetail

export async function getStaticProps(context) {
    try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/services-detail/7`);
        const result = await res.json();
        console.log("resulys-service", result)
        return {
            props: {
                data: result,

                servicedetails: result[0],
                field_service_detail_collection_export: result[0].field_service_detail_collection_export,
                servicedetails_default_navigation: result[0].field_service_detail_collection_export[0].navigation,
                isLoading: false
            },
            revalidate: 10,
        }
    } catch (e) {
        return {
            props: {
                servicedetails: [],
                field_service_detail_collection_export: [],
                servicedetails_default_navigation: [],
                isLoading: true,
            },
            revalidate: 10,
        }
    }
}