import React from "react";
import MetaDecorator from "../components/Util/MetaDecorator";
const policy = require("../data/privacy-policy.json");
class Privacy extends React.Component {
  // constructor(props) {
  //   super(props);
  //   this.state = {
  //     items: [],
  //     error: false
  //   };
  // }
  componentDidMount() {
    setTimeout(() => {
      window.scrollTo(0, 0)
    }, 300)
    //   fetch(`${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/privacy-policy/37`)
    //     .then(res => res.json())
    //     .then(res => {
    //       this.setState({
    //         items: res[0].field_privacy_sub_block_export
    //       });
    //     })
    //     .catch(error => {
    //       console.error(error);
    //       this.setState({
    //         error: true
    //       });
    //     });
  }

  render() {
    {
      console.log(this);
    }
    return (
      <>
        <MetaDecorator
          href={policy.canonicalUrl}
        />
        <div className='DesktopBlogDetail'>
          <div className="container-fluid">
            <div className="wrapper">
              <div className="row">
                <div className='col-lg-2'>
                  <div className='blog'>
                    <div className="social-icons soc-ico-wrapper">
                      <ul>
                        <li><a href="https://twitter.com/AmeexDigital" target="_blank"> <span className="amd-twitter"></span></a></li>
                        <li><a href="https://www.facebook.com/Ameex_Digital-101893662036320" target="_blank"> <span className="amd-facebook"></span></a></li>
                        <li><a href="https://www.youtube.com/channel/UC5sHd3vyJISHaTFLx8Vvmyg" target="_blank"> <span className="amd-youtube"></span></a></li>
                      </ul>
                    </div>
                  </div>

                </div>
                <div className='col-lg-10'>

                  <div className='privacypara'>
                    <h1 className="privacy-title">{this.props.items.title}</h1>
                    {this.props.items.field_privacy_sub_block_export?.map(
                      ({ privacy_sub_title, privacy_sub_description }, index) => {
                        return (
                          <div className='privacypara-1' key={index}>
                            <h2 className='privacytitle'>{privacy_sub_title}</h2>
                            {privacy_sub_description.map((item, index) => {
                              return <p style={{ margin: '45px 0px 25px 0px' }}>{item}</p>;
                            })}
                          </div>
                        );
                      }
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }
}

export default Privacy;
export async function getStaticProps(context) {
  try {
    const res = await fetch(`${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/privacy-policy/37`);
    const data = await res.json();

    return {
      props: {
        items: data?.[0],
      },
      revalidate: 10,
    }
  } catch (e) {
    return {
      props: {
        items: {},
      },
      revalidate: 10,
    }
  }
}
