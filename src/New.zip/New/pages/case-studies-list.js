import React from 'react';
import axios from 'axios';
// import Tabs from 'react-responsive-tabs';
// import OurClients from '../components/common/ourClients/ourclients';
import SeeResult from '../components/common/seeResults/seeresult';
import MonthlyBudget from '../components/common/monthlyBudget/monthlybudget';
import Link from 'next/link';
import ReactPlaceholder from 'react-placeholder';
import "react-placeholder/lib/reactPlaceholder.css";
import MetaDecorator from "../components/Util/MetaDecorator";
import Schema from '../components/Util/Schema';
import dynamic from 'next/dynamic';
import { TextBlock, RectShape } from 'react-placeholder/lib/placeholders';
import LazyLoad from 'react-lazyload';



const CaselistPlaceholder = (
    <div className='my-awesome-placeholder' style={{ paddingTop: 35, }}>
        <RectShape color='black' className="list-place-rect" style={{ width: 117, height: 125, marginBottom: 20, borderRadius: 6 }} />
        <RectShape color='black' className="list-place-rect" style={{ width: 117, height: 125, marginBottom: 20, borderRadius: 6 }} />
        <RectShape color='lightgrey' className="list-place-rect" style={{ width: 117, height: 125, marginBottom: 20, borderRadius: 6 }} />
        <RectShape color='lightgrey' className="list-place-bigrect" style={{ width: 510, height: 751, marginLeft: 159, marginTop: -436, marginBottom: -160, borderRadius: 6 }} />
        <TextBlock rows={7} color='#b4b4b7' className="list-place-text" style={{ width: 450, position: 'relative', left: 190, bottom: 160 }} />
    </div>
);
const casestudypage = require("../data/casestudypage");

const Tabs = dynamic(() => import('react-responsive-tabs'), {
    ssr: false
})

class CaseStudiesListing extends React.Component {
    constructor(props) {
        super(props);
        this.tabsiconchange = this.tabsiconchange.bind(this);
        this.tabsiconchange2 = this.tabsiconchange2.bind(this);
        this.tabsiconchange3 = this.tabsiconchange3.bind(this);

        this.closetabscont1 = this.closetabscont1.bind(this);
        this.closetabscont2 = this.closetabscont2.bind(this);
        this.closetabscont3 = this.closetabscont3.bind(this);

        this.state = {
            casestudieslisting1: {},
            casestudieslisting1statsresult_stats: {},
            casestudieslisting2: {},
            casestudieslisting2statsresult_stats: {},
            casestudieslisting3: {},
            casestudieslisting3statsresult_stats: {},
            casestudieslistingtabs1: [],
            casestudieslistingtabs2: [],
            casestudieslistingtabs3: [],
            selectedtabkey: null,
            selectedtabkey2: null,
            selectedtabkey3: null,
            //selectedtabkey4: null,
            //selectedtabkey5: null,

            featuredcont_m: true,
            featuredcont_m2: true,
            featuredcont_m3: true,
            //featuredcont_m4: true,
            //featuredcont_m5: true,

            closetabscont1key: false,
            closetabscont2key: false,
            closetabscont3key: false,
            //closetabscont4key: false,
            //closetabscont5key: false,
            dropdownlistopenul: false,
            dropdownlists: [
                {
                    name: "a",
                }, {
                    name: "b",
                }, {
                    name: "c",
                },
                {
                    name: "d",
                }
            ],

            open: true,
            data: null,
            isLoading: true,
        }

    }
    componentDidMount() {
        setTimeout(() => {
            window.scrollTo(0, 0);
        }, 300);
        if (this.props.isLoading) {
            fetch(`${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/case-studies-listing/22`)
                .then(res => res.json())
                .then(result => {
                    console.log('__RES__:From Case Page', result)
                    this.setState({
                        casestudieslisting1: result[0],
                        casestudieslisting1statsresult_stats: result[0].field_project_stats_export[0].result_stats[0],
                        casestudieslisting2: result[1],
                        casestudieslisting2statsresult_stats: result[1].field_project_stats_export[0].result_stats[0],
                        casestudieslisting3: result[2],
                        casestudieslisting3statsresult_stats: result[2].field_project_stats_export[0].result_stats[0],
                        casestudieslistingtabs1: [
                            result[0].field_project_stats_export[0],
                            result[0].field_watch_video_export[0],
                            result[0].field_industry_intel_export[0],
                            result[0].field_testimonial_case_study_export[0]
                        ],
                        casestudieslistingtabs2: [
                            result[1].field_project_stats_export[0],
                            result[1].field_industry_intel_export[0],
                            result[1].field_testimonial_case_study_export[0]
                        ],
                        casestudieslistingtabs3: [
                            result[2].field_project_stats_export[0],
                            result[2].field_industry_intel_export[0],
                            result[2].field_testimonial_case_study_export[0]
                        ],
                        isLoading: false,
                    })
                })
                .catch(e => console.log('__ERROR__:From Case-Listing Page', e))
        }
        else {
            const {
                casestudieslisting1,
                casestudieslisting1statsresult_stats,
                casestudieslisting2,
                casestudieslisting2statsresult_stats,
                casestudieslisting3,
                casestudieslisting3statsresult_stats,
                casestudieslistingtabs1,
                casestudieslistingtabs2,
                casestudieslistingtabs3,
            } = this.props;
            this.setState({
                casestudieslisting1,
                casestudieslisting1statsresult_stats,
                casestudieslisting2,
                casestudieslisting2statsresult_stats,
                casestudieslisting3,
                casestudieslisting3statsresult_stats,
                casestudieslistingtabs1,
                casestudieslistingtabs2,
                casestudieslistingtabs3,
                isLoading: false,
            })
        }
        // this.setState({ isLoading: false, });
        // this.getlisting1result();
        if (window.innerWidth <= 767) {
            this.setState({
                selectedtabkey: null,
                selectedtabkey2: null,
                selectedtabkey3: null,
                //selectedtabkey4: null,
                //selectedtabkey5: null,
            });

        }
        else {
            this.setState({
                selectedtabkey: 3,
                selectedtabkey2: 2,
                selectedtabkey3: 2,
                //selectedtabkey4: 3,
                //selectedtabkey5: 3
            });
        }
    }
    tabsiconchange(ix) {
        for (let i = 0; i < this.state.casestudieslistingtabs1.length; i++) {
            if (i === ix) {
                if (this.state.open) {
                    if (typeof window !== "undefined") {
                        if (window.innerWidth <= 767) {

                            this.setState({
                                featuredcont_m: false,
                                closetabscont1key: false,
                            });
                        }
                    }
                }
            }
        }
    }
    tabsiconchange2(ix) {
        for (let i = 0; i < this.state.casestudieslistingtabs2.length; i++) {
            if (i === ix) {
                if (this.state.open) {
                    if (typeof window !== "undefined") {
                        if (window.innerWidth <= 767) {

                            this.setState({
                                featuredcont_m2: false,
                                closetabscont2key: false,
                            });
                        }
                    }
                }
            }
        }
    }
    tabsiconchange3(ix) {
        for (let i = 0; i < this.state.casestudieslistingtabs3.length; i++) {
            if (i === ix) {
                if (this.state.open) {
                    if (typeof window !== "undefined") {
                        if (window.innerWidth <= 767) {

                            this.setState({
                                featuredcont_m3: false,
                                closetabscont3key: false,
                            });
                        }
                    }
                }
            }
        }
    }


    closetabscont1() {
        if (typeof window !== "undefined") {
            if (window.innerWidth <= 767) {
                this.setState({
                    closetabscont1key: true,
                    featuredcont_m: true,
                    selectedtabkey: null,
                });
                var gettabs = document.getElementById("tabswrapper1").querySelector(".RRT__tab--selected");
                gettabs?.classList.remove("RRT__tab--selected");
            }
        }
    }
    closetabscont2() {
        if (typeof window !== "undefined") {
            if (window.innerWidth <= 767) {
                this.setState({
                    closetabscont2key: true,
                    featuredcont_m2: true,
                    selectedtabkey2: null,
                });
                var gettabs = document.getElementById("tabswrapper2").querySelector(".RRT__tab--selected");
                gettabs?.classList.remove("RRT__tab--selected");
            }
        }
    }
    closetabscont3() {
        if (typeof window !== "undefined") {
            if (window.innerWidth <= 767) {
                this.setState({
                    closetabscont3key: true,
                    featuredcont_m3: true,
                    selectedtabkey3: null,
                });
                var gettabs = document.getElementById("tabswrapper3").querySelector(".RRT__tab--selected");
                gettabs?.classList.remove("RRT__tab--selected");
            }
        }
    }
    dropdownselect(name, event) {
        event.currentTarget.parentElement.parentElement.querySelector("span.dropdown").innerHTML = name;
        this.setState({
            dropdownlistopenul: false,
        });
    }
    dropdownlistopen() {
    }

    getcasestudieslisting1() {
        const {
            casestudieslisting1,
            casestudieslistingtabs1,
            casestudieslisting1statsresult_stats,
        } = this.state;
        return casestudieslistingtabs1.map((tab, index) => ({
            title: <>
                <picture className="tabs-images normal">
                    <source media="(max-width: 767px)" srcSet={tab.case_study_mobile_icon} />
                    <img className="img-list1" src={tab.case_study_desktop_icon} alt="ameex" />
                </picture>

                <picture className="tabs-images active">
                    <source media="(max-width: 767px)" srcSet={tab.case_study_mobile_active} />
                    <img className="img-list1" src={tab.case_study_desktop_active} alt="ameex" />
                </picture>

            </>,
            tabClassName: 'tab',
            panelClassName: 'panel',
            content: (
                <LazyLoad>
                    <div className={`tabs-content-wrapper ${this.state.closetabscont1key === true ? 'hide' : ''}`}>
                        <div className="tabs-content-inner">
                            <div className="tabs-content-bg-images-wrapper">
                                <picture className="tabs-conent-bg-images list1">
                                    <img src={casestudieslisting1.field_case_studies_bg_image} alt="ameex" />
                                    <source media="(max-width: 767px)" srcSet={casestudieslisting1.field_case_studies_mobile_image} />
                                </picture>

                                {
                                    tab.case_study_id === "0" && (
                                        <div className="tabs-content-stats">
                                            <div className="tabs-content-stats-inner">
                                                <div className="close-tabs-cont">
                                                    <div className="close-tabs-cont-inner" onClick={this.closetabscont1}>x</div>
                                                </div>
                                                <div className="title">
                                                    <picture className="tabs-conent-inner-icon">
                                                        <source media="(max-width: 767px)" srcSet={'/assets/images/icons/stats-content-icon-m.png'} />
                                                        <img className="" src={'/assets/images/icons/stats-content-icon-m.png'} alt="ameex" />
                                                    </picture>
                                                    <span className="label">{tab.project_stats_title}</span>
                                                </div>
                                                <div className="qualified">
                                                    <div className="row wssliderdetails" >
                                                        <div className="col-md-6 col-sm-6 col-xs-6 col-6 item">
                                                            <div className="leads">
                                                                <div className="leads-inner">
                                                                    <p>{casestudieslisting1statsresult_stats.source_name_0}</p>
                                                                    <h1>{casestudieslisting1statsresult_stats.percentage_value_0}</h1>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div className="col-md-6 col-sm-6 col-xs-6 col-6 item">
                                                            <div className="leads">
                                                                <div className="leads-inner">
                                                                    <p>{casestudieslisting1statsresult_stats.source_name_1}</p>
                                                                    <h1>{casestudieslisting1statsresult_stats.percentage_value_1}</h1>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div className="col-md-6 col-sm-6 col-xs-6 col-6 item">
                                                            <div className="leads">
                                                                <div className="leads-inner">
                                                                    <p>{casestudieslisting1statsresult_stats.source_name_2}</p>
                                                                    <h1>{casestudieslisting1statsresult_stats.percentage_value_2}</h1>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div className="col-md-6 col-sm-6 col-xs-6 col-6 item">
                                                            <div className="leads">
                                                                <div className="leads-inner">
                                                                    <p>{casestudieslisting1statsresult_stats.source_name_3}</p>
                                                                    <h1 className="down-arrow">{casestudieslisting1statsresult_stats.percentage_value_3}</h1>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="bt-title">{tab.project_stats_description}</div>
                                            </div>
                                        </div>
                                    )
                                }
                                {
                                    tab.case_study_id === "2" ? (
                                        <div className="tabs-content-video">
                                            <div className="tabs-content-video-inner">
                                                <div className="close-tabs-cont">
                                                    <div className="close-tabs-cont-inner" onClick={this.closetabscont1}>x</div>
                                                </div>
                                                <div className="title">
                                                    <picture className="tabs-conent-inner-icon">
                                                        <source media="(max-width: 767px)" srcSet={"/assets/images/icons/video-content-icon-m.png"} />
                                                        <img className="" src={"/assets/images/icons/video-content-icon.png"} alt="ameex" />
                                                    </picture>
                                                    <span className="label">{tab.watch_video_title}</span>
                                                </div>
                                                <div className="listing-video">
                                                    <iframe className="list-video-iframe" src={tab.youtube_embedded_link + "?mute=0&rel=0"} alt="ameex" allow='fullscreen;'
                                                        mozallowfullscreen="mozallowfullscreen"
                                                        msallowfullscreen="msallowfullscreen"
                                                        oallowfullscreen="oallowfullscreen"
                                                        webkitallowfullscreen="webkitallowfullscreen" frameborder="0"></iframe>
                                                </div>
                                                <div className="txt">
                                                    <p className="title">
                                                        {tab.case_studies_sub_title}
                                                    </p>
                                                    <p className="desc">{tab.watch_video_description}</p>
                                                </div>

                                            </div>
                                        </div>
                                    ) : (<></>)
                                }
                                {
                                    tab.case_study_id === "1" ? (
                                        <div className="tabs-content-information">
                                            <div className="tabs-content-information-inner">
                                                <div className="close-tabs-cont">
                                                    <div className="close-tabs-cont-inner" onClick={this.closetabscont1}>x</div>
                                                </div>
                                                <div className="title">
                                                    <picture className="tabs-conent-inner-icon">
                                                        <source media="(max-width: 767px)" srcSet={"/assets/images/icons/intel-content-icon-m.png"} />
                                                        <img className="" src={"/assets/images/icons/intel-content-icon.png"} alt="ameex" />
                                                    </picture>
                                                    <span className="label">{tab.industry_intel_title}</span>
                                                </div>
                                                <div className="txt">
                                                    <p>{tab.industry_intel_description}</p>
                                                </div>

                                            </div>
                                        </div>
                                    ) : (<></>)
                                }
                                {
                                    tab.case_study_id === "3" ? (
                                        <div className="tabs-content-testimonial">
                                            <div className="tabs-content-testimonial-inner">
                                                <div className="close-tabs-cont">
                                                    <div className="close-tabs-cont-inner" onClick={this.closetabscont1}>x</div>
                                                </div>
                                                <div className="title testimonial-title">
                                                    <picture className="tabs-conent-inner-icon">
                                                        <source media="(max-width: 767px)" srcSet={"/assets/images/icons/testimonial-content-icon-m.png"} />
                                                        <img className="" src={"/assets/images/icons/testimonial-content-icon.png"} alt="ameex" />
                                                    </picture>
                                                    <span className="label">{tab.testimonial_title}</span>
                                                </div>
                                                <div className="txt">
                                                    <p>
                                                        {tab.testimonial_description}
                                                    </p>
                                                    <span className="testimonial-author">{tab.authors_name}&nbsp;{tab.author_rolw}</span>
                                                </div>
                                            </div>
                                        </div>
                                    ) : (<></>)
                                }
                            </div>
                        </div>
                    </div>
                </LazyLoad >
            )
        }));

    }
    getcasestudieslisting2 = () => {
        const {
            casestudieslisting2,
            casestudieslistingtabs2,
            casestudieslisting2statsresult_stats,
        } = this.state;
        return casestudieslistingtabs2?.map((tab, index) => ({
            title: <>
                <div style={{ marginTop: -20 }}>
                    <span style={{ opacity: 0 }}>.</span>
                    <picture className="tabs-images active">
                        <source media="(max-width: 767px)" srcSet={tab?.case_study_mobile_active} />
                        <img className="img-list2" src={tab?.case_study_desktop_active} alt="ameex" />
                    </picture>
                    <picture className="tabs-images normal">
                        <source media="(max-width: 767px)" srcSet={tab?.case_study_mobile_icon} />
                        <img className="img-list2" src={tab?.case_study_desktop_icon} alt="ameex" />
                    </picture>
                </div>
            </>,
            tabClassName: 'tab',
            panelClassName: 'panel',
            content: (
                <LazyLoad>
                    <div className={`tabs-content-wrapper ${this.state.closetabscont2key === true ? 'hide' : ''}`}>
                        <div className="tabs-content-inner">
                            <div className="tabs-content-bg-images-wrapper">
                                <picture className="tabs-conent-bg-images list2">
                                    <source media="(max-width: 767px)" srcSet={casestudieslisting2.field_case_studies_mobile_image} />
                                    <img className="" src={casestudieslisting2.field_case_studies_bg_image} alt="ameex" />
                                </picture>

                                {
                                    tab.case_study_id === "0" && (
                                        <div className="tabs-content-stats">
                                            <div className="tabs-content-stats-inner">
                                                <div className="close-tabs-cont">
                                                    <div className="close-tabs-cont-inner" onClick={this.closetabscont2}>x</div>
                                                </div>
                                                <div className="title">
                                                    <picture className="tabs-conent-inner-icon">
                                                        <source media="(max-width: 767px)" srcSet={"/assets/images/icons/stats-content-icon-m.png"} />
                                                        <img className="" src={"/assets/images/icons/stats-content-icon-m.png"} alt="ameex" />
                                                    </picture>
                                                    <span className="label">{tab.project_stats_title}</span>
                                                </div>
                                                <div className="qualified">
                                                    <div className="row wssliderdetails" >
                                                        <div className="col-md-6 col-sm-6 col-xs-6 col-6 item">
                                                            <div className="leads">
                                                                <div className="leads-inner">
                                                                    <p>{casestudieslisting2statsresult_stats.source_name_0}</p>
                                                                    <h1>{casestudieslisting2statsresult_stats.percentage_value_0}</h1>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div className="col-md-6 col-sm-6 col-xs-6 col-6 item">
                                                            <div className="leads">
                                                                <div className="leads-inner">
                                                                    <p>{casestudieslisting2statsresult_stats.source_name_1}</p>
                                                                    <h1>{casestudieslisting2statsresult_stats.percentage_value_1}</h1>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div className="col-md-6 col-sm-6 col-xs-6 col-6 item">
                                                            <div className="leads">
                                                                <div className="leads-inner">
                                                                    <p>{casestudieslisting2statsresult_stats.source_name_2}</p>
                                                                    <h1>{casestudieslisting2statsresult_stats.percentage_value_2}</h1>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="bt-title">{tab.project_stats_description}</div>
                                            </div>
                                        </div>
                                    )
                                }
                                {
                                    tab.case_study_id === "2" ? (
                                        <div className="tabs-content-video">
                                            <div className="tabs-content-video-inner">
                                                <div className="close-tabs-cont">
                                                    <div className="close-tabs-cont-inner" onClick={this.closetabscont2}>x</div>
                                                </div>
                                                <div className="title">
                                                    <picture className="tabs-conent-inner-icon">
                                                        <source media="(max-width: 767px)" srcSet={"/assets/images/icons/video-content-icon-m.png"} />
                                                        <img className="" src={"/assets/images/icons/video-content-icon.png"} alt="ameex" />
                                                    </picture>
                                                    <span className="label">{tab.watch_video_title}</span>
                                                </div>
                                                <picture className="tabs-conent-inner-image">
                                                    <source media="(max-width: 767px)" srcSet={tab.mobile_thumbnail_icon} />
                                                    <img className="" src={tab.desktop_thumbnail_icon} alt="ameex" />
                                                </picture>
                                                <div className="txt">
                                                    <p className="title">
                                                        {tab.case_studies_sub_title}
                                                    </p>
                                                    <p className="desc">{tab.watch_video_description}</p>
                                                </div>

                                            </div>
                                        </div>
                                    ) : (<></>)
                                }
                                {
                                    tab.case_study_id === "1" ? (
                                        <div className="tabs-content-information">
                                            <div className="tabs-content-information-inner">
                                                <div className="close-tabs-cont">
                                                    <div className="close-tabs-cont-inner" onClick={this.closetabscont2}>x</div>
                                                </div>
                                                <div className="title">
                                                    <picture className="tabs-conent-inner-icon">
                                                        <source media="(max-width: 767px)" srcSet={"/assets/images/icons/intel-content-icon-m.png"} />
                                                        <img className="" src={"/assets/images/icons/intel-content-icon.png"} alt="ameex" />
                                                    </picture>
                                                    <span className="label">{tab.industry_intel_title}</span>
                                                </div>
                                                <div className="txt">
                                                    <p>{tab.industry_intel_description}</p>
                                                </div>

                                            </div>
                                        </div>
                                    ) : (<></>)
                                }
                                {
                                    tab.case_study_id === "3" ? (
                                        <div className="tabs-content-testimonial">
                                            <div className="tabs-content-testimonial-inner sec-third-inner">
                                                <div className="close-tabs-cont">
                                                    <div className="close-tabs-cont-inner" onClick={this.closetabscont2}>x</div>
                                                </div>
                                                <div className="title testimonial-title">
                                                    <picture className="tabs-conent-inner-icon">
                                                        <source media="(max-width: 767px)" srcSet={"/assets/images/icons/testimonial-content-icon-m.png"} />
                                                        <img className="" src={"/assets/images/icons/testimonial-content-icon.png"} alt="ameex" />
                                                    </picture>
                                                    <span className="label">{tab.testimonial_title}</span>
                                                </div>
                                                <div className="txt">
                                                    <p>
                                                        {tab.testimonial_description}
                                                    </p>
                                                    <span className="testimonial-author">{tab.authors_name}&nbsp;{tab.author_rolw}</span>
                                                </div>
                                            </div>
                                        </div>
                                    ) : (<></>)
                                }
                            </div>
                        </div>
                    </div>
                </LazyLoad >
            )
        }));
    }
    getcasestudieslisting3() {
        const {
            casestudieslisting3,
            casestudieslistingtabs3,
            casestudieslisting3statsresult_stats
        } = this.state;
        return casestudieslistingtabs3.map((tab, index) => ({
            title: <>
                <div style={{ marginTop: -20 }}>
                    <span style={{ opacity: 0 }}>.</span>
                    <picture className="tabs-images normal">
                        <source media="(max-width: 767px)" srcSet={tab.case_study_mobile_icon} />
                        <img className="img-list3" src={tab.case_study_desktop_icon} alt="ameex" />
                    </picture>
                    <picture className="tabs-images active">
                        <source media="(max-width: 767px)" srcSet={tab.case_study_mobile_active} />
                        <img className="img-list3" src={tab.case_study_desktop_active} alt="ameex" />
                    </picture>
                </div>
            </>,
            tabClassName: 'tab',
            panelClassName: 'panel',
            content: (
                <LazyLoad>
                    <div className={`tabs-content-wrapper ${this.state.closetabscont3key === true ? 'hide' : ''}`}>
                        <div className="tabs-content-inner">
                            <div className="tabs-content-bg-images-wrapper">
                                <picture className="tabs-conent-bg-images list3">
                                    <source media="(max-width: 767px)" srcSet={casestudieslisting3.field_case_studies_mobile_image} />
                                    <img className="" src={casestudieslisting3.field_case_studies_bg_image} alt="ameex" />
                                </picture>
                                {
                                    tab.case_study_id === "0" ? (
                                        <div className="tabs-content-stats">
                                            <div className="tabs-content-stats-inner">
                                                <div className="close-tabs-cont">
                                                    <div className="close-tabs-cont-inner" onClick={this.closetabscont3}>x</div>
                                                </div>
                                                <div className="title">
                                                    <picture className="tabs-conent-inner-icon">
                                                        <source media="(max-width: 767px)" srcSet={"/assets/images/icons/stats-content-icon-m.png"} />
                                                        <img className="" src={"/assets/images/icons/stats-content-icon-m.png"} alt="ameex" />
                                                    </picture>
                                                    <span className="label">{tab.project_stats_title}</span>
                                                </div>
                                                <div className="qualified">
                                                    <div className="row wssliderdetails" >
                                                        <div className="col-md-6 col-sm-6 col-xs-6 col-6 item">
                                                            <div className="leads">
                                                                <div className="leads-inner">
                                                                    <p>{casestudieslisting3statsresult_stats.source_name_0}</p>
                                                                    <h1>{casestudieslisting3statsresult_stats.percentage_value_0}</h1>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div className="col-md-6 col-sm-6 col-xs-6 col-6 item">
                                                            <div className="leads">
                                                                <div className="leads-inner">
                                                                    <p>{casestudieslisting3statsresult_stats.source_name_1}</p>
                                                                    <h1>{casestudieslisting3statsresult_stats.percentage_value_1}</h1>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div className="col-md-6 col-sm-6 col-xs-6 col-6 item">
                                                            <div className="leads">
                                                                <div className="leads-inner">
                                                                    <p>{casestudieslisting3statsresult_stats.source_name_2}</p>
                                                                    <h1>{casestudieslisting3statsresult_stats.percentage_value_2}</h1>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div className="col-md-6 col-sm-6 col-xs-6 col-6 item">
                                                            <div className="leads">
                                                                <div className="leads-inner">
                                                                    <p>{casestudieslisting3statsresult_stats.source_name_3}</p>
                                                                    <h1>{casestudieslisting3statsresult_stats.percentage_value_3}</h1>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="bt-title">{tab.project_stats_description}</div>
                                            </div>
                                        </div>
                                    ) : (<></>)
                                }
                                {
                                    tab.case_study_id === "2" ? (
                                        <div className="tabs-content-video">
                                            <div className="tabs-content-video-inner">
                                                <div className="close-tabs-cont">
                                                    <div className="close-tabs-cont-inner" onClick={this.closetabscont3}>x</div>
                                                </div>
                                                <div className="title">
                                                    <picture className="tabs-conent-inner-icon">
                                                        <source media="(max-width: 767px)" srcSet={"/assets/images/icons/video-content-icon-m.png"} />
                                                        <img className="" src={"/assets/images/icons/video-content-icon.png"} alt="ameex" />
                                                    </picture>
                                                    <span className="label">{tab.watch_video_title}</span>
                                                </div>
                                                <picture className="tabs-conent-inner-image">
                                                    <source media="(max-width: 767px)" srcSet={tab.mobile_thumbnail_icon} />
                                                    <img className="" src={tab.desktop_thumbnail_icon} alt="ameex" />
                                                </picture>
                                                <div className="txt">
                                                    <p className="title">
                                                        {tab.case_studies_sub_title}
                                                    </p>
                                                    <p className="desc">{tab.watch_video_description}</p>
                                                </div>

                                            </div>
                                        </div>
                                    ) : (<></>)
                                }
                                {
                                    tab.case_study_id === "1" ? (
                                        <div className="tabs-content-information">
                                            <div className="tabs-content-information-inner">
                                                <div className="close-tabs-cont">
                                                    <div className="close-tabs-cont-inner" onClick={this.closetabscont3}>x</div>
                                                </div>
                                                <div className="title">
                                                    <picture className="tabs-conent-inner-icon">
                                                        <source media="(max-width: 767px)" srcSet={"/assets/images/icons/intel-content-icon-m.png"} />
                                                        <img className="" src={"/assets/images/icons/intel-content-icon.png"} alt="ameex" />
                                                    </picture>
                                                    <span className="label">{tab.industry_intel_title}</span>
                                                </div>
                                                <div className="txt">
                                                    <p>{tab.industry_intel_description}</p>
                                                </div>

                                            </div>
                                        </div>
                                    ) : (<></>)
                                }
                                {
                                    tab.case_study_id === "3" ? (
                                        <div className="tabs-content-testimonial">
                                            <div className="tabs-content-testimonial-inner">
                                                <div className="close-tabs-cont">
                                                    <div className="close-tabs-cont-inner" onClick={this.closetabscont3}>x</div>
                                                </div>
                                                <div className="title testimonial-title">
                                                    <picture className="tabs-conent-inner-icon">
                                                        <source media="(max-width: 767px)" srcSet={"/assets/images/icons/testimonial-content-icon-m.png"} />
                                                        <img className="" src={"/assets/images/icons/testimonial-content-icon.png"} alt="ameex" />
                                                    </picture>
                                                    <span className="label">{tab.testimonial_title}</span>
                                                </div>
                                                <div className="txt">
                                                    <p>
                                                        {tab.testimonial_description}
                                                    </p>
                                                    <span className="testimonial-author">{tab.authors_name}&nbsp;{tab.author_rolw}</span>
                                                </div>
                                            </div>
                                        </div>
                                    ) : (<></>)
                                }
                            </div>
                        </div>
                    </div>
                </LazyLoad >
            )
        }));
    }

    render() {
        const {
            isLoading,
            casestudieslisting1,
            casestudieslisting2,
            casestudieslisting3 } = this.state;
        return (
            <>

                <MetaDecorator
                    description={casestudypage.metaDescription}
                    title={casestudypage.pageTitle}
                    href={casestudypage.canonicalUrl}
                />
                {
                    casestudieslisting1.field_schema_types_export && casestudieslisting1.field_schema_types_export.map((data) =>
                        <Schema data={JSON.parse(data.body)} />
                    )
                }
                <section className="featured-success-wrapper case-studies-listing-wrapper">
                    <div className="container-fluid">
                        <div className="wrapper">

                            <div className="row">
                                <div className="col-md-5 offset-md-1">
                                    <h1>
                                        <ReactPlaceholder type='text' rows={1} color="#1c1d21" style={{ width: "50%" }} ready={!isLoading} showLoadingAnimation={true}>
                                            {casestudieslisting1.field_top_title}
                                        </ReactPlaceholder>
                                    </h1>
                                </div>
                            </div>

                            <div className="row">
                                <div className="col-md-5 offset-md-1 tabswrapper-wrap">
                                    <div className="tabswrapper" id="tabswrapper1">
                                        {/* this.state.casestudieslistingtabs1.length==0 */}
                                        <ReactPlaceholder ready={!isLoading} customPlaceholder={CaselistPlaceholder}>
                                            <Tabs
                                                transformWidth={100}
                                                selectedTabKey={this.state.selectedtabkey}
                                                items={this.getcasestudieslisting1()}
                                                onChange={this.tabsiconchange}
                                                showMore={false}
                                            />
                                        </ReactPlaceholder>
                                    </div>
                                </div>
                                <div className={`col-md-4 offset-md-1 tabs-cont-parallel-wrapper ${this.state.featuredcont_m === false ? 'hide' : ''}`} >
                                    <div className="tabs-content-wrapper">
                                        <div className="tabs-content-inner" id="case-image-first">

                                            <picture className="tabs-conent-bg-images list1">
                                                <img className="" src={casestudieslisting1.field_case_studies_bg_image} alt="ameex" />

                                            </picture>

                                        </div>
                                    </div>
                                    <div className="tabs-cont-parallel-inner">
                                        <h3 className="sub-title">
                                            <ReactPlaceholder type='text' className="list-place-content" rows={1} ready={!isLoading} showLoadingAnimation={true}>
                                                {casestudieslisting1.field_case_studies_title}
                                            </ReactPlaceholder>
                                        </h3>
                                        <h2 className="title">
                                            <ReactPlaceholder type='text' className="list-place-content" rows={1} ready={!isLoading} style={{ height: "80px", marginTop: "26px" }} showLoadingAnimation={true}>
                                                {casestudieslisting1.field_case_studies_sub_title}
                                            </ReactPlaceholder>
                                        </h2>
                                        <p>
                                            <ReactPlaceholder type='text' className="list-place-content-para" rows={6} ready={!isLoading} showLoadingAnimation={true}>
                                                {casestudieslisting1.field_case_studies_description}
                                            </ReactPlaceholder>
                                        </p>
                                        <ReactPlaceholder type='rect' className="list-place-content-btn" ready={!isLoading} style={{ width: 200, height: 42 }} showLoadingAnimation={true}>
                                            <div className="group-btn listing-btn1">
                                                <div className="bg">
                                                    <Link href={{ pathname: casestudieslisting1.field_case_studies_link }}><a className="btn">{casestudieslisting1.field_case_studies_button}</a></Link>
                                                </div>
                                            </div>
                                        </ReactPlaceholder>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <section className="case-studies-listing-wrapper dropdownlist-wrapper">
                    <div className="container-fluid">
                        <div className="wrapper">
                            <div className="row">
                                <div className="col-12">
                                    <div className="dropdown_list_tittle"></div>
                                    <div className="dropdown_list">
                                        <span className={`dropdown ${this.state.dropdownlistopenul ? 'is-active' : ''}`} onClick={this.dropdownlistopen.bind(this)}>HEALTH &amp; WELLNESS</span>
                                        <ul className="drop">
                                            {
                                                this.state.dropdownlists.map((dropdownlist, index) => (
                                                    <li key={index} data-name={dropdownlist.name} onClick={this.dropdownselect.bind(this, dropdownlist.name)}>{dropdownlist.name}</li>
                                                ))
                                            }
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <section className="case-studies-listing-wrapper vitamins-industry-wrapper tabs-right">
                    <div className="container-fluid">
                        <div className="wrapper">
                            <div className="row">
                                <div className="col-md-4 offset-md-1 tabs-cont-parallel-wrapper">
                                    <div className={`tabs-content-wrapper ${this.state.featuredcont_m2 === false ? 'hide' : ''}`}>
                                        <div className="tabs-content-inner">
                                            <picture className="tabs-conent-bg-images list2">
                                                <source media="(max-width: 767px)" srcSet={casestudieslisting2.field_case_studies_mobile_image} />
                                                <img className="" src={casestudieslisting2.field_case_studies_bg_image} alt="ameex" />
                                            </picture>
                                        </div>
                                    </div>
                                    <div className="tabs-cont-parallel-inner tabs-cont-par-in">
                                        <h3 className="sub-title">
                                            <ReactPlaceholder type='text' rows={4} color="#ffda41" ready={!isLoading} showLoadingAnimation={true}>
                                                {casestudieslisting2.field_case_studies_title}
                                            </ReactPlaceholder>
                                        </h3>
                                        <p>
                                            <ReactPlaceholder type='text' rows={5} ready={!isLoading} showLoadingAnimation={true}>
                                                {casestudieslisting2.field_case_studies_description}
                                            </ReactPlaceholder>
                                        </p>
                                        <ReactPlaceholder type='rect' ready={!isLoading} style={{ width: 200, height: 42 }} showLoadingAnimation={true}>
                                            <div className="group-btn listing-btn1">
                                                <div className="bg">
                                                    <Link href={{ pathname: casestudieslisting2.field_case_studies_link }}><a className="btn">{casestudieslisting2.field_case_studies_button}</a></Link>
                                                </div>
                                            </div>
                                        </ReactPlaceholder>
                                    </div>
                                </div>
                                <div className="col-md-5 offset-md-1 tabswrapper-wrap">
                                    <div className="tabswrapper" id="tabswrapper2">
                                        <Tabs
                                            transformWidth={100}
                                            selectedTabKey={this.state.selectedtabkey2}
                                            items={this.getcasestudieslisting2()}
                                            onChange={this.tabsiconchange2}
                                            showMore={false}
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <section className="xyz-corp-wrapper case-studies-listing-wrapper">
                    <div className="container-fluid">
                        <div className="wrapper">

                            <div className="row">
                                <div className="col-md-5 offset-md-1 tabswrapper-wrap">
                                    <div className="tabswrapper" id="tabswrapper3">
                                        <Tabs
                                            transformWidth={100}
                                            selectedTabKey={this.state.selectedtabkey3}
                                            items={this.getcasestudieslisting3()}
                                            onChange={this.tabsiconchange3}
                                            showMore={false}
                                        />
                                    </div>
                                </div>
                                <div className="col-md-4 offset-md-1 tabs-cont-parallel-wrapper">
                                    <div className={`tabs-content-wrapper ${this.state.featuredcont_m3 === false ? 'hide' : ''}`}>
                                        <div className="tabs-content-inner">
                                            <picture className="tabs-conent-bg-images list3">
                                                <source media="(max-width: 767px)" srcSet={casestudieslisting3.field_case_studies_mobile_image} />
                                                <img className="" src={casestudieslisting3.field_case_studies_bg_image} alt="ameex" />
                                            </picture>
                                        </div>
                                    </div>
                                    <div className="tabs-cont-parallel-inner">
                                        <h3 className="sub-title variation">
                                            <ReactPlaceholder type='text' rows={4} color="#4e4e56" ready={!isLoading} showLoadingAnimation={true}>
                                                {casestudieslisting3.field_case_studies_title}
                                            </ReactPlaceholder>
                                        </h3>

                                        <p className="variation">
                                            <ReactPlaceholder type='text' rows={5} ready={!isLoading} showLoadingAnimation={true}>
                                                {casestudieslisting3.field_case_studies_description}
                                            </ReactPlaceholder>
                                        </p>
                                        <ReactPlaceholder type='rect' ready={!isLoading} style={{ width: 200, height: 42 }} showLoadingAnimation={true}>
                                            <div className="group-btn listing-btn1 listing-btn2">
                                                <div className="bg">
                                                    <Link href={{ pathname: casestudieslisting3.field_case_studies_link }}><a className="btn">{casestudieslisting3.field_case_studies_button}</a></Link>
                                                </div>
                                            </div>
                                        </ReactPlaceholder>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>


                <section className="case-studies-listing-wrapper loadmore-wrapper">
                    <div className="container-fluid">
                        <div className="wrapper">
                            <div className="row">
                                <div className="col-12">
                                    <div className="group-btn listing-btn3">
                                        <div className="bg">
                                            <button className="btn">LOAD MORE</button>
                                        </div>
                                    </div>
                                    <div className="loadmore-cont">Showing 3 of 30 Case Studies</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <MonthlyBudget />
                <div className="seeresult-listing"><SeeResult /></div>
                {/* <div class="contactus-our-clients">
                    <OurClients />
                </div> */}
            </>
        );
    }
}
export default CaseStudiesListing;
export async function getStaticProps(context) {
    try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/case-studies-listing/22`);
        const result = await res.json();
        console.log("list", result)
        return {
            props: {
                isLoading: false,
                casestudieslisting1: result[0],
                casestudieslisting1statsresult_stats: result[0].field_project_stats_export[0].result_stats[0],
                casestudieslisting2: result[1],
                casestudieslisting2statsresult_stats: result[1].field_project_stats_export[0].result_stats[0],
                casestudieslisting3: result[2],
                casestudieslisting3statsresult_stats: result[2].field_project_stats_export[0].result_stats[0],
                casestudieslistingtabs1: [
                    result[0].field_project_stats_export[0],
                    result[0].field_watch_video_export[0],
                    result[0].field_industry_intel_export[0],
                    result[0].field_testimonial_case_study_export[0]
                ],
                casestudieslistingtabs2: [
                    result[1].field_project_stats_export[0],
                    result[1].field_industry_intel_export[0],
                    result[1].field_testimonial_case_study_export[0]
                ],
                casestudieslistingtabs3: [
                    result[2].field_project_stats_export[0],
                    result[2].field_industry_intel_export[0],
                    result[2].field_testimonial_case_study_export[0]
                ],
            },
            revalidate: 10,
        }
    } catch (e) {
        console.log('__ERROR__:Case Studies Page:', e);
        return {
            props: {
                // errorObj: e,
                isLoading: true,
                casestudieslisting1: {},
                casestudieslisting2: {},
                casestudieslisting3: {},
                casestudieslisting1statsresult_stats: {},
                casestudieslisting2statsresult_stats: {},
                casestudieslisting3statsresult_stats: {},
                casestudieslistingtabs1: [],
                casestudieslistingtabs2: [],
                casestudieslistingtabs3: [],
            },
            revalidate: 10,
        }
    }
}