import React, { useEffect } from 'react';
import ServicePage from '../components/ServicePage';


const DigitalMarketStrategy = (props) => {
    useEffect(() => {
        setTimeout(() => {
            window.scrollTo(0, 0);
        }, 300)
    }, []);
    
    return (
        <>
            <ServicePage pageClass='digitalmarketstrategy' {...props} />
        </>
    )
}
export default DigitalMarketStrategy
export async function getStaticProps(context) {
    try {
        const res = await fetch(`${process.env.NEXT_PUBLIC_AMEEXDIGITAL_API}/services-detail/4`);
        const result = await res.json();
        console.log("resulys-service", result)
        return {
            props: {
                data: result,

                servicedetails: result[0],
                field_service_detail_collection_export: result[0].field_service_detail_collection_export,
                servicedetails_default_navigation: result[0].field_service_detail_collection_export[0].navigation,
                isLoading: false
            },
            revalidate: 10,
        }
    } catch (e) {
        return {
            props: {
                // data: null,
                servicedetails: [],
                field_service_detail_collection_export: [],
                servicedetails_default_navigation: [],
                isLoading: true
            },
            revalidate: 10,
        }
    }
}